import { configDotenv } from "dotenv";
configDotenv();

import sendEmail from "./send-email";
export default sendEmail;

export { testEnvironment, testTemplate } from "./config-test";
