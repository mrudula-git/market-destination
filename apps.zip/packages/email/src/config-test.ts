import path from "path";
import ejs from "ejs";
import fs from "fs";

export function testEnvironment() {
  console.log("Environment", process.env.EMAIL_USER, process.env.EMAIL_PASS);
  console.log(__dirname);
}

export function testTemplate() {
  try {
    const TEMPLATE_BASE_PATH = __dirname + "";

    const emailTemplatePath = path.join(
      TEMPLATE_BASE_PATH,
      "..",
      "/templates/test.template.ejs"
    );

    const emailTemplateContent = fs.readFileSync(emailTemplatePath, {
      encoding: "utf-8",
    });

    const content = "Hello world";
    const compiledEmailContent = ejs.compile(emailTemplateContent)({ content });

    console.log(compiledEmailContent);
  } catch (error) {
    throw error;
  }
}
