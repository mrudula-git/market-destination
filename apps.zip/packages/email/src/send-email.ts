import nodemailer from "nodemailer";
import ejs from "ejs";
import fs from "fs/promises";
import path from "path";

const USER = process.env.EMAIL_USER;
const PASS = process.env.EMAIL_PASS;
const TEMPLATE_BASE_PATH = __dirname + "";
console.log(__dirname);

export default async function sendEmail(
  to: string,
  subject: string,
  heading: string,
  content: string,
  templateFileName: string,
  name: string,
  otp: string,
  userEmail: string,
  contact: string
) {
  try {
    const transporter = nodemailer.createTransport({
      service: "Gmail",
      host: "smtp.gmail.com",
      port: 465,
      secure: true,
      auth: {
        user: USER,
        pass: PASS,
      },
    });

    const emailTemplatePath = path.join(
      TEMPLATE_BASE_PATH,
      "..",
      "templates",
      templateFileName
  );
  
    const emailTemplateContent = await fs.readFile(emailTemplatePath, "utf-8");
    // console.log(heading,content,to,subject)

    const compiledTemplate = ejs.compile(emailTemplateContent);

    const formattedEmail = compiledTemplate({
      heading,
      content,
      name,
      otp,
      userEmail,
      contact,
    });
    // console.log(heading,content,to,subject)
    const mailOptions = {
      from: USER,
      to: `${to}`,
      subject: subject,
      html: formattedEmail,
    };

    const info = await transporter.sendMail(mailOptions);
    console.log("Email sent:", info.response);
    return true;
  } catch (error) {
    console.error("Error sending email:", error);
    return false;
  }
}
