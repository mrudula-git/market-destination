export { Prisma } from "@prisma/client";
export { prisma } from "./prisma";
export type {
  acl_roles as ACL_Roles,
  acl_roles_policies as ACL_Roles_Policies,
  listings as Listings,
  badges as ListingsBadges,
  packages as ListingsPackages,
  price as ListingsPackagesPrice,
  places as ListingsPlaces,
  locations as Locations,
  listing_categories as ListingsCategories,
  listing_attributes as ListingsAttributes,
  listing_attribute_groups as ListingsAttributesGroup,
  users as Users,
  admin_users as AdminUsers,
  contacts as Contacts,
  // listing_types as ListingTypes,
  reviews as Reviews,
  review_details as ReviewDetails,
  reviewers as Reviewers,
  media as Media,
} from "@prisma/client";
