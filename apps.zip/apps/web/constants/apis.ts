export const baseUrl =
  process.env.NEXT_PUBLIC_API_URL || "http://54.81.164.225:8000/api/web";

export const apis = {
  search: `/search`,
  listings: `/listings`,
  listingsByCategories: `/listings-categories`,
  listingsCompare: `/listings-compare`,
  listingCompareSearch: `/listings-compare/search`,
  listingsAttributes: `/listings-attributes`,
  listingsAttributesForAttributes: `/listings-attributes/attributes`,
  listingsAttributesCompare: `/listings-attributes/compare`,

  listing: (slug: string) => `/listings/${slug}`,
  review: (listingsId: string) => `/reviews/listings/${listingsId}`,
  reviews: `/reviews`,
  reviewer: `/reviewers`,
  verify: `/reviewers/verify`,
  contactus:`/contact-us`
};
