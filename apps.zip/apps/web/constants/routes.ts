export const routes = {
  root: "/",
  search: "/search",
  compareLeft: (leftId: string) => `/compare?left=${leftId}`,
  compareLeftRight: (leftId: string, rightId: string) =>
    `/compare?left=${leftId}&right=${rightId}`,
};
