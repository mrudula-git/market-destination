import {
  Contacts,
  Listings,
  ListingsAttributes,
  ListingsAttributesGroup,
  ListingsCategories,
  ListingsPackages,
  ListingsPackagesPrice,
  ListingsPlaces,
  Locations,
  Media,
  Reviews,
} from "database";
import Attributes from "../app/[listing_name]/attributes";

export type Attribute = Partial<ListingsAttributes> & {
  value: string;
};

export type Category = Partial<ListingsCategories> & {
  attributes: Partial<Attribute>[];
};

export type AttributeGroup = Partial<ListingsAttributesGroup> & {
  attributes: Partial<Attribute>[];
};

export type Package = Partial<ListingsPackages> & {
  price: Partial<ListingsPackagesPrice>;
};

export type Place = Partial<ListingsPlaces> & {
  location: Partial<Locations>;
};

export type Listing = Partial<Listings> & {
  contacts: Partial<Contacts>;
  photos: Partial<Media>[];
  attributes: Partial<Attribute>[];
  categories: Partial<Category>[];
  attributeGroups: Partial<AttributeGroup>[];

  packages?: Partial<Package>[];
  location?: Partial<Locations>;
  places?: Partial<Place>[];
  reviews?: Partial<Reviews> & {};
};
