const colors = require("tailwindcss/colors");

/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./app/**/*.{js,ts,jsx,tsx}",
    "./pages/**/*.{js,ts,jsx,tsx}",
    "./layouts/**/*.{js,ts,jsx,tsx}",
    "./components/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        base0: colors.white,
        // base0: "#FFF",

        // red 1
        // primary1: "#e31e24",
        // primary2: "#ef7f1a",
        // secondary2: "#e18958",
        // secondary1: "#b37688",

        // red 2
        // primary1: "#e31e24",
        // primary2: "#fa9273",
        // secondary1: "#f39614",

        // green
        // primary1: "#026670",
        // primary2: "#9FEDD7",
        // secondary1: "#FCE181",
        // secondary2: "#FEF9C7",

        section: "#fff7eb",

        // "btn-primary": "#ef7f1a",
        "btn-primary": "#e31e24",

        "link-red": "#e31e24",
        "link-orange": "#ef7f1a",

        highlight: "#ef7f1a",

        // overlay: colors.transparent,
        "overlay-red": "#e31e24",
        "overlay-orange": "#ef7f1a",
        "overlay-blue": "#436c9e",
        "overlay-text": "#026670",

        "theme-red": "#e31e24",
        "theme-orange": "#ef7f1a",
        "theme-black": "#232C33",
        "theme-text-dark": "#232C33",
        "theme-text-light": colors.white,
        //
        // primary1: "#60839E",
        primary1: "#232C33",
        primary2: "#ef7f1a",
        // primary2: "#f5af71",
        // secondary1: "#ef7f1a",
      },
    },
  },
  plugins: [
    require("@tailwindcss/forms"),
    require("tailwindcss-animate"),
    require("tailwindcss-react-aria-components"),
  ],
};
