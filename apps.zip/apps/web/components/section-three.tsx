"use client";

import CardGrid from "./UI/Cards/card-grid";

export default function SectionThree() {
  return (
    <div className="container lg:max-w-screen-md xl:max-w-screen-lg mx-auto">
      <CardGrid />
    </div>
  );
}
