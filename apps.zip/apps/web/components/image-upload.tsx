import React, { useState } from "react";
import { FilePond, registerPlugin } from "react-filepond";
import "filepond/dist/filepond.min.css";
import FilePondPluginImagePreview from "filepond-plugin-image-preview";
import "filepond-plugin-image-preview/dist/filepond-plugin-image-preview.min.css";
import ImageKit from "imagekit";

registerPlugin(FilePondPluginImagePreview);

export const imagekit = new ImageKit({
  publicKey: process.env.NEXT_PUBLIC_IMAGEKIT_PUBLIC_KEY!,
  privateKey: process.env.NEXT_PUBLIC_IMAGEKIT_PRIVATE_KEY!,
  urlEndpoint: process.env.NEXT_PUBLIC_IMAGEKIT_URL_ENDPOINT!,
});

export default function ImageUpload({ onUpload, uploadedImages }) {
  const handleImageChange = (fileItems: any[]) => {
    onUpload(fileItems.map((fileItem: { file: any }) => fileItem.file));
  };

  return (
    <div className="overflow-hidden">
      <FilePond
        className=""
        allowMultiple={true}
        files={uploadedImages}
        onupdatefiles={handleImageChange}
        labelIdle={`<span class="filepond--label-action text-primary1">Drag & Drop your files or Browse</span>`}
      />
    </div>
  );
}
