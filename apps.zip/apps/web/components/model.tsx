import { useEffect, useState } from "react";
import {
  Button,
  Dialog,
  DialogTrigger,
  Heading,
  Modal,
  ModalOverlay,
  ModalContext,
} from "react-aria-components";

interface ModalExampleProps {
  open: boolean;
  children: React.ReactNode;
  onClose: () => void; // Adjust the type of onClose
}

const ModalExample: React.FC<ModalExampleProps> = ({
  open,
  children,
  onClose,
}: any) => {
  let [isOpen, setIsOpen] = useState(open);

  useEffect(() => {
    setIsOpen(open);
  }, [open]);

  const handleClose = () => {
    setIsOpen(false);
    onClose();
  };

  const handleButtonClick = () => {
    // Handle button click logic here
  };

  return (
    <ModalContext.Provider value={{ isOpen, onOpenChange: setIsOpen }}>
      <DialogTrigger>
        <ModalOverlay
          className={({ isEntering, isExiting }) => `
            fixed inset-0 z-50 overflow-x-hidden bg-black/25 flex items-center justify-center p-4 text-center backdrop-blur
            ${isEntering && "animate-in fade-in duration-500 ease-out"}
            ${isExiting && "animate-out fade-out duration-300 ease-out"}
          `}
        >
          <Modal
            className={({ isEntering, isExiting }) => `
              w-4/5 max-w-full overflow-x-hidden h-4/5 rounded-2xl bg-white p-6 align-middle shadow-xl
              ${isEntering && "animate-in slide-in-from-bottom duration-500"}
              ${isExiting && "animate-out slide-out-to-bottom duration-300"}
            `}
          >
            {/* Close button */}
            <div className="absolute top-0 right-0 p-4">
              <Button
                className="bg-white text-black px-4 py-2 rounded-md"
                onPress={handleClose}
              >
                X
              </Button>
            </div>

            <div className="container max-h-full">
              <div className="p-4 overflow-auto">{children}</div>
            </div>
          </Modal>
        </ModalOverlay>
      </DialogTrigger>
    </ModalContext.Provider>
  );
};

export default ModalExample;
