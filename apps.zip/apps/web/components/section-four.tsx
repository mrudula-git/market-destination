"use client";

const data = [
  {
    count: 50,
    description: "Our customer",
  },
  {
    count: 43,
    description: "Locations Covered",
  },
  {
    count: 250,
    description: "Our Patners (Waterparks, Resorts, &amp; Agrotourisum)",
  },
];

export default function SectionFour() {
  return (
    <div className="">
      <br />
      <div className="container mx-auto px-4 relative text-primary1">
        <div className="md:absolute md:top-0 md:inset-4">
          <div className="container lg:max-w-screen-lg mx-auto">
            <div className="grid grid-cols-2 ">
              <div className="col-span-2 sm:col-span-1">
                <h1 className="text-2xl md:text-3xl lg:text-4xl font-bold">
                  Why always trust us?
                </h1>
                <br />
                <p className="">
                  Findigoo isn't just a booking platform; it's a vibrant
                  community for adventure-seekers and relaxation enthusiasts.
                  We're passionate about connecting people with incredible
                  experiences, fostering bonds, and introducing you to new
                  destinations that redefine the perfect getaway. Join us on
                  this journey of exploration and leisure
                </p>
                <div className="grid grid-cols-2 sm:grid-cols-2 gap-4 mt-4">
                  {data.slice(0, 2).map((item, key) => (
                    <div
                      key={key}
                      className="flex flex-col-reverse lg:text-left xs:text-center"
                    >
                      <div>
                        <p className="text-xl md:text-3xl font-black">
                          {item.count}
                        </p>
                        <p>{item.description}</p>
                      </div>
                    </div>
                  ))}
                  <div
                    key={data[2]?.count}
                    className="col-span-2 flex flex-col-reverse lg:text-left xs:text-center"
                  >
                    <div>
                      <p className="text-xl md:text-3xl font-black">
                        {data[2]?.count}
                      </p>
                      <p>{data[2]?.description}</p>
                    </div>
                  </div>
                  <br />
                  <br />
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 align-middle">
          <div></div>
          <div className="relative">
            <div className="absolute inset-0"></div>
            <img
              className="max-h-[32rem] rounded-[32px] object-cover object-center h-full sm:h-[360px] md:h-full aspect-square"
              src="/assets/map.jpg"
              alt=""
            />
          </div>
        </div>
      </div>
      <br />
    </div>
  );
}
