"use client";
const data = [
  {
    count: 354,
    description: "Customer",
  },
  {
    count: 456,
    description: "Our Patners",
  },
  {
    count: 323,
    description: "Lorem ipsum dolor ",
  },
  {
    count: 234,
    description: "Lorem ipsum dolor ",
  },
];

export default function SectionTwo() {
  return (
    <div className="container mx-auto relative lg:my-20 my-14 ">
      <div className="container lg:max-w-screen-md xl:max-w-screen-lg mx-auto px-6 md:mt-0 mt-10">
        <div className="grid grid-flow-col-1 sm:grid-cols-2 gap-8 align-middle">
          <div className="col-span-1">
            <h1 className="font-bold text-black lg:text-5xl md:text-3xl sm:text-6xl">
              Let's visit places you've never tried
            </h1>
            <p className="mt-4">
              Lorem ipsum dolor sit amet consectetur adipisicing elit. Inventore
              laboriosam unde vel. Nam laudantium asperiores voluptatibus dicta
              aut. Incidunt facilis ipsum iure qui ab vero hic sint explicabo ut
              beatae.
            </p>
          </div>
          <div className="col-span-1 top-20 origin-top-left rotate-6 animate-spin overflow-hidden">
            <img className="w-full h-72 " src="/asset/waterpark1.jpg" alt="" />
            <img
              className="w-full h-72 absolute top-10 left-8"
              src="/asset/ice2.jpg"
              alt=""
            />
            <img
              className="w-full h-72 absolute top-20 left-16"
              src="/asset/farm.jpg"
              alt=""
            />
          </div>
        </div>
      </div>
    </div>
  );
}
