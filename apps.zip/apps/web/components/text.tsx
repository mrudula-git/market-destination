const texts =[
    "consectetur", "consectetur", "consectetur"
]

export default texts;