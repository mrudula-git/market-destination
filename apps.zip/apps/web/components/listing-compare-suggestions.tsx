"use client";

import Link from "next/link";
import React, { useMemo } from "react";
import { routes } from "../constants/routes";

function ListingCompareSuggestions({ listing }: any) {
  const storedData = localStorage.getItem("list");
  const storedListings = storedData ? JSON.parse(storedData) : null;

  const filteredListings = useMemo(() => {
    return storedListings
      ? storedListings.filter(
          (storedListing: any) => storedListing.id !== listing.id
        )
      : null;
  }, [listing.id, storedListings]);

  // const displayedListings = filteredListings?.slice(0, 5);

  return (
    <div>
      {/* <pre>{JSON.stringify(filteredListings, null, 2)}</pre> */}
      {filteredListings && filteredListings.length > 0 ? (
        <>
          <p className="font-bold text-xl py-2">Compare these listings:</p>
          <div className="flex flex-wrap gap-3">
            {filteredListings
              .slice(0, 5)
              .map((filteredListing: any, index: any) => (
                <Link
                  key={index}
                  className="text-sm font-medium hover:underline border border-btn-primary text-btn-primary rounded-full py-2 px-6"
                  href={
                    filteredListing.id
                      ? routes.compareLeftRight(listing.id, filteredListing.id)
                      : routes.compareLeft(listing.id)
                  }
                  target="_blank"
                >
                  Compare with {filteredListing.name}
                </Link>
              ))}
          </div>
        </>
      ) : (
        <div className="pt-3 ">
          <Link
            className="font-semibold hover:underline border border-primary1 rounded-full py-2 px-6 "
            href={routes.compareLeft(listing.id)}
          >
            Compare with other listings
          </Link>
        </div>
      )}
    </div>
  );
}

export default ListingCompareSuggestions;
