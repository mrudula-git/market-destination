// CheckboxPopup.tsx

import React from "react";

interface CheckboxPopupProps {
  options: string[];
  onClose: () => void;
}

const CheckboxPopup: React.FC<CheckboxPopupProps> = ({ options, onClose }) => {
    console.log(options);
    
  return (
    <div className="fixed top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 bg-white p-6 rounded-md shadow-lg">
      <div className="mb-4">
        {options.map((option, index) => (
          <div key={index} className="flex items-center mb-2">
            <input
              type="checkbox"
              id={`popup-${index}`}
              name={`popup-${index}`}
              className="mr-2 form-checkbox h-5 w-5 text-black-600 border-gray-300 rounded focus:text-black"
            />
            <label htmlFor={`popup-${index}`}>{option}</label>
          </div>
        ))}
      </div>
      <button onClick={onClose} className="bg-blue-500 text-white py-2 px-4 rounded-md">
        Close
      </button>
    </div>
  );
};

export default CheckboxPopup;
