import HeroMedia from "./hero-media";

export default function Sectionexample() {
  return (
    <div>
      <div className="container mx-auto relative">
        <div className="grid grid-cols-1 sm:grid-cols-2">
          {/* <div className="col-span-1"></div> */}
          {/* <div className="col-span-1"> */}
          <HeroMedia />
          <div className="absolute top-20 left-72 inset-x-0">
            <div className="container lg:max-w-screen-sm xl:max-w-screen-sm mx-auto">
              <HeroMedia />
            </div>
          </div>
          {/* </div> */}
        </div>
      </div>
    </div>
  );
}
