"use client";

import { useRouter, useSearchParams } from "next/navigation";
import { useSeachStore } from "../stores/zustand/search.store";
import type { ListingTypes, Listings } from "database";
import apiKit from "../utils/api/helper";
import { apis } from "../constants/apis";
import { useEffect } from "react";
import { Icon } from "@iconify/react";

export default function SearchField() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const { query, setQuery, setListings, setAvailableFilters } = useSeachStore();

  useEffect(() => {
    setQuery(searchParams.get("query"));
  }, [searchParams]);

  async function getListings() {
    const body = {
      query,
      filter: {},
    };

    setListings([]);
    const data = await apiKit({
      method: "POST",
      api: apis.search,
      body,
    });

    const listings = data.listings;
    if (!listings) return;
    setListings(listings);

    // const listingTypes: ListingTypes[] = listings
    //   .map((el) => el.types as ListingTypes[])
    //   .flat();

    // const listingTypeUniques = listingTypes.reduce(
    //   (prev: ListingTypes[], el) => {
    //     const fi = prev.findIndex((p) => p.id === el.id);
    //     if (fi < 0) return [...prev, { ...el, count: 1 }];
    //     else {
    //       prev[fi]["count"] += 1;
    //       return [...prev];
    //     }
    //   },
    //   []
    // ) as ListingTypes[];
    // console.log(listingTypeUniques);
    // setAvailableFilters({ type: listingTypeUniques });
  }

  function search() {
    let params = Object.fromEntries(searchParams);
    params["query"] = query;
    if (query) params = { query: query, ...params }; // just to keep query first
    const qs = new URLSearchParams(params).toString();
    const nextUrl = `${apis.search}?${qs.toString()}`;
    router.push(nextUrl);
  }

  return (
    <div className="">
      <form
        className="group flex items-center p-1.5 border border-theme-red shadow shadow-theme-orange focus-within:shadow-theme-orange focus-within:shadow-md bg-base0 rounded-full transition-all"
        onSubmit={(event) => {
          event.preventDefault();
          search();
        }}
      >
        <input
          className="flex-grow px-6 border-0 rounded-full bg-base0 focus:outline-none focus:ring-0 transition-colors"
          placeholder="Search..."
          value={query}
          onChange={(e) => {
            setQuery(e.target.value);
          }}
        />
        <button
          className="p-3 md:p-2 md:px-4 inline-flex items-center gap-2 rounded-full bg-primary1 text-base0"
          type="submit"
        >
          <Icon icon={"fe:search"} />
          <span className="hidden md:inline font-semibold">Search</span>
        </button>
      </form>
    </div>
  );
}
