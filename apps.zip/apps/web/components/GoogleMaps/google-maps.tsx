"use client";

import {
  GoogleMap,
  Marker,
  MarkerF,
  useLoadScript,
} from "@react-google-maps/api";
import { useMemo, useRef } from "react";
// import listings from "../../sample-data/listings.json";
import type { Listings } from "database";

const MAP_CENTER_OFFSET = 350;

const center = {
  lat: 18.5204303,
  lng: 73.8567437,
};

type GoogleMapsProps = {
  listings: Listings[];
};

export default function GoogleMaps({ listings }: GoogleMapsProps) {
  const googleMapsRef = useRef(null);

  const { isLoaded } = useLoadScript({
    googleMapsApiKey: process.env.NEXT_PUBLIC_GOOGLE_MAPS_KEY as string,
  });

  const computedCenter = useMemo(() => {
    return center;
  }, []);

  const mapMarkers = useMemo(() => {
    const markers = listings?
      .map((listing) => {
        if (listing.location) {
          const { location } = listing;
          const { lat, lng } = location;
          if (lat && lng) return listing;
          return null;
        } else return null;
      })
      .filter((el) => el !== null);
    return markers;
  }, [listings]);

  return (
    <>
      {isLoaded ? (
        <GoogleMap
          // center={computedCenter}
          mapContainerStyle={{ width: "100%", height: "100%" }}
          options={{
            scrollwheel: true,
            gestureHandling: "greedy",
            zoomControl: true,
            scaleControl: true,
            mapTypeControl: false,
            fullscreenControl: false,
            streetViewControl: false,
            // zoomControlOptions: {
            //   position: window.google.maps.ControlPosition.TOP_RIGHT,
            // },
            // fullscreenControlOptions: {
            //   position: window.google.maps.ControlPosition.TOP_LEFT,
            // },
          }}
          ref={googleMapsRef}
          onLoad={(map) => {
            // console.log({ listings, mapMarkers });
            const bounds = new window.google.maps.LatLngBounds();
            mapMarkers?.forEach((listing) => {
              bounds.extend({
                lat: parseFloat(listing?.location?.lat),
                lng: parseFloat(listing?.location?.lng),
              });
            });

            const padding = 100;
            map.fitBounds(bounds, {
              top: padding,
              bottom: padding,
              left: padding + MAP_CENTER_OFFSET,
              right: padding,
            });
          }}
        >
          {mapMarkers?.map((listing) => (
            <MarkerF
              key={listing.locationsId}
              position={{
                lat: parseFloat(listing?.location?.lat),
                lng: parseFloat(listing?.location?.lng),
              }}
            />
          ))}
        </GoogleMap>
      ) : null}
    </>
  );
}
