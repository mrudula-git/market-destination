"use client";

import { GoogleMap, MarkerF, useLoadScript } from "@react-google-maps/api";
import { useMemo, useRef } from "react";
import type { Listings } from "database";

type ListingMapProps = {
  listing?: Listings;
  center?: { lat: number; lng: number };
};

export default function ListingMap({ listing, center }: ListingMapProps) {
  const googleMapsRef = useRef(null);

  const { isLoaded } = useLoadScript({
    googleMapsApiKey: process.env.NEXT_PUBLIC_GOOGLE_MAPS_KEY as string,
  });

  const computedCenter = useMemo(() => {
    return center;
  }, []);

  return (
    <>
      {isLoaded ? (
        <GoogleMap
          center={computedCenter}
          mapContainerStyle={{ width: "100%", height: "100%" }}
          options={{
            // scrollwheel: true,
            // gestureHandling: "greedy",
            zoomControl: false,
            scaleControl: false,
            mapTypeControl: false,
            fullscreenControl: false,
            streetViewControl: false,
          }}
          ref={googleMapsRef}
          zoom={14}
          onLoad={(map) => {}}
        >
          <MarkerF
            position={{
              lat: parseFloat(center?.lat),
              lng: parseFloat(center?.lng),
            }}
          />
        </GoogleMap>
      ) : null}
    </>
  );
}
