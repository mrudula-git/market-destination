"use client";

import { useEffect, useState } from "react";
import { motion } from "framer-motion";

const texts = ["Waterparks", "Resorts", "Agro Tourism", "Farmhouses"];

export default function HeroMedia() {
  const images = [
    "/assets/waterpark.webp",
    "/assets/resort.webp",
    "/assets/agro-tourism.webp",
    "/assets/farmhouse.webp",
  ];

  const [index, setIndex] = useState(0);

  const incrementIndex = () => {
    setIndex((prevIndex) => (prevIndex + 1) % texts.length);
  };

  useEffect(() => {
    const timer = setInterval(incrementIndex, 3000);
    return () => clearInterval(timer);
  }, []);

  const imageVariants = {
    hidden: { opacity: 0, x: "100%" },
    visible: { opacity: 1, x: 0 },
    exit: { opacity: 0, x: "-100%" },
  };

  return (
    <div className="realative overflow-hidden rounded-none md:rounded-s-3xl h-[420px] sm:h-[512px]">
      <div className="absolute inset-0 z-10 bg-base0 opacity-75 md:opacity-50"></div>
      <motion.img
        className="h-full w-full -z-10 object-cover"
        src={images[index]!}
        key={index}
        initial="hidden"
        animate="visible"
        exit="exit"
        variants={imageVariants}
        transition={{ duration: 0.5 }}
      />
    </div>
  );
}
