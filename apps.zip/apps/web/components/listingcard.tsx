function Listingcard() {
  return null;
}

export default Listingcard;
