import type { ReactNode } from "react";
import { useState, useEffect } from "react";
import { Icon } from "@iconify/react";
import {
  DialogTrigger,
  Modal as RACModal,
  ModalOverlay,
  ModalContext,
} from "react-aria-components";

interface ModalProps {
  open: boolean;
  onClose: () => void;
  children: ReactNode;
}

export default function Modal({
  open,
  onClose,
  children,
}: ModalProps): JSX.Element {
  const [isOpen, setIsOpen] = useState(open);
  const [modalDivHeight, setModalDivHeight] = useState(0);

  useEffect(() => {
    setIsOpen(open);
  }, [open]);

  useEffect(() => {
    const modalDiv = document.querySelector(".modal-div");
    const closeIcon = document.querySelector(".close");
    const modalChild = document.querySelector(".modal-child");

    if (modalDiv && closeIcon && modalChild) {
      const modalDivHeight = modalDiv.offsetHeight;
      const closeIconHeight = closeIcon.offsetHeight;
      const modalChildHeight = modalChild.offsetHeight;

      // console.log("Modal div height:", modalDivHeight);
      // console.log("Close icon height:", closeIconHeight);
      // console.log("Modal child height:", modalChildHeight);

      const remainingHeight =
        modalDivHeight - closeIconHeight - modalChildHeight;
      // console.log("Remaining height:", remainingHeight);

      setModalDivHeight(remainingHeight);
    } else {
      console.log("One or more elements not found.");
    }
  }, [isOpen]);

  function handleClose() {
    setIsOpen(false);
    onClose();
  }

  return (
    <ModalContext.Provider value={{ isOpen }}>
      <DialogTrigger>
        <ModalOverlay
          className={({ isEntering, isExiting }) => `
            fixed inset-0 z-30 bg-black/25 flex items-center justify-center backdrop-blur
            ${isEntering && "animate-in duration-800 ease-in"}
            ${isExiting && "animate-out duration-300 ease-out"}
          `}
        >
          <RACModal
            className={({ isEntering, isExiting }) => `
              max-w-screen-md w-full h-[96vh]  md:max-h-[768px] rounded-2xl bg-base0 overflow-hidden
              ${isEntering && "animate-in slide-in-from-bottom duration-800"}
              ${isExiting && "animate-out slide-out-to-bottom duration-300"}
            `}
          >
            <div className="modal-div flex flex-col h-full overflow-hidden">
              <div className="sticky top-0 p-6 pb-2 bg-base0 close">
                <div className="text-end">
                  <button
                    className="bg-base0 text-primary1 rounded-md"
                    onClick={handleClose}
                    type="button"
                  >
                    <Icon className="w-6 h-6" icon="carbon:close-outline" />
                  </button>
                </div>
              </div>

              <div className="flex-grow px-4 md:px-8 overflow-y-auto scrollbar-hide ">
                {children}
              </div>
            </div>
          </RACModal>
        </ModalOverlay>
      </DialogTrigger>
    </ModalContext.Provider>
  );
}
