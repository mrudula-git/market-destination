import React, { useState } from "react";
import { Icon } from "@iconify/react";
import { Carousel } from "flowbite-react";
import Modal from "../Modals/modal";

const SwiperComponent = ({ images }) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedImage, setSelectedImage] = useState("");

  const openModal = (imageUrl) => {
    setSelectedImage(imageUrl);
    setIsModalOpen(true);
  };

  const closeModal = () => {
    setIsModalOpen(false);
  };

  const iconLeft = (
    <Icon
      className="rounded-full text-white bg-primary1"
      icon="material-symbols:arrow-circle-left"
    />
  );

  const iconRight = (
    <Icon
      className="rounded-full text-white bg-primary1"
      icon="material-symbols:arrow-circle-right"
    />
  );

  return (
    <>
      <div className="flex gap-1 md:gap-3 lg:gap-3">
        {images.slice(0, 5).map((media, index) => (
          <img
            key={media.id}
            src={media.url}
            className="swiper-image"
            onClick={() => openModal(media.url)}
          />
        ))}
      </div>
      <Modal open={isModalOpen} onClose={closeModal}>
        <div className="h-[80vh]">
          <Carousel
            pauseOnHover
            leftControl={iconLeft}
            rightControl={iconRight}
          >
            {[selectedImage, ...images].map((media, index) => (
              <img
                key={index}
                src={media.url || selectedImage}
                className="overflow-hidden object-contain image-size"
              />
            ))}
          </Carousel>
        </div>
      </Modal>
    </>
  );
};

export default SwiperComponent;
