"use client";

import { useEffect } from "react";
import { twMerge } from "tailwind-merge";
import { usePathname, useSearchParams } from "next/navigation";
import { useIndicatorsStore } from "../../../stores/zustand/indicators.store";

export default function LoadingIndicator() {
  const pathname = usePathname();
  const searchParams = useSearchParams();
  const { pageLoading, setPageLoading } = useIndicatorsStore();

  useEffect(() => {
    // console.log("stop");
    if (pageLoading) setPageLoading(false);

    return () => {
      // console.log("start");
    };
  }, [pathname, searchParams]);

  return (
    <div className="fixed top-0 z-40 w-full">
      <div
        className={twMerge(
          "h-1 w-full overflow-hidden absolute bg-transparent transition-colors",
          pageLoading ? "bar bg-primary2" : ""
        )}
      >
        <div></div>
      </div>
    </div>
  );
}
