"use client";
import { useRouter, useSearchParams } from "next/navigation";
import React, { useState } from "react";

let LISTINGS_PER_PAGE = 12;

function Pagination({ listings, count }: any) {
  const searchParams = useSearchParams();
  let pageParam = searchParams.get("page");

  let router = useRouter();

  const totalPages = Math.ceil(count / LISTINGS_PER_PAGE);
  const [currentPage, setCurrentPage] = useState(+pageParam! || 1);

  const startIndex = (currentPage - 1) * LISTINGS_PER_PAGE;
  const endIndex = startIndex + LISTINGS_PER_PAGE;

  const visibleListings = listings?.slice(startIndex, endIndex);

  const handlePageChange = (pageNumber: number) => {
    if (count < LISTINGS_PER_PAGE) {
      setCurrentPage(1);
      const newUrl = `${window.location.pathname}`;
      router.push(newUrl);
    } else {
      setCurrentPage(pageNumber);
      const existingParams = new URLSearchParams(window.location.search);
      existingParams.set("page", pageNumber.toString());
      const newUrl = `${window.location.pathname}?${existingParams.toString()}`;
      router.push(newUrl);
    }
  };

  return (
    <div className="text-primary1">
      {listings?.length > 0 && (
        <div className="mx-auto">
          <nav
            aria-label="Page navigation example "
            className="flex justify-center items-center"
          >
            <ul className="flex items-center gap-2 text-sm">
              <li>
                <button
                  onClick={() => handlePageChange(Math.max(currentPage - 1, 1))}
                  className={`flex items-center justify-center px-4 py-1.5 rounded-full border border-transparent ${
                    currentPage === 1
                      ? "text-primary1 cursor-not-allowed"
                      : "hover:underline hover:border-primary1"
                  }`}
                  disabled={currentPage === 1}
                >
                  Previous
                </button>
              </li>
              {Array.from({ length: totalPages }).map((_, pageIndex) => (
                <li key={pageIndex}>
                  <button
                    onClick={() => handlePageChange(pageIndex + 1)}
                    className={`w-8 h-8 rounded-full border border-transparent ${
                      pageIndex + 1 === currentPage
                        ? "border-primary1 bg-primary1 text-base0"
                        : "border border-transparent hover:border-primary1 hover:underline"
                    }`}
                  >
                    {pageIndex + 1}
                  </button>
                </li>
              ))}
              <li>
                <button
                  onClick={() =>
                    handlePageChange(Math.min(currentPage + 1, totalPages))
                  }
                  className={`flex items-center justify-center px-4 py-1.5 rounded-full border border-transparent ${
                    currentPage === totalPages
                      ? "text-primary1 cursor-not-allowed"
                      : "hover:underline hover:border-primary1"
                  }`}
                  disabled={currentPage === totalPages}
                >
                  Next
                </button>
              </li>
            </ul>
          </nav>
        </div>
      )}
    </div>
  );
}

export default Pagination;
