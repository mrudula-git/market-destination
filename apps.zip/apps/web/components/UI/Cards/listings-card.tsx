"use client";

import { Icon } from "@iconify/react";
import type { Contacts, Listings, Media } from "database";
import Link from "next/link";
import { twMerge } from "tailwind-merge";
import { useIndicatorsStore } from "../../../stores/zustand/indicators.store";
// import { ErrorBoundary } from "react-error-boundary";

type ListingCardProps = {
  listing: Listings & { contacts: Partial<Contacts>; photos: Media[] };
};

const cardVariants = {
  hidden: {
    opacity: 0,
    scale: 0.8,
  },
  visible: {
    opacity: 1,
    scale: 1,
    transition: {
      duration: 0.5,
    },
  },
  hover: {
    scale: 1.05,
    transition: {
      duration: 0.3,
    },
  },
};

export default function ListingsCard({ listing }: ListingCardProps) {
  const { setPageLoading } = useIndicatorsStore();

  // const listingSummary = reviewSummary.find(
  //   (summary) => summary._id === listing.id
  // );

  return (
    <div className="group mb-6 text-primary1 p-3 rounded-xl hover:bg-highlight hover:text-white hover:shadow hover:shadow-primary2 transition-all">
      <Link
        href={`${listing.slug}`}
        onClick={() => {
          setPageLoading(true);
        }}
      >
        <div className="cursor-pointer mb-2">
          {listing.photos?.[0]?.url ? (
            <img
              className="rounded-lg w-full aspect-square object-cover"
              src={listing.photos?.[0]?.url}
              alt=""
            />
          ) : (
            <img
              className="rounded-lg w-full aspect-square object-cover"
              src="/favicon.ico"
              alt=""
            />
          )}
        </div>
        <div className="flex justify-between items-baseline">
          <p className="text-sm">
            {listing.contacts.city}, {listing.contacts.state}{" "}
            {listing.contacts.pinCode}
          </p>
          {listing?.reviews ? (
            <>
              {listing?.reviews?.avgRatingValue && (
                <div className="flex px-1.5 pt-0.5 bg-primary1 text-base0 group-hover:bg-base0 group-hover:text-overlay-orange rounded items-baseline gap-2 transition-all">
                  <Icon
                    strokeWidth={1.5}
                    icon="streamline:interface-favorite-star-reward-rating-rate-social-star-media-favorite-like-stars"
                  />
                  <span className="flex items-baseline">
                    <span className="font-semibold">
                      {listing?.reviews?.avgRatingValue.toFixed(1)}
                    </span>
                    <span className="ml-1 text-xs font-thin">
                      ({listing?.reviews?.countRatingValue})
                    </span>
                  </span>
                </div>
              )}
            </>
          ) : null}
        </div>
        <h1
          className={twMerge(
            "text-lg md:text-sm lg:text-lg font-semibold",
            "cursor-pointer",
            "leading-5"
          )}
        >
          {listing.name}
        </h1>
        <div className="text-sm font-light text-justify">
          {/* <pre>{JSON.stringify(listing.contacts, null, 2)}</pre> */}
          {/* <p className="">{listing.description}</p> */}
          <p className="">{listing.contacts.address}</p>
        </div>
      </Link>
    </div>
  );
}
