"use client";
import { Reviews } from "database";
import { formatDistance } from "date-fns";
import { useState } from "react";
import Rating from "../../../app/[listing_name]/reviews-details/rating";
import SwiperComponent from "../Swiper/swipercomponent";

type ReviewCardProps = Partial<Reviews> & {
  details: {
    cleanlinessRating: number;
    comfortRating: number;
    valueRating: number;
    servicesRating: number;
  };
  photos: {
    id: string;
    url: string;
    thumbUrl: string;
  }[];
  reviewer: {
    name: string;
    verified: boolean;
  };
  ratings?: boolean;
};

export default function ReviewCard({
  ratingValue,
  title,
  content,
  details,
  reviewer,
  photos,
  createdAt,
  ratings = false,
}: ReviewCardProps) {
  const [showMoreText, setShowMoreText] = useState(false);

  const result = formatDistance(new Date(createdAt), new Date(), {
    addSuffix: true,
  });

  const toggleMoreText = () => {
    setShowMoreText(!showMoreText);
  };

  const truncatedContent = showMoreText ? content : content?.slice(0, 150);
  return (
    <div className="p-2 md:p-4 border-2 border-theme-orange hover:border-theme-orange rounded-lg hover:shadow hover:shadow-theme-orange mb-2 transition-all">
      <div className="mb-3">
        <Rating value={ratingValue} />
      </div>

      <div className="mb-2 flex items-center gap-3">
        <img
          alt={`...`}
          className="w-12 h-12 rounded-full"
          src="https://via.placeholder.com/64"
        />
        <div>
          <div className="text-sm">
            <span className="font-semibold">{reviewer?.name}</span>,{" "}
            <span className="">says</span>
          </div>
          <p className="font-bold">{title}</p>
          <p className="text-sm">{result}</p>
        </div>
      </div>
      <p className="mb-2 text-sm md:text-base break-words">
        {truncatedContent}
        {content.length > 150 && (
          <button
            className="text-primary1 font-semibold hover:underline cursor-pointer"
            onClick={toggleMoreText}
          >
            {showMoreText ? "...Show less" : "...Show more"}
          </button>
        )}
      </p>
      {photos && photos.length > 0 && <SwiperComponent images={photos} />}
      {ratings ? (
        <div className="text-xs grid grid-cols-2">
          {details.cleanlinessRating ? (
            <div className="flex gap-3">
              <div>Cleanliness</div>
              <Rating value={details.cleanlinessRating} />
            </div>
          ) : null}
          {details.comfortRating ? (
            <div className="flex gap-3">
              <div>Comfort</div>
              <Rating value={details.comfortRating} />
            </div>
          ) : null}
          {details.valueRating ? (
            <div className="flex gap-3">
              <div>Value</div>
              <Rating value={details.valueRating} />
            </div>
          ) : null}
          {details.servicesRating ? (
            <div className="flex gap-3">
              <div>Services</div>
              <Rating value={details.servicesRating} />
            </div>
          ) : null}
        </div>
      ) : null}
    </div>
  );
}
