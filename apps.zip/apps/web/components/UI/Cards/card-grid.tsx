"use client";

import { AnimatePresence, motion } from "framer-motion";
import { Icon } from "@iconify/react";
import Link from "next/link";
import { useIndicatorsStore } from "../../../stores/zustand/indicators.store";
import {
  categoriesData,
  generateQSforCategories,
} from "../../Sections/Navigation/navigation-links";

const cardVariants = {
  hidden: {
    opacity: 0,
    scale: 0.8,
  },
  visible: {
    opacity: 1,
    scale: 1,
    transition: {
      duration: 0.25,
    },
  },
  hover: {
    scale: 1.05,
    transition: {
      duration: 0.1,
    },
  },
};

export default function CardGrid({ categories, reviewSummary }) {
  const { setPageLoading } = useIndicatorsStore();

  // console.log(categories, reviewSummary);

  return (
    <div className="text-primary1">
      <h1 className="text-2xl md:text-3xl lg:text-4xl font-bold text-center">
        Find your destinations
      </h1>
      <br />
      <br />
      {/* <pre>{JSON.stringify(listings, null, 2)}</pre> */}

      {categories?.map((category) => (
        <div key={category.id} className="px-8 lg:px-4">
          <div className="flex justify-between">
            <h2 className="text-2xl font-black">{category.name}</h2>
            <a
              className="cursor-pointer hover:underline bg-btn-primary font-semibold text-base0 py-2 px-5 rounded-full hover:opacity-90"
              href={
                links.find((l) =>
                  category.name.toLowerCase().startsWith(l.term)
                )?.href
              }
              onClick={() => {
                setPageLoading(true);
              }}
            >
              <span className="inline-flex text-center align-middle justify-center">
                <span>More</span>
                <svg
                  height="22"
                  width="22"
                  viewBox="0 0 512 512"
                  className="ml-2"
                >
                  <g fill="none" stroke="#fff" strokeWidth="32">
                    <path
                      d="m64 256c0 106 86 192 192 192s192-86 192-192-86-192-192-192-192 86-192 192z"
                      strokeMiterlimit="10"
                    />
                    <path
                      d="m216 352 96-96-96-96"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    />
                  </g>
                </svg>
              </span>
            </a>
          </div>
          <br />
          <motion.div
            animate="visible"
            className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-x-6 gap-y-20 mb-10"
            initial="hidden"
          >
            <AnimatePresence>
              {category.listings?.map((listing) => (
                <div key={listing.id}>
                  <Link
                    className="relative block cursor-pointer"
                    key={listing.id}
                    href={`/${listing.slug}`}
                    onClick={() => {
                      console.log("loading start");
                      setPageLoading(true);
                    }}
                  >
                    {/* <p>{listing.id}</p> */}
                    {listing.photos?.[0]?.url ? (
                      <Card image={listing?.photos?.[0].url} />
                    ) : (
                      <Card image="/favicon.ico" />
                    )}
                    <div className="absolute -bottom-4 inset-x-0 z-10">
                      <div className="w-[96%] h-16 mx-auto">
                        <CardRating
                          listing={listing}
                          reviewSummary={reviewSummary}
                        />
                      </div>
                    </div>
                  </Link>
                </div>
              ))}
            </AnimatePresence>
          </motion.div>
          <br />
          <br />
          <br />
        </div>
      ))}
    </div>
  );
}

function CardRating({ listing, reviewSummary }: any) {
  // console.log(listing.slug);
  reviewSummary = reviewSummary.find(
    (summary: any) => summary._id === listing.id
  );

  return (
    <div>
      <motion.div
        animate="visible"
        className="p-2 rounded-lg bg-opacity-75 bg-gradient-to-b from-overlay-orange to-overlay-red text-white backdrop-blur-lg min-h-20"
        initial="hidden"
        variants={cardVariants}
        whileHover="hover"
      >
        <h3 className="text-xl lg:text-xl font-black">{listing.name}</h3>
        <div className="flex justify-between items-baseline">
          <div></div>

          {!isNaN(reviewSummary?.avgRatingValue) && (
            <div className="flex px-1.5 pt-0.5 rounded bg-base0 text-overlay-orange items-baseline gap-2">
              {/* <ErrorBoundary fallback={<span>Star</span>}> */}
              <Icon
                strokeWidth={1.5}
                icon="streamline:interface-favorite-star-reward-rating-rate-social-star-media-favorite-like-stars"
              />
              {/* </ErrorBoundary> */}
              <span className="flex items-baseline">
                <span className="font-semibold">
                  {reviewSummary?.avgRatingValue !== undefined
                    ? reviewSummary.avgRatingValue.toFixed(1)
                    : ""}
                </span>
                <span className="ml-1 text-xs font-thin">
                  ({reviewSummary?.countRatingValue || ""})
                </span>
              </span>
            </div>
          )}
        </div>
      </motion.div>
    </div>
  );
}

function Card({ image }: { image: string }) {
  return (
    <motion.div
      animate="visible"
      className="h-full"
      initial="hidden"
      variants={cardVariants}
      whileHover="hover"
    >
      <img
        alt=""
        className="rounded-t-full rounded-b inset-y-0 w-full aspect-square object-center object-cover"
        src={image}
      />
    </motion.div>
  );
}

const links = [
  { term: "waterparks", href: generateQSforCategories("waterparks") },
  { term: "resorts", href: generateQSforCategories("resorts") },
  { term: "agro tourism", href: generateQSforCategories("agro tourism") },
  { term: "farmhouse", href: generateQSforCategories("farmhouse") },
];

const desiredOrder = links.map(({ term }) => term);
