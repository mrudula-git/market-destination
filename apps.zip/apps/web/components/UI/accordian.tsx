const AccordionItem: React.FC<{
  title: string;
  bodyId: string;
  children: React.ReactNode;
  onToggle: () => void;
}> = ({ title, bodyId, children, onToggle }) => (
  <>
    <h2
      className="font-semibold bg-gray-300 p-2 w-full sticky left-0"
      style={{ zIndex: 10 }}
    >
      <button
        className="w-full text-left"
        type="button"
        data-accordion-target={`#${bodyId}`}
        aria-expanded="false"
        aria-controls={bodyId}
        onClick={onToggle}
      >
        {title}
      </button>
    </h2>
    <div id={bodyId} className="hidden" aria-labelledby={`#${title}`}>
      {children}
    </div>
  </>
);
export default AccordionItem;
