"use client";

import { useRouter } from "next/navigation";
import { FaArrowLeft } from "react-icons/fa";

export default function Backbutton() {
  const router = useRouter();

  function handleClick() {
    const previousUrl = document.referrer;
    router.push(previousUrl);
  }

  return (
    <button
      type="button"
      onClick={handleClick}
      className="p-2 rounded-full hover:bg-primary2 focus:outline-none"
    >
      <FaArrowLeft className="text-xl" />
    </button>
  );
}
