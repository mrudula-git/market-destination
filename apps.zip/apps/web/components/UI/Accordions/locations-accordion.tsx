"use client";

import { useSearchParams } from "next/navigation";
import { useEffect, useState } from "react";
import { useSearchFiltersStore } from "../../../stores/zustand/search-filters.store";

type LocationsAccordionProps = {
  initialState?: any;
  onSelectionChange?: (value: any) => void;
};

const staticLocations = [
  "Mumbai",
  "Pune",
  "Lonavala",
  "Mahabaleshwar",
  "Matheran",
  "Alibag",
  "Panchgani",
  "Nashik",
  "Khandala",
  "Aurangabad",
];

export default function LocationsAccordion({
  initialState,
  onSelectionChange,
}: LocationsAccordionProps): JSX.Element {
  const searchParams = useSearchParams();
  const filterData = searchParams.get("data");

  let { locationCities } = useSearchFiltersStore();

  const [locationsList, setLocationsList] = useState<string[]>([]);
  const [locations, setLocations] = useState<string[]>(initialState);

  useEffect(() => {
    console.log({ locationCities, staticLocations });
    const _locations = Array.from(
      new Set([...locationCities, ...staticLocations])
    );
    setLocationsList(_locations);
  }, [locationCities]);

  useEffect(() => {
    if (!filterData) return;

    let appliedFilters = JSON.parse(decodeURIComponent(filterData));
    setLocations(appliedFilters.locations);
  }, [filterData]);

  useEffect(() => {
    if (onSelectionChange) onSelectionChange(locations);
  }, [locations]);

  return (
    <div>
      <h4 className="font-semibold mb-2">Locations</h4>
      {/* <pre>{JSON.stringify(locationCities, null, 2)}</pre> */}
      <ul>
        {locationsList.map((item, key) => (
          <li key={key} className="flex items-center gap-2 py-0.5">
            <input
              id={`location-key-${key}`}
              type="checkbox"
              className="form-checkbox h-3.5 w-3.5 border-1 rounded-sm bg-base0 text-theme-red focus:ring-theme-red"
              checked={locations.includes(item)}
              onChange={(event) => {
                if (event.target.checked) {
                  setLocations([...locations, item]);
                } else {
                  setLocations(
                    locations.filter((location) => location !== item)
                  );
                }
              }}
            />
            <label
              htmlFor={`location-key-${key}`}
              className="text-sm font-medium pl-2"
            >
              {item}
            </label>
          </li>
        ))}
      </ul>
    </div>
  );
}
