"use client";

import type { ListingsAttributes, ListingsAttributesGroup } from "database";
import { useMemo } from "react";

type WaterparksAccordionProps = {
  category: Partial<ListingsAttributesGroup>;
  attributes: (Partial<ListingsAttributes> & { value: any })[];
};

export default function WaterparksAccordion({
  category,
  attributes,
}: WaterparksAccordionProps) {
  // console.log(attributesGroup);

  const waterparksAttributes = useMemo(() => {
    return attributes.filter(
      (attribute) => category.attributesId?.includes(attribute.id)
    );
  }, []);

  return (
    <div>
      <h3 className="text-xl font-semibold">{category.name}</h3>
      <br />

      <div>
        {/* <pre>{JSON.stringify(waterparksAttributes, null, 2)}</pre> */}
        {waterparksAttributes.map((attribute) => (
          <div className="my-3 flex justify-between items-center">
            {attribute.type === "boolean" && attribute.value === true ? (
              <>
                <div className="flex items-center gap-2">
                  {attribute.iconUrl ? (
                    <img
                      className="w-6 h-6"
                      src={attribute.iconUrl || ""}
                      alt=""
                    />
                  ) : (
                    <div className="w-6 h-6"></div>
                  )}
                  <p className="">{attribute.name}</p>
                </div>
                {/* <p className="">{attribute.value}</p> */}
              </>
            ) : null}
            <div></div>
          </div>
        ))}
      </div>
      <hr />
    </div>
  );
}
