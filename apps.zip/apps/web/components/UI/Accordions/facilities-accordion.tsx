"use client";

import type { ListingsAttributes, ListingsAttributesGroup } from "database";
import { useMemo } from "react";

type FacilitiesAccordionProps = {
  attributesGroup: Partial<ListingsAttributesGroup>;
  attributes: (Partial<ListingsAttributes> & { value: any })[];
};

export default function FacilitiesAccordion({
  attributesGroup,
  attributes,
}: FacilitiesAccordionProps) {
  // console.log(attributesGroup);

  const facilitiesAttributes = useMemo(() => {
    return attributes.filter(
      (attribute) => attributesGroup.attributesId?.includes(attribute.id)
    );
  }, []);

  return (
    <div>
      <h3 className="text-xl font-semibold">{attributesGroup.name}</h3>
      <br />

      <div>
        {/* <pre>{JSON.stringify(facilitiesAttributes, null, 2)}</pre> */}
        {facilitiesAttributes.map((attribute) => (
          <div className="my-3 flex justify-between items-center">
            {attribute.type === "boolean" && attribute.value === true ? (
              <>
                <div className="flex items-center gap-2">
                  {attribute.iconUrl ? (
                    <img
                      className="w-6 h-6"
                      src={attribute.iconUrl || ""}
                      alt=""
                    />
                  ) : (
                    <div className="w-6 h-6"></div>
                  )}
                  <p className="">{attribute.name}</p>
                </div>
                {/* <p className="">{attribute.value}</p> */}
              </>
            ) : null}
            <div></div>
          </div>
        ))}
      </div>
      <hr />
    </div>
  );
}
