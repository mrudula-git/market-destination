"use client";

import { useSearchParams } from "next/navigation";
import { useEffect, useState } from "react";
import { Icon } from "@iconify/react";

type ReviwsFilterAccordionProps = {
  initialState?: any;
  onSelectionChange?: (value: any) => void;
};

export default function ReviwsFilterAccordion({
  initialState,
  onSelectionChange,
}: ReviwsFilterAccordionProps): JSX.Element {
  const searchParams = useSearchParams();
  const filterData = searchParams.get("data");

  // const { locationCities } = useSearchFiltersStore();

  const [review, serReview] = useState<string>(initialState);

  useEffect(() => {
    if (!filterData) return;

    let appliedFilters = JSON.parse(decodeURIComponent(filterData));
    serReview(appliedFilters.reviews);
  }, [filterData]);

  useEffect(() => {
    if (onSelectionChange) onSelectionChange(review);
  }, [review]);

  return (
    <div>
      <h4 className="font-semibold mb-2">Reviews</h4>
      {/* <pre>{JSON.stringify(locationCities, null, 2)}</pre> */}
      <ul>
        {[1, 2, 3, 4].map((item, key) => (
          <li key={key} className="flex items-center gap-2 py-0.5">
            <input
              id={`review-key-${key}`}
              type="checkbox"
              className="form-checkbox h-3.5 w-3.5 border-1 rounded-sm bg-base0 text-theme-red focus:ring-theme-red"
              checked={+review === item}
              onChange={(event) => {
                if (event.target.checked) {
                  serReview(item.toString());
                } else {
                  serReview("");
                }
              }}
            />
            <label
              htmlFor={`review-key-${key}`}
              className="text-sm font-medium pl-2 inline-flex gap-2"
            >
              <span className="inline-flex items-baseline gap-1">
                <Icon
                  fontSize={12}
                  strokeWidth={1.5}
                  icon="streamline:interface-favorite-star-reward-rating-rate-social-star-media-favorite-like-stars"
                />
                {item}
              </span>
              <span>and up</span>
            </label>
          </li>
        ))}
      </ul>
    </div>
  );
}
