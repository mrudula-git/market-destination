"use client";
// import { useListingStore } from "../../../stores/zustand/search.store1";

export default function AmenitiesAccordion(): JSX.Element {
  // const updateCheckedField = useListingStore((state) => state.setCheckedValue);
  // const checkedData = useListingStore((state) => state.checkedData);

  // console.log(checkedData);

  // const handleCheckboxChange = (
  //   type: string,
  //   group: string,
  //   name: string,
  //   checked: boolean
  // ) => {
  //   console.log(type, group, name, checked);

  //   updateCheckedField(type, group, name, checked);
  // };
  return (
    <div>
      <h2 className="font-semibold mb-2">Amenities</h2>
      <ul>
        {["Wifi", "Pool"].map((item, key) => (
          <li key={key} className="flex items-center gap-2 py-0.5">
            <input
              id={key}
              type="checkbox"
              className="form-checkbox h-4 w-4 border-2 rounded accent-indigo-600"
              // onChange={(e) => {
              //   handleCheckboxChange("amenities", item, item, e.target.checked);
              // }}
            />
            <label htmlFor={key} className="text-sm font-light">
              {item}
            </label>
          </li>
        ))}
      </ul>
    </div>
  );
}
