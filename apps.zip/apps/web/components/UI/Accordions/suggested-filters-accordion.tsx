"use client";

import { useEffect, useState } from "react";
import Modal from "../Modals/modal";
import { useCustomStore } from "../../../stores/zustand/search.store1";
import ListingsFilters from "../../../app/search/listings-filters";
import useCheckboxStore from "../../../stores/zustand/checkbox.store";
import { useSearchFiltersStore } from "../../../stores/zustand/search-filters.store";
import { useSearchParams } from "next/navigation";

type SuggestedFiltersAccordionProps = {
  props: any;
  expanded: boolean;
  onApply: () => void;
};

export default function SuggestedFiltersAccordion({
  props,
  expanded,
  onApply,
}: any) {
  let listings = props;

  const searchParams = useSearchParams();
  const data = searchParams.get("data");

  const customStore = useCustomStore();
  const checkboxStore = useCheckboxStore();
  const { categories, attributeGroups, attributes } = useSearchFiltersStore();

  const [showModal, setShowModal] = useState(false);

  const handleCheckboxChange = (
    type: string,
    id: string,
    name: string,
    checked: boolean
  ) => {
    customStore.setCheckedValue(type, id, name, checked);
    checkboxStore.setCheckedItem(name, checked);
  };

  useEffect(() => {
    // console.log("filter change", !data, attributes.length);

    if (!data || !attributes.length) return;

    let appliedFilters = decodeURIComponent(data);
    appliedFilters = JSON.parse(appliedFilters);

    // console.log(appliedFilters, attributes);

    // console.log(appliedFilters.attributegroup.flat());
    // console.log(appliedFilters.categories.flat());

    // console.log(appliedFilters.attributegroup, appliedFilters.categories);

    const _attributeIds = new Set();
    appliedFilters.attributegroup.forEach((el) => {
      _attributeIds.add(Object.keys(el)[0]);
    });
    appliedFilters.categories.forEach((el) => {
      _attributeIds.add(Object.keys(el)[0]);
    });
    const _filters = attributes.filter(({ id }) =>
      Array.from(_attributeIds).includes(id)
    );
    // console.log(_filters);
    const _checkboxState = _filters.map(({ id, name }) => ({
      name,
      checked: true,
    }));
    // console.log(_checkboxState);
    checkboxStore.setCheckedItems(_checkboxState);

    // _filters.forEach((f) => {
    //   checkboxStore.setCheckedItems();
    // });
  }, [data, attributes]);

  const handleClick = () => {
    // onApply();
    setShowModal(false);
  };

  return (
    <div>
      <div>
        {categories?.length ? (
          <h4 className="font-semibold mb-2">Categories</h4>
        ) : null}
        <ul>
          {categories?.map((category) => (
            <li key={category.id}>
              {category?.attributes?.length > 0 ? (
                <strong className="text-sm mb-1">{category.name}</strong>
              ) : null}
              <ul></ul>
              <ul>
                {category.attributes?.map((attribute: any) => (
                  <li key={attribute.id} className="pl-2">
                    <input
                      id={`${category.name}-${attribute.name}`}
                      type="checkbox"
                      className="form-checkbox h-3.5 w-3.5 border-1 rounded-sm bg-base0 text-theme-red focus:ring-theme-red"
                      onChange={(e) => {
                        handleCheckboxChange(
                          "category",
                          attribute.id,
                          attribute.name,
                          e.target.checked
                        );
                      }}
                      checked={
                        checkboxStore.getCheckedItem(attribute.name)?.checked ||
                        false
                      }
                    />
                    <label
                      htmlFor={`${category.name}-${attribute.name}`}
                      className="text-sm font-medium pl-2"
                    >
                      {attribute.name}
                    </label>
                  </li>
                ))}
              </ul>
            </li>
          ))}
        </ul>
      </div>
      <hr className="my-2"></hr>

      <div>
        {attributeGroups?.length ? (
          <h4 className="font-semibold mb-2">Offers</h4>
        ) : null}
        <ul>
          {attributeGroups?.map((attributeGroup) => (
            <li key={attributeGroup.id}>
              {attributeGroup?.attributes?.length > 0 ? (
                <strong className="text-sm mb-1">{attributeGroup.name}</strong>
              ) : null}
              <ul>
                {attributeGroup.attributes?.map((attribute: any) => (
                  <li key={attribute.id} className="pl-2">
                    <input
                      id={`${attributeGroup.name}-${attribute.name}`}
                      type="checkbox"
                      className="form-checkbox h-3.5 w-3.5 border-1 rounded-sm bg-base0 text-theme-red focus:ring-theme-red"
                      onChange={(e) => {
                        handleCheckboxChange(
                          "attribute",
                          attribute.id,
                          attribute.name,
                          e.target.checked
                        );
                      }}
                      checked={
                        checkboxStore.getCheckedItem(attribute.name)?.checked ||
                        false
                      }
                    />
                    <label
                      htmlFor={`${attributeGroup.name}-${attribute.name}`}
                      className="text-sm font-medium pl-2"
                    >
                      {attribute.name}
                    </label>
                  </li>
                ))}
              </ul>
            </li>
          ))}
        </ul>
      </div>

      <br />

      {/* {!expanded && (
        <button
          className="underline hidden md:inline-block"
          onClick={() => {
            setShowModal(true);
          }}
          type="button"
        >
          <div className="">More...</div>
        </button>
      )} */}

      <Modal
        open={showModal}
        onClose={() => {
          setShowModal(false);
        }}
      >
        <ListingsFilters props={props} expanded={true} onApply={handleClick} />
        {/* <h2 className="font-semibold mb-2">Suggested Filters</h2> */}
      </Modal>
    </div>
  );
}
