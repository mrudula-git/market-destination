import type {
  ListingsAttributes,
  ListingsAttributesGroup,
  ListingsCategories,
} from "database";
import { useMemo } from "react";
import AutoAttributeDetails from "../../../app/[listing_name]/auto-attribute-details";
import type {
  Attribute,
  AttributeGroup,
  Category,
} from "../../../constants/types";

type AttributesAccordionProps = {
  // categories: Partial<ListingsCategories>[];
  // attributeGroups: Partial<ListingsAttributesGroup>[];
  // attributes: Partial<
  //   ListingsAttributes & { value: string | number | boolean | null }
  // >[];

  attributes?: Attribute[];
  categories?: Category[];
  attributeGroups?: AttributeGroup[];
};

export default function AttributesAccordions({
  categories,
  attributeGroups,
  attributes,
}: AttributesAccordionProps) {
  // console.log(categories, attributeGroups, attributes);

  const populatedAttributes = useMemo(() => {
    let _populatedAttributes = structuredClone([
      ...attributeGroups,
      ...categories,
    ]);
    // console.log(_populatedAttributes);
    let _attributesList = attributes.map((el) => el.id);

    _populatedAttributes.forEach((group) => {
      const _attributes = [];
      group.attributesId?.forEach((id) => {
        if (_attributesList.includes(id)) {
          _attributes.push(attributes.find((el) => el.id === id));
        }
      });
      group.attributes = _attributes;
    });
    return _populatedAttributes;
  }, [categories]);

  // console.log(populatedAttributes);

  return (
    <div className="text-primary1">
      {/* <pre>{JSON.stringify(populatedAttributes, null, 2)}</pre> */}

      <div>
        {populatedAttributes.map((group) => (
          <>
            {group.attributes?.length ? (
              <div key={group.id}>
                <h4 className="text-xl font-semibold">{group.name}</h4>

                <br />

                {group.attributes?.map((attribute) => (
                  <AutoAttributeDetails key={attribute.id} {...attribute} />
                ))}

                <hr className="mt-4 mb-6" />
              </div>
            ) : null}
          </>
        ))}
      </div>
      {/* <pre>{JSON.stringify(populatedAttributes, null, 2)}</pre> */}
    </div>
  );
}
