"use client";

import { useState } from "react";
import {
  Button,
  Dialog,
  DialogTrigger,
  Link,
  OverlayArrow,
  Popover,
} from "react-aria-components";

export default function CategoriesPopover() {
  const [open, setOpen] = useState(false);

  return (
    <div>
      <DialogTrigger>
        <Button
          aria-label="Categories"
          className="inline-flex items-center justify-center font-bold"
          onPressChange={(isPressed) => {
            if (isPressed) setOpen(true);
            // else setOpen(false);
          }}
          onHoverChange={(isHovering) => {
            if (isHovering) setOpen(true);
            // else setOpen(false);
          }}
        >
          Categories
        </Button>
        <Popover
          isOpen={open}
          className={({ isEntering, isExiting }) => `
          w-64 group rounded-lg overflow-hidden shadow shadow-primary2 bg-primary2 bg-opacity-50 backdrop-blur text-primary1
          ${
            isEntering
              ? "animate-in fade-in placement-bottom:slide-in-from-top-1 placement-top:slide-in-from-bottom-1 ease-out duration-200"
              : ""
          }
          ${
            isExiting
              ? "animate-out fade-out placement-bottom:slide-out-to-top-1 placement-top:slide-out-to-bottom-1 ease-in duration-150"
              : ""
          }
        `}
          shouldCloseOnInteractOutside={(element) => {
            setOpen(false);
            return true;
          }}
        >
          <Dialog>
            <div
              className="flex flex-col gap-2"
              onMouseLeave={() => {
                setOpen(false);
              }}
            >
              <Link
                href={"/search?query=waterpark"}
                className="font-semibold hover:underline"
              >
                <div className="p-4 hover:bg-base0 hover:bg-opacity-50">
                 Waterparks
                </div> 
              </Link>
              <Link
                href={"/search?query=resort"}
                className="font-semibold hover:underline"
              >
                <div className="p-4 hover:bg-base0 hover:bg-opacity-50">
                  Resorts
                </div>
              </Link>
            </div>
          </Dialog>
        </Popover>
      </DialogTrigger>
    </div>
  );
}
