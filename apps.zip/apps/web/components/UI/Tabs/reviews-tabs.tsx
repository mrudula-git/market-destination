import { Tab, TabList, TabPanel, Tabs } from "react-aria-components";
import WriteAReview from "../../../app/[listing_name]/reviews-details/write-a-reiview";
import ReviewList from "../../../app/[listing_name]/reviews-details/review-list";
import { useReviewsStore } from "../../../stores/zustand/review.store";

const tabs = [
  {
    id: "see-all-reviews",
    label: "See all reviews",
    // component: SeeAllReviewsTab,
  },
  {
    id: "write-a-review",
    label: "Write a review",
    // component: WriteAReviewTab,
  },
];

type ReviewsTabProps = {
  listingsId: string;
  activeWriteAReview: boolean;
};

export default function ReviewsTabs({
  listingsId,
  activeWriteAReview = false,
}: ReviewsTabProps): JSX.Element {
  const defaultSelectedKey = activeWriteAReview ? tabs[1]?.id : tabs[0]?.id;
  const reviews = useReviewsStore((state) => state.reviews);

  return (
    <Tabs
      className="w-full h-full flex flex-col items-center"
      defaultSelectedKey={defaultSelectedKey}
    >
      <TabList
        aria-label="Reviews"
        className="sticky left-0 right-0 top-0 modal-child flex justify-center p-1 mb-4 rounded-full bg-theme-orange border border-solid"
      >
        {tabs.map((el) => (
          <Tab
            className={({ isSelected }) => `
          w-fit rounded-full py-2 px-4 font-semibold text-center cursor-default outline-none transition-colors focus-visible:ring-2
          ${
            isSelected
              ? "text-theme-text-light bg-theme-red"
              : "text-theme-text-light"
          }
          `}
            id={el.id}
            key={el.id}
          >
            {el.label}
          </Tab>
        ))}
      </TabList>

      <TabPanel className="w-full h-full" id={tabs[0]?.id}>
        <ReviewList listingsId={listingsId} showMore={false} showAll={true} />
      </TabPanel>

      <TabPanel className="w-full" id={tabs[1]?.id}>
        <br />
        <WriteAReview listingsId={listingsId} />
      </TabPanel>
    </Tabs>
  );
}
