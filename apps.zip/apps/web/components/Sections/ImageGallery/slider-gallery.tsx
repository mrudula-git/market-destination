export default function SliderGallery() {
  return <div></div>;
}
