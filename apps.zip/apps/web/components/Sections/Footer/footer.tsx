"use client";

import { Icon } from "@iconify/react";
import Link from "next/link";
import { categoriesData } from "../Navigation/navigation-links";

const icons = [
  "fa6-brands:facebook",
  "fa6-brands:instagram",
  "fa6-brands:square-x-twitter",
  "fa6-brands:youtube",
];

export default function Footer() {
  return (
    <div className="sticky z-20 bg-base0 text-primary1">
      <div className="max-w-screen-lg mx-auto px-2">
        <div className="relative -top-6 grid p-4 grid-cols-2 md:grid-cols-4 gap-6 bg-primary1 text-link-orange shadow rounded-lg">
          <div className="col-span-2 md:col-span-1">
            <Link href="/">
              <img className="h-6 w-auto" src="assets/logo.png" alt="" />
            </Link>
            {/* <div className="text-sm">
              <div className="flex gap-2">
                <p>
                  Phone:{" "}
                  <a className="underline" href="tel:+919594646353">
                    +919594646353
                  </a>
                </p>
                <p>
                  Email:{" "}
                  <a className="underline" href="mailto:support@findigoo.com">
                    support@findigoo.com
                  </a>
                </p>
              </div>
              <p>
                Address: 309/A, Bhavin Apartment, Chandansar Road, Virar East,
                401305.
              </p>
            </div> */}
          </div>
          <div className="col-span-2 md:col-span-1 flex gap-2">
            {icons.map((icon) => (
              <Icon key={icon} icon={icon} className="w-5 h-5" />
            ))}
          </div>
          <div>
            <p className="font-semibold mb-1">Categories</p>
            <div className="text-sm font-light flex flex-col items-start gap-[1px]">
              {categoriesData.map((c) => (
                <Link key={c.key} href={c.url} className="dm-link">
                  {c.name}
                </Link>
              ))}
            </div>
          </div>
          <div>
            <p className="font-semibold mb-1">Company</p>
            <ul className="text-sm font-light flex flex-col items-start gap-[1px]">
              <li className="dm-link">
                <a href="/about-us">About Us</a>
              </li>
              <li className="dm-link">
                <a href="/contact-us">Contact Us</a>
              </li>
              <li className="dm-link">
                <a href="/terms-of-use">Terms of Use</a>
              </li>
              <li className="dm-link">
                <a href="/privacy-policy">Privacy Policy</a>
              </li>
            </ul>
          </div>
        </div>

        {/* <br /> */}
        {/* <div className="text-sm md:text-base grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="flex flex-col items-start">
            <div className="font-bold">Water parks</div>
            <div className="dm-link">Near Pune</div>
            <div className="dm-link">Near Mumbai</div>
          </div>
          <div className="flex flex-col items-start">
            <div className="font-bold">Resorts</div>
            <div className="dm-link">Near Pune</div>
            <div className="dm-link">Near Mumbai</div>
          </div>
          <div className="flex flex-col items-start">
            <div className="font-bold">Farm houses</div>
            <div className="dm-link">Near Pune</div>
            <div className="dm-link">Near Mumbai</div>
          </div>
          <div className="flex flex-col items-start">
            <div className="font-bold">Agro tourisms</div>
            <div className="dm-link">Near Pune</div>
            <div className="dm-link">Near Mumbai</div>
          </div>
        </div> */}
        {/* <br />
        <hr />
        <br /> */}

        <div className="text-center text-xs">
          <p className="">
            Designed & Developed by{" "}
            <a
              className="underline"
              href="https://neurosparkworks.com/"
              target="_blank"
            >
              Neuro Spark Works Solutions Pvt. Ltd.
            </a>
          </p>
          <p className="">
            © Copyright Findigoo Infotainment Pvt. Ltd. All Rights Reserved
          </p>
        </div>
        <br />
      </div>
    </div>
  );
}
