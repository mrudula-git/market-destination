export default function NavigationBar() {
  return <div></div>;
}
