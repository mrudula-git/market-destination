export default function NavigationDrawer() {
  return <div></div>;
}
