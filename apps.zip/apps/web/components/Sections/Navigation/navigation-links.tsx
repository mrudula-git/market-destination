"use client";

import Link from "next/link";
import { useIndicatorsStore } from "../../../stores/zustand/indicators.store";
import { useSearchParams } from "next/navigation";
import { twJoin, twMerge } from "tailwind-merge";

export function generateQSforCategories(category: string) {
  let qs = new URLSearchParams("");
  qs.append("category", category);
  return `/search?${qs.toString()}`;
}

export const categoriesData = [
  {
    name: "Waterparks",
    icon: "https://cdn-icons-png.flaticon.com/128/4775/4775786.png",
    key: "waterpark",
    url: generateQSforCategories("waterparks"),
  },
  {
    name: "Resorts",
    icon: "https://cdn-icons-png.flaticon.com/128/3942/3942052.png",
    key: "resorts",
    url: generateQSforCategories("resorts"),
  },
  {
    name: "Agro Tourism",
    icon: "https://cdn-icons-png.flaticon.com/128/4866/4866818.png",
    key: "agro tourism",
    url: generateQSforCategories("agro tourism"),
  },
  {
    name: "Farmhouse",
    icon: "https://cdn-icons-png.flaticon.com/128/2388/2388427.png",
    key: "farmhouse",
    url: generateQSforCategories("farmhouse"),
  },
];

export default function NavigationLink() {
  const searchParams = useSearchParams();
  const category = searchParams.get("category") || "";
  // console.log(category);

  const { setPageLoading } = useIndicatorsStore();

  return (
    <>
      {categoriesData.map((c) => (
        <Link
          key={c.key}
          className="group flex flex-col justify-center items-center font-medium hover:underline hover:decoration-link-red"
          href={c.url}
          onClick={() => {
            setPageLoading(true);
          }}
        >
          <img
            src={c.icon}
            alt={c.name}
            className={twJoin(
              "w-8 h-8 ring-4 ring-transparent group-hover:ring-link-red group-hover:bg-link-red rounded group-hover:p-0.5 transition-all",
              c.key === category ? "ring-link-orange bg-link-orange" : ""
            )}
          />
          <span
            className={twJoin(
              "text-center group-hover:text-link-red ",
              c.key === category ? "text-link-orange" : ""
            )}
          >
            {c.name}
          </span>
        </Link>
      ))}
    </>
  );
}
