import Link from "next/link";
import NavigationLink from "./navigation-links";
import { ErrorBoundary } from "react-error-boundary";
// import CategoriesPopover from "../../UI/Popovers/categories-popover";

export default function Navigation() {
  return (
    <div className="sticky top-0 z-30 bg-base0 text-primary1">
      <div className="max-w-screen-lg mx-auto px-2">
        <nav className="grid grid-cols-1 sm:grid-cols-2 py-1 items-center">
          <div>
            <a
              href="/"
              className="my-2 sm:my-0 inline-flex items-center justify-start"
            >
              <img className="h-8 w-auto" src="assets/logo.png" alt="" />
              {/* <h1 className="text-3xl font-black">
              </h1> */}
            </a>
          </div>
          {/* <CategoriesPopover /> */}
          <div className="flex gap-4 my-1 overflow-x-auto scrollbar-hide justify-normal sm:justify-end items-start text-xs sm:text-sm">
            <ErrorBoundary fallback={<></>}>
              <NavigationLink />
            </ErrorBoundary>
          </div>
        </nav>
      </div>
    </div>
  );
}
