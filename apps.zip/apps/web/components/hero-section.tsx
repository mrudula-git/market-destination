"use client";

import HeroContent from "./hero-content";
import HeroMedia from "./hero-media";
import HeroSearchBar from "./hero-searchbar";

export default function HeroSection() {
  return (
    <div className="bg-base0">
      <div className="container mx-auto relative h-full">
        <div className="grid grid-cols-1 sm:grid-cols-2">
          <div></div>
          <div>
            <HeroMedia />
          </div>
        </div>
        <div className="absolute top-0 inset-x-0 z-20">
          <div className="container lg:max-w-screen-md xl:max-w-screen-lg mx-auto">
            {/* <Navigation/> */}
            <div className="px-4">
              <HeroContent />
              <br />
              <HeroSearchBar />
            </div>
          </div>
        </div>
      </div>
      {/* <br /> */}
    </div>
  );
}
