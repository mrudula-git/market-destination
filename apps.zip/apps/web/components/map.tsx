"use client";
import { Fragment, useRef, useState } from "react";
import {
  GoogleMap,
  InfoWindowF,
  MarkerF,
  useLoadScript,
} from "@react-google-maps/api";
import { Icon } from "@iconify/react/dist/iconify.js";
import data from "../app/[listing_name]/data.json";

// console.log(data.listing.location);
const placesData = [
  {
    business_status: "OPERATIONAL",
    geometry: {
      location: {
        lat: 18.366277,
        lng: 73.7558777,
      },
    },
    icon: "https://maps.gstatic.com/mapfiles/place_api/icons/v1/png_71/generic_business-71.png",
    name: "Sinhagad Fort",
    place_id: "ChIJ2RgRhuaTwjsRC-nUx4nVtMs",
    types: ["tourist_attraction", "park", "point_of_interest", "establishment"],
    vicinity: "Sinhagad Ghat Road, Thoptewadi",
  },
  {
    business_status: "OPERATIONAL",
    geometry: {
      location: {
        lat: 18.6980499,
        lng: 73.69045869999999,
      },
    },
    icon: "https://maps.gstatic.com/mapfiles/place_api/icons/v1/png_71/worship_hindu-71.png",
    name: "Birla Ganpati Temple",
    place_id: "ChIJE6O16lKwwjsR1w5gW6DuBOI",
    types: [
      "hindu_temple",
      "tourist_attraction",
      "place_of_worship",
      "point_of_interest",
      "establishment",
    ],
    vicinity:
      "10, Mumbai - Pune Expressway, Chourai Nagar, Talwade, Pimpri-Chinchwad",
  },
  {
    business_status: "OPERATIONAL",
    geometry: {
      location: {
        lat: 18.5164297,
        lng: 73.85613289999999,
      },
    },
    icon: "https://maps.gstatic.com/mapfiles/place_api/icons/v1/png_71/worship_hindu-71.png",
    name: "Shreemant Dagdusheth Halwai Ganpati Mandir",
    place_id: "ChIJARU6Gc_RwjsR7-oEzsCdgc8",
    types: [
      "hindu_temple",
      "tourist_attraction",
      "place_of_worship",
      "point_of_interest",
      "establishment",
    ],
    vicinity:
      "Ganpati Bhavan, 250, Chhatrapati Shivaji Maharaj Rd, Budhvar Peth",
  },
  // ... (Add other places from the provided data similarly)
];
// console.log(data.listing.location);

const mapStyles = [
  {
    featureType: "poi",
    elementType: "labels.text.fill",
    stylers: [{ color: "#757575" }],
  },
  {
    featureType: "poi.park",
    elementType: "geometry",
    stylers: [{ color: "#3CB371" }],
  },
  {
    featureType: "road",
    elementType: "geometry",
    stylers: [{ color: "#D3D3D3" }],
  },
  {
    featureType: "road.local",
    elementType: "labels.text.fill",
    stylers: [{ color: "#616161" }],
  },
  {
    featureType: "transit",
    elementType: "labels.text.fill",
    stylers: [{ color: "#757575" }],
  },
  {
    featureType: "water",
    elementType: "geometry",
    stylers: [{ color: "#AEE1F5" }],
  },
];

function Map() {
  const googleMapRef = useRef();
  // console.log(googleMapRef);
  const { isLoaded } = useLoadScript({
    googleMapsApiKey: process.env.NEXT_PUBLIC_GOOGLE_MAPS_KEY!,
  });

  const [activeMarker, setActiveMarker] = useState(null);

  const center = {
    lat: data.listing.location.lat,
    lng: data.listing.location.lng,
  };

  const handleActiveMarker = (marker: any) => {
    if (marker === activeMarker) {
      return;
    }
    setActiveMarker(marker);
  };

  return (
    <>
      {isLoaded ? (
        <GoogleMap
          center={center}
          mapContainerStyle={{ width: "100%", height: "100%" }}
          onClick={() => {
            setActiveMarker(null);
          }}
          options={{
            scrollwheel: true,
            mapTypeControl: false,
            fullscreenControl: false,
            gestureHandling: "greedy",

            zoomControl: true,
            styles: mapStyles,
            zoomControlOptions: {
              position: window.google.maps.ControlPosition.TOP_RIGHT,
            },
            fullscreenControlOptions: {
              position: window.google.maps.ControlPosition.TOP_LEFT,
            },
            scaleControl: false,
          }}
          ref={googleMapRef}
          zoom={10}
        >
          {placesData.map((place, index) => (
            <MarkerF
              key={index}
              position={place.geometry.location}
              onClick={() => {
                handleActiveMarker(index);
              }}
              // icon={{
              //   url: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAQUAAADBCAMAAADxRlW1AAAA6lBMVEX/////AQH7AAD8///4AAD6//////78/v/2AAD//f/7//z3/////fv///z6//3/AgDvAAD/+v/2//r85+L64N/9/vb5pKT8nqD2qaX+Agn81tf6PEL+v7X93tz/9fL6NzT5eHL1saj6ZWP9gYT/jZD92NP+XVz96N/7h3/7mJX7lZv73OD87ez9zM/5srP6cWb4Py3/EBv0HyH7pZ/0/vD7cHL7w8L9Vlf7RD/7n5Xw8/H3iobzc2/6Ky76y8b4rKD7OUT+l4j8w7n2kYz93s/7v8T8JzT+WEzukZD7ZmDyV1L7sLT8TFD/GSgb09zIAAAKm0lEQVR4nO2dCXfbNhLHgQEgHCQIkxLtMLbl27UTxa6UWr4aJXVdp0m83//rLEBJPnWwuytpA+H3EvkQ+R44Amb+AwxghAKBQCAQCAQCgUAgEAgEAoFAIBAIBAIeU0OI2FddQ8PXZSRinNvHjwmpERJrhCRi0aIbNXdyHes810TpmlbEfpvHcbx0XSJmDEWtDyera2trqycfWpFkTC66UXOHNd6cCkoBY/ePUnH6psEW3ah5oWScZChqrv4KQI0xGOPyvzEU4NfVZoQypZFedDNnTK4jmdb325RigZ8jMKXt65b1mjJbdDNnDJe6udoBCgK/MIP7BQjorOaZTBfdzBnDk7frtu9bhwAYzFMAChDurYu3EV90M2eIzBniH2EF3LMWzi9Yx4iLduE8pKHYmsGagq7AR8557mvA+C1C+RmlhcBFAfZhofPtsvv27ebbD93Lww5Y80BRYFFQepbL6LdFN3dGxGl+SEUh7KcuAMx2j7NIKyuklYqQ7G3bMCEAl1ec56mvviG6ulgp3KcNBtqXGWEyirhzAZxHREYsu2zbd4S9pBBbV8mimzsDCNI8tn6RFvazBnrdJJIhonWurYJ2rwmyPzevKbY9obBe4yLmukYW3ez/MRwp9ju1TsF1+U+9bLRMTLLeHXVu0prr9yTmnsUKqRL2GWwktP1AfK9H6Wh1qHnUOl8RLmYC/cwS5VegYJw0wI0FcJ6P5/HoT5nHOcrPqfWddlxAgxC/MgudxudWJTg5YI3AORk94gl3SuG76zF25JzH0q+EIuE7LjpawfipOWY0DFGy+Qn3DbaDPHOPV3dOMQJeOSDx5G7Oc3SwYjC1zuHuak6tmxer1D0XhcuIx1MutbrxEqywsOnVm7m0bW6k6zb+2U93vZnLKYNdcq6aF4PL/RGQTCZ8w6WQNkHougmUqbOLGnWtgrR3wAZJUj98g0ozdlZmj+KiWfGe5gUU2GA4Y1mqZtq6eaFk1uq4eRQKqxXjfy1atVawdFqZJ9FSc9J1k4sGoFW1d6uW6zz2ri7hnlghQ9f9SbVdmVdbcSAq3oXSCtck8cMKRJP78pOFNaSqPRJReq1/y729e8btmw8sztr9R+pWXoJLSA/cDD1uZ9KTXILUoW+FFpmmmB6IW6UVANe5H3mljHoYSu/IkKrWvQnJES1vwb3IE+UUbfQdfptUXo5VmrTLEQEbngwIRDbKCGE6TFf190qzTt8K3Zk2bZ5slGP8P7GCgZOZtmyORAMr2BFRWTUNRoTxZkQQ1MOFc3U01nlF7yjztPSOBe55MtNC5CaY0uE3aqRi2JO60deOsCn9sAInzYG/P1FVZVOkTwZxpUk8mY5X6K4s1aB7qqKCRpne72dTd8iTNSqlyLfSCmI95tW6dy2TX2gZXg8Z8WN+Ic7QH/2kgB5E1WRTLToYiO4/SORHTikzdDOwwnVFK6DoiPZF9w3JPMkjVNwo3SMIUa/o8H8Rgtq4YtoN7ceAQDJW8Zar36HU/MlqtSkCgKFajf0JxYqrbtmy9/oRI6SO9DfbEwALurIZxXryY3Eto80VUbiSDji09/oxIkiNszVXx2cKgXc1yyanymnG9C6mhSuAxGtMVlbd/9+46vdeuUrpanWOVTpZASSpuqSuK1hoj8npyxc/BfYp4npHlMVMBdAuyydenrOuGzw2hQDo1LWWflih5B67jMoYgVduUSbHLLUoV/Z6u4JXXHyggO/n3MoZQ45cRYIVAK6I7SDN4tEuT6os3RQGSnlBKRz54ROG2F5elDIIu3rHz0SO9g0JR58FpQL66xfQ9WRyYUCt0cZ9SWyNIPB2ffTjkdY2FtaHlt2GgtVMc27nbNHxfTnTUhrCPuXWTpMgm2dzrXWslZUQkbIZ+M6WjSMw2Cxg3ULsmRWcY+hbwfo9V9ZyYe2gdKJih0q04s2dCwoufRhcR2HPt40S5MY87AFwo8I+bXvvr3rMGYsY43H9rz2ba4DTCYOrDJgbv5yjW59q46EdwJV+WnFoBcTW7t7+8f7e7pargLYqqXxvaIV25SXunwSi0nPAj5TbpQq3U6j83hmoKH8Jj1fBeVpxKetnwUbGa/wSM+EnZ4VrX2bbHmDRYKalMgZumF9yAdn0uCnMPzKDEU3kSTXPkEQm5LzvAp51/3Ff3ZWHjHDPhoRK0OWj/5+OvfYSMU9m24ZIHaUHNqGsagaXWh+krHLRx89BjZCUuYr/qlYAQX2p93yEuImDUyhoNQdpaAGnJEs9Wal9xg9XyVnFDMappx+Lbu6MqFvdXHFEUAr1RTd3RpA7GGbXUyKl7Qx3Hg6GEnJNi2pdweZV175aodajVVU00N6iWzsrVLNdzQbWCu2mZ4rpAc4OK/eFQ19KWF7B2ZvKeuEN86Tk9RVZvFnRO+JiU/k6IrJYr1e0wrr2pW7hFSohR8MuP+XrEfNkc8hrVIp6lXqCwb2a9CyffECnqr+NbKoVOi3l2TTTI1YNsjNcPMjoMdDCnHk24fgUp4l3XEY12QqC4p1FN3XG1IspNnALdIWv+aTD9YX46xTh5GpYvvrqExyuNIetuUOKJkRKU4BY82zq+RXkgIqJY8JYv3DgsXPsk0+Vj7DV9HVu4ZH9yZHSjoh9T4r7xqOTrpk4+Wio6XqrnofIrDltBpY2Iz+KfsfDuTqdEipPlW9ndr0iTskJnrB4bd85YamvmdQQJUkLYIJeAGhx6evcwgN5Gn1xZ3ON6g42PhT0S5RWPKvi54Urxo7dwvxoK4gCHzOmvPcLUqIDYcbllWDEAZKeHLkwnloUJ6SDx1jBWqdD1JQjzjyB7Y1ZwncL9nvMd6cw5AbGlXMAeFfvOg7Z/AQwLIp+GikNwKcmX5a+wM7GxQg4W5oBoaMNPM4KG55sKJ6OZr+0R/sFaP/iW13beJg+HO0c3XbLRTdubnD0g47IqIyhJ8h3wfQA0VGjMPCiBBSsrxCNyJNj26ajZCLP3bnXzyKlAIG/58yTDcXTyaRia/SlcHJ7ZdYY97HQcySa56QBL/JKU7hDfBhfGtFkrZDmF6J4XuREC3FxJT07E30af5vi+TQsBfO391PwLzkA8dwxUIFvl8UnDCHukJLn3pFuLU18eIAd0efeEdOj5fIJDvXBWeHpWjX94P3U8ysS/XzWzcrn3PcF+9fwbPuFgt7OfJ96foWO4+7TjMoY0UWeHTQwHa3ihPbPOi7FMzY0i5NlkwvuSIZdeNRNFL4RT86n+ifwRG6UB3qVPsF+2ZDJ0uQQQ3SsUEs8sYJoJbWqZ2B6g9YqYd9pOSbcQjX9ThLl0wFV1fkB/bVrq5i83T45nXrR34BuX70ud50MOS8LOuyIwOeLbsvicH+gb+AdPy9fJjUke98uN1JB0X6/fDnEEKa/9k+Qh696ea2AyMdBRvWx6tHpHsJ5ozzp19CGt5tIp8NVXJ5lBYdyypG4PiM5emdcXcs7tISZ1JAaYbfGgDG3jCyleC7RBLF7MHB/VVuesoVXaCLZsc2ojqO4+l+i8pJNK583F92IhaO/mC/LNq3wGvIOv1u6JalX1N7j98sbH4Zo9i8WRoTmt578NdL/Bh3JpSn0nEAy5rT05aK2dAUsgUAgEAgEAoFAIBAIBAKBQCAQCAQCy8q/Ac4Yn0hP7UQYAAAAAElFTkSuQmCC", // Use the icon URL from your data
              //   scaledSize: new window.google.maps.Size(40, 40), // Adjust the size as needed
              // }}
            >
              {activeMarker === index ? (
                <InfoWindowF
                  onCloseClick={() => {
                    setActiveMarker(null);
                  }}
                >
                  <div>
                    <p>{place.name}</p>
                    <p>{place.vicinity}</p>
                  </div>
                </InfoWindowF>
              ) : null}
            </MarkerF>
          ))}
        </GoogleMap>
      ) : (
        <div>Loading map...</div>
      )}
    </>
  );
}

export default Map;
