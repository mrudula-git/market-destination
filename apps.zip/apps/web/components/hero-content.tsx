"use client";

import { useEffect, useState } from "react";
import { motion, useAnimation } from "framer-motion";

const texts = ["Waterparks", "Resorts", "Agro Tourism", "Farmhouse"];

export default function HeroContent() {
  const [index, setIndex] = useState(0);
  const controls = useAnimation();

  const incrementIndex = () => {
    setIndex((prevIndex) => (prevIndex + 1) % texts.length);
  };

  useEffect(() => {
    const timer = setInterval(incrementIndex, 3000);
    return () => clearInterval(timer);
  }, []);

  const textVariants = {
    hidden: { opacity: 0, y: -50 },
    visible: { opacity: 1, y: 0 },
    exit: { opacity: 0, y: 50 },
  };

  const lineUpAnimation = {
    hidden: { opacity: 0, translateY: "60%" },
    visible: { opacity: 1, translateY: "0%" },
    exit: { opacity: 1, translateY: "0%" },
  };

  return (
    <div className="mt-8 md:mt-16 text-primary1">
      <h1 className="font-bold md:text-6xl">
        <motion.h1
          key={index}
          className=""
          initial="visible"
          animate="visible"
          exit="exit"
          variants={textVariants}
          transition={{ duration: 0.5 }}
          style={{ lineClamp: "clamp(1, 50%, 3)" }}
        >
          <span className="text-2xl md:text-4xl mb-2 block">
            Discover Your Oasis,
          </span>
          <span className="block text-3xl md:text-5xl font-black">
            Plan next vacation at
            <span className="block text-5xl md:text-6xl">
              <motion.span
                className="animate-charcter"
                initial="hidden"
                animate="visible"
                exit="exit"
                variants={lineUpAnimation}
                transition={{ duration: 0.5 }}
                controls={controls}
              >
                {texts[index]}
              </motion.span>
            </span>
          </span>
          <span className="block">
            {/* <span className="border-2 p-2 rounded-2xl xl:my-8 md:my-2">
              <motion.span
                className="motion lineUp animate-charcter my-2 text-blue-500"
                initial="hidden"
                animate="visible"
                exit="exit"
                variants={lineUpAnimation}
                transition={{ duration: 0.5 }}
                controls={controls}
              >
                {texts[index]}
              </motion.span>
            </span> */}
          </span>
        </motion.h1>
      </h1>
      <br />
      <p className="hidden md:block p-2 rounded-md font-medium bg-transparent transition-colors">
        We “Trend Water Rides Pvt. Ltd.” engaged as the foremost Manufacturer of
        Waterslides and Playground Equipments, having installed 150+ waterslides
        in the span of 2 years all over India. We are well known for guidance
        and hand-holding.
      </p>
    </div>
  );
}
