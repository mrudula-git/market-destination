"use client";

import { Icon } from "@iconify/react";

type ListingIntroductionProps = {
  socialMediaURLs?:
    | {
        instagram?: string;
        website?: string;
        youtube?: string;
      }
    | undefined;
};

const icons = {
  facebook: "fa6-brands:facebook",
  instagram: "fa6-brands:instagram",
  x: "fa6-brands:square-x-twitter",
  youtube: "fa6-brands:youtube",
  website: "fa6-solid:globe",
};

export default function SocialMediaComponent({
  socialMediaURLs,
}: ListingIntroductionProps) {
  let websiteDomain = "";

  // Check if socialMediaURLs.website is provided and is a valid URL
  if (socialMediaURLs?.website) {
    try {
      const url = new URL(socialMediaURLs.website);
      websiteDomain = url.hostname;
    } catch (error) {
      // Handle invalid URL (optional)
      console.error("Invalid website URL:", socialMediaURLs.website);
    }
  }
  return (
    <div>
      <div className="flex gap-3">
        <div>
          {socialMediaURLs?.instagram ? (
            <a
              href={socialMediaURLs.instagram}
              target="_blank"
              rel="noreferrer"
            >
              <Icon className="w-6 h-6" icon={icons.instagram} />
            </a>
          ) : null}
        </div>
        <div className="border-l pl-2">
          {socialMediaURLs?.youtube ? (
            <a
              className="flex items-center gap-1 justify-center"
              href={socialMediaURLs.youtube}
              target="_blank"
              rel="noreferrer"
            >
              <Icon className="w-6 h-6" icon={icons.youtube} />
            </a>
          ) : null}
        </div>
        <div className="border-l pl-2">
          {socialMediaURLs?.website ? (
            <a
              className="flex items-center gap-1 justify-center"
              href={socialMediaURLs?.website}
              target="_blank"
              rel="noreferrer"
            >
              <span>Website: </span>
              <span className="hover:underline max-w-36 md:max-w-fit truncate">
                {websiteDomain}
              </span>
            </a>
          ) : null}
        </div>
      </div>
    </div>
  );
}
