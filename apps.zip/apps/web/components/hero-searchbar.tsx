"use client";

import React from "react";
import { Icon } from "@iconify/react";
import { useRouter } from "next/navigation";
import { apis } from "../constants/apis";
import { useSeachStore } from "../stores/zustand/search.store";
import { useEffect, useState, useRef } from "react";
import Typed from "typed.js";

export function HeroSearchBar() {
  const router = useRouter();
  const { query, setQuery } = useSeachStore();
  const [showDynamicText, setShowDynamicText] = useState(query.length === 0);
  const typingRef = useRef<Typed | null>(null);
  const inputRef = useRef<HTMLInputElement | null>(null);
  const wrapperRef = useRef(null);
  useOutsideAlerter(wrapperRef);

  function search() {
    const qs = new URLSearchParams("");
    if (query) qs.append("query", query);
    const nextUrl = `${apis.search}${qs.size ? `?${qs.toString()}` : ``}`;
    console.log(nextUrl);
    router.push(nextUrl);
  }

  function handleDynamicTextClick() {
    setShowDynamicText(false);
    if (inputRef.current) {
      inputRef.current.focus();
    }
  }

  function handleDynamicTextBlur() {
    query.length < 1 ? setShowDynamicText(true) : setShowDynamicText(false);
  }
  useEffect(() => {
    if (showDynamicText) {
      typingRef.current! = new Typed("#text", {
        strings: ["Waterparks", "Resorts", "Agro Tourism", "Farmhouse"],
        typeSpeed: 50,
        backDelay: 1500,
        backSpeed: 50,
        loop: true,
        cursorChar: "|",
        showCursor: true,
      });
    }

    return () => {
      if (typingRef.current) {
        typingRef.current.destroy();
      }
    };
  }, [showDynamicText]);

  function useOutsideAlerter(ref: any) {
    useEffect(() => {
      function handleClickOutside(event: any) {
        if (ref.current && !ref.current.contains(event.target)) {
          setShowDynamicText((prev) => true);
        }
      }

      document.addEventListener("click", handleClickOutside);

      return () => {
        document.removeEventListener("click", handleClickOutside);
      };
    }, [ref, setShowDynamicText]);
  }

  return (
    <div className="max-w-screen-md overflow-hidden relative pb-4">
      {showDynamicText && (
        <div
          className="pl-6 text-4xl absolute pt-1 w-full flex items-center"
          onClick={handleDynamicTextClick}
          ref={wrapperRef}
        >
          <div className="text-base inline-block text-primary1 ps-2 ">
            Search for
          </div>
          <span
            id="text"
            className="text font-bold pl-2 text-primary1 text-xl "
          ></span>
        </div>
      )}
      <form
        className="flex items-center p-1.5 border border-theme-red bg-base0 rounded-full shadow shadow-overlay-orange focus-within:shadow-overlay-orange focus-within:shadow-md transition-all"
        onSubmit={(event) => {
          event.preventDefault();
          search();
        }}
      >
        <input
          ref={inputRef}
          className="flex-grow px-6 border-0 bg-base0 focus:outline-none focus:ring-0 rounded-full transition-colors placeholder:text-primary1"
          placeholder={showDynamicText ? "" : "Search"}
          value={query}
          onChange={(e) => {
            setQuery(e.target.value);
          }}
          onBlur={handleDynamicTextBlur}
        />

        <button
          type="submit"
          className="p-3 md:p-2 md:px-4 inline-flex items-center gap-2 border bg-primary1 text-base0 rounded-full"
        >
          <Icon icon={"fe:search"} />
          <div className="hidden md:inline font-semibold">Search</div>
        </button>
      </form>
    </div>
  );
}

export default HeroSearchBar;
