"use client";
// import {Card, Label, TextInput } from "flowbite-react";

export default function SectionFive() {
  return (
    <div className="bg-secondary1 text-primary1">
      <br />
      <br />
      <div className="container mx-auto relative">
        <div className="container lg:max-w-screen-md xl:max-w-screen-lg mx-auto px-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 align-middle gap-12">
            {/* Image Section */}
            <div className="md:col-span-1 order-last md:order-first">
              <div className="relative h-full">
                <img
                  alt=""
                  className="h-full w-full object-center max-h-[320px] object-cover"
                  src="https://ik.imagekit.io/va54lhjie/marketplace/listings/65954e7a20a363210a9c83cc/kshitij-gallery_iqrtS4Vbh.jpeg"
                />
              </div>
            </div>

            {/* Content Section */}
            <div className="md:col-span-1 ">
              <div className="font-bold text-xl py-2 pb-4">
                Explore the Gentle Art of Comparison
              </div>
              <div className="">
                Step into the serenity of choice with our delicate comparison
                feature. Discover the subtle nuances that differentiate two
                items, allowing you to make decisions with grace and ease.
                Embrace the tranquil journey of understanding each option,
                gently guiding you towards the perfect choice for your needs.
                Uncover the quiet wisdom behind our comparison tool, where
                decisions unfold like the soft petals of a blossoming flower.
                Experience the beauty of informed choices – because sometimes,
                decisions should be as gentle as a whisper.
              </div>
            </div>
          </div>
        </div>
      </div>
      <br />
      <br />
    </div>
  );
}
