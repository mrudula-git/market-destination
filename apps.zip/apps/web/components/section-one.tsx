"use client"
import { motion, useAnimation } from "framer-motion";
import React, { useEffect, useState } from "react";

const data = [
  {
    count: 555,
    description: "Customer",
  },
  {
    count: 456,
    description: "Our Partners",
  },
  {
    count: 323,
    description: "Lorem ipsum dolor ",
  },
  {
    count: 234,
    description: "Lorem ipsum dolor ",
  },
  {
    count: 354,
    description: "Customer",
  },
  {
    count: 456,
    description: "Our Partners",
  },
  {
    count: 323,
    description: "Lorem ipsum dolor ",
  },
  {
    count: 234,
    description: "Lorem ipsum dolor ",
  },
  {
    count: 354,
    description: "Customer",
  },
  {
    count: 456,
    description: "Our Partners",
  },
  {
    count: 323,
    description: "Lorem ipsum dolor ",
  },
  {
    count: 234,
    description: "Lorem ipsum dolor ",
  },
];

export default function SectionOne() {
  const controls = useAnimation();
  const [isHovered, setHovered] = useState(false);

  useEffect(() => {
    const startContinuousAnimation = async () => {
      //delay before starting the animation
      await new Promise((resolve) => setTimeout(resolve, 100));

      // while (true) {
        console.log('loop')
        // Slide right to left
        await controls.start({
          x: `-${(data.length - 1) * 100}%`,
          transition: {
            type: "tween",
            duration: data.length * 12,
            ease: "linear",
          },
        });

        // first column back to the right
        await controls.start({
          x: 0,
          transition: {
            type: "tween",
            duration: 0,
          },
        });
      // }
    };

    startContinuousAnimation();

    // Cleanup the animation on component unmount
    return () => controls.stop();
  }, [controls, isHovered]);

  const stopContinuousAnimation = () => {
    controls.stop();
  };

  const handleHover = () => {
    setHovered(true);
    stopContinuousAnimation()
  };

  const handleLeave = () => {
    setHovered(false);
  };

  return (
    <div className="container mx-auto relative lg:my-20 my-14 ">
      <div className="container lg:max-w-screen-md xl:max-w-screen-lg mx-auto px-6 md:mt-0 mt-10 overflow-hidden">
        <h2 className="lg:text-5xl md:text-3xl sm:text-6xl font-bold mb-6 text-center">Our Partners</h2>
        <motion.div
          className="flex overflow-hidden"
          style={{
            width: `${data.length * 100}%`,
          }}
          animate={controls}
          onMouseEnter={handleHover}
          onMouseLeave={handleLeave}
        >
          {data.map((item, index) => (
            <motion.div
              key={index}
              className="flex-shrink-0 h-20 mx-1 text-center bg-gray-200"
              onClick={stopContinuousAnimation}
            >
              <div className="text-gray-500 p-4">
                <div className="font-bold text-lg">{item.count}</div>
                <div>{item.description}</div>
              </div>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </div>
  );
}
