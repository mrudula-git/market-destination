import React, { useState } from "react";
import { Icon } from "@iconify/react/dist/iconify.js";

interface Accommodation {
  title: string;
  imageURL: string;
  rating: number;
  review: string;
  description?:string;
}

const AccommodationCard: React.FC<Accommodation> = ({
  title,
  imageURL,
  rating,
  review,
  description
}) => {
    const [userRating, setUserRating] = useState<number>(rating);
    const generateStarElements = () => {
        const clampedRating = Math.min(Math.max(userRating, 0), 5); // Clamp userRating within 0 to 5
        const starElements = [];
      
        for (let i = 0; i < 5; i++) {
          const starType =
            clampedRating >= i + 1 ? (
              <Icon className="hover:text-red-500" icon="codicon:star-full" />
            ) : clampedRating > i && clampedRating < i + 1 ? (
              <Icon className="hover:text-red-500" icon="codicon:star-half" />
            ) : (
              <Icon className="hover:text-red-500" icon="codicon:star-empty" />
            );
      
          starElements.push(starType);
        }
      
        return starElements;
      };
      

  return (
    <div className="md:flex md:flex-row-2 gap-2 sm:gap-4 md:border md:h-64 flex-col sm:flex-row md:rounded-lg md:bg-slate-50">
      <div className="row-span-4 md:w-1/3 md:border sm:order-1">
        <div className="flex items-center justify-center  md:justify-center md:flex-none md:pb-60">
          <img
            src={imageURL}
            alt={title}
            className="w-64 h-64 object-cover md:rounded-lg"
          />
        </div>
      </div>

      <div className="text-center mx-auto items-center justify-center md:w-2/3 md:col-span-3 sm:order-2">
        <div>
          <div>
            <h3 className="text-xl font-semibold md:px-2 py-2 font-sans">{title}</h3>
          </div>
        </div>
        <div className="col-span-4 order-1 lg:order-2">
          <p className="text-gray-600 font-normal py-2 text-1xl">{review}</p>
          <div>
            <p className="text-gray-600 text-base mb-2 xl:pb-2 sm:hidden lg:block">
              {description}
            </p>
            <div className="flex items-end justify-center md:justify-end w-full md:px-8">
              <p className="text-end">
                <div className="flex sm:text-center items-center space-x-1">
                  {generateStarElements()} ({rating})
                </div>
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

const App = () => {
  const dummyData: Accommodation[] = [
    {
      title: "1. The Corinthians Resort & Club",
      imageURL:
        "https://a0.muscache.com/im/pictures/6d97f1b6-2dd7-4d7e-ba28-80f0a2005ace.jpg?im_w=720",
      rating: 2, // Replace with your actual rating value
      description:"Excellent services with cooperative staff and prompt services.",
      review:
        "Another example review text.",
    },
    {
      title: "2. Another Accommodation",
      imageURL: "https://images.unsplash.com/photo-1488155436641-58ef42fcc44e?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8NTV8fGdvb2dsZSUyMG1hcHxlbnwwfHwwfHx8MA%3D%3D",
      rating: 4,
      description:"Excellent services with cooperative staff and prompt services.",
      review: "Another example review text.",
    },
    // Add more accommodation objects as needed
  ];

  return (
    <div className=" py-4">
      <h1 className="text-2xl text-center font-bold mb-4">Accommodation Cards</h1>
      {dummyData.map((data, index) => (
        <div className="py-3">
        <AccommodationCard key={index} {...data} />
        </div>
      ))}
    </div>
  );
};

export default App;
