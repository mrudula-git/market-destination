import type {
  Users,
  Listings,
  Reviews,
  ListingsCategories,
  Reviewers,
} from "database";
import { baseUrl } from "../../constants/apis";

type Args = {
  url?: string;
  api?: string;
  body?: object | null;
  method?: string;
  queryParams?: Record<string, string | number | boolean>;
};

type Resources = {
  [x: string]: any;
  processedData: any;
  users?: Users[];
  listing?: Listings | null;
  listings?: Listings[] | null;
  categories?: ListingsCategories[] | null;
  Reviews?: Reviews[] | null;
  reviewSummary: any;
  // listing_types?: ListingTypes[];
  review?: Reviews | null;
  reviews?: Reviews[] | null;
  reviewers?: Reviewers[] | null;
};

export default async function apiKit({
  url,
  api,
  body = null,
  method = "GET",
  queryParams = {},
}: Args): Promise<Resources> {
  try {
    const queryString = new URLSearchParams(queryParams).toString();
    const _url =
      url ??
      baseUrl +
        api +
        (method === "GET" && queryString ? `?${queryString}` : "");
    console.log(_url);

    // console.log("apiKit", { url: _url, api, body, method, queryParams });
    const response = await fetch(_url, {
      method,
      body: method === "GET" ? null : JSON.stringify(body),
      credentials: "include",
      headers: {
        "Content-Type": "application/json",
      },
      cache: "no-store",
    });

    let data: Resources;

    if (response.status >= 200 && response.status < 300) {
      data = (await response.json()) as Resources;
    }

    return data;
  } catch (error) {
    console.error("apiKit ERROR", error);
    throw error;
  }
}
