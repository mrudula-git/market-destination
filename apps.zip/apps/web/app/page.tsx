// import Index from "../components";
import { ErrorBoundary } from "react-error-boundary";
import CardGrid from "../components/UI/Cards/card-grid";
import HeroSection from "../components/hero-section";
// import SectionFive from "../components/section-five";
import SectionFour from "../components/section-four";
import { apis } from "../constants/apis";
import apiKit from "../utils/api/helper";

async function getData() {
  const data = await apiKit({
    api: apis.listingsByCategories,
  });

  // console.log(data, "apis.listingsByCategories");
  const { categories, reviewSummary } = data;

  return { categories, reviewSummary };
}

export default async function Page(): Promise<JSX.Element> {
  const { categories, reviewSummary } = await getData();

  return (
    <main className="bg-base0">
      <>
        <title>Findigoo</title>
        <meta title="title" content={"Findigoo"} />
        <meta title="description" content={"Description"} />
        <meta name="type" content="website" />

        <meta property="og:title" content={"Findigoo"} />
        <meta property="og:description" content={"Description"} />
        <meta property="og:type" content="website" />
      </>

      <HeroSection />

      <div className="">
        <ErrorBoundary fallback={<p>CSR Inside</p>}>
          <br />
          <div className="container lg:max-w-screen-md xl:max-w-screen-lg mx-auto">
            {/* <pre>{JSON.stringify({ categories  reviewSummary }, null, 2)}</pre> */}
            <CardGrid categories={categories} reviewSummary={reviewSummary} />
          </div>
          <br />
          <br />
        </ErrorBoundary>
      </div>

      <SectionFour />

      <br />
      <br />
      <br />
    </main>
  );
}
