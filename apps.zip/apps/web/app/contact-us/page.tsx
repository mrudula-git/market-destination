"use client";

import { useState } from "react";
import { validateField, formErrors } from "./validationUtils";
import { apis } from "../../constants/apis";
import apiKit from "../../utils/api/helper";
import ContactUsSubmission from "./contact-us-submission";

export default function ContactUs() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    message: "",
  });

  const [validationErrors, setValidationErrors] = useState({
    name: "",
    email: "",
    phone: "",
    message: "",
  });

  const [formSubmitted, setFormSubmitted] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  const handleChange = (e) => {
    const { name, value } = e.target;

    setFormData({
      ...formData,
      [name]: value,
    });

    const error = validateField(name, value, {
      required: true,
      minLength: name === "message" ? 10 : undefined,
      maxLength: name === "message" ? 500 : undefined,
    });

    setValidationErrors({
      ...validationErrors,
      [name]: error,
    });
  };

  const scrollToFirstError = () => {
    const ErrorField = Object.keys(validationErrors).find(
      (field) => validationErrors[field] !== ""
    );

    if (ErrorField) {
      const errorElement = document.getElementById(`${ErrorField}-error`);

      if (errorElement) {
        const yOffset = -100;
        const y =
          errorElement.getBoundingClientRect().top +
          window.pageYOffset +
          yOffset;

        // console.log(`Scrolling to field with name: ${ErrorField}`);
        window.scrollTo({ top: y, behavior: "smooth" });

        const fieldWithError = document.getElementById(ErrorField);
        if (fieldWithError) {
          fieldWithError.focus();
          // console.log(`Setting focus on field: ${ErrorField}`);
        }
      }
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (isLoading) {
      return;
    }

    setIsLoading(true);

    const errors = {};
    Object.keys(formData).forEach((name) => {
      const value = formData[name];
      const error = validateField(name, value, {
        required: true,
        minLength: name === "message" ? 10 : undefined,
        maxLength: name === "message" ? 500 : undefined,
      });
      errors[name] = error;
    });

    // If there are validation errors, don't submit the form
    if (Object.values(errors).some((error) => error !== "")) {
      setValidationErrors(errors);
      scrollToFirstError();
      setIsLoading(false);
      return;
    }

    const source = window.location.pathname;

    try {
      const response = await apiKit({
        method: "POST",
        api: apis.contactus,
        body: { ...formData, source: source },
      });
      if (response.feedback) {
        // const { feedback } = response.feedback;

        // console.log("Form submitted successfully!", response.feedback);

        setFormSubmitted(true);
      } else {
        console.error("Unexpected response format:", response);
      }
    } catch (error) {
      console.error("Error submitting form:", error);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <>
      <title>Findigoo | Contact us</title>
      <div className="bg-base0 text-primary1">
        <div className="max-w-screen-lg mx-auto px-2">
          <br />
          <div>
            {formSubmitted ? (
              <ContactUsSubmission />
            ) : (
              <form className="max-w-md mx-auto">
                <h2 className="text-2xl font-semibold mb-2">Contact Us</h2>
                <div className="mb-4">
                  <label className="block font-semibold" htmlFor="name">
                    Name
                  </label>
                  <input
                    className="block w-full px-4 rounded-full border border-primary1 focus:border-primary1 bg-transparent focus:outline-none focus:ring-0"
                    id="name"
                    name="name"
                    placeholder="Enter your name"
                    onChange={handleChange}
                    type="text"
                    value={formData.name}
                  />
                  {validationErrors.name && (
                    <p id="name-error" className="text-red-500">
                      {validationErrors.name}
                    </p>
                  )}
                </div>
                <div className="mb-4">
                  <label className="block font-semibold" htmlFor="email">
                    Email
                  </label>
                  <input
                    className="block w-full px-4 rounded-full border border-primary1 focus:border-primary1 bg-transparent focus:outline-none focus:ring-0"
                    id="email"
                    name="email"
                    placeholder="Enter your email"
                    onChange={handleChange}
                    type="email"
                    value={formData.email}
                  />
                  {validationErrors.email && (
                    <p id="email-error" className="text-red-500">
                      {validationErrors.email}
                    </p>
                  )}
                </div>
                <div className="mb-4">
                  <label className="block font-semibold" htmlFor="phone">
                    Mobile Number
                  </label>
                  <input
                    className="block w-full px-4 rounded-full border border-primary1 focus:border-primary1 bg-transparent focus:outline-none focus:ring-0"
                    id="phone"
                    name="phone"
                    placeholder="Enter your mobile number"
                    onChange={handleChange}
                    type="text"
                    value={formData.phone}
                  />
                  {validationErrors.phone && (
                    <p id="phone-error" className="text-red-500">
                      {validationErrors.phone}
                    </p>
                  )}
                </div>
                <div className="mb-4">
                  <label className="block font-semibold" htmlFor="message">
                    Message
                  </label>
                  <textarea
                    className="block w-full px-4 rounded-lg border border-primary1 focus:border-primary1 bg-transparent focus:outline-none focus:ring-0"
                    id="message"
                    name="message"
                    placeholder="Enter your message"
                    onChange={handleChange}
                    rows={6}
                    value={formData.message}
                  />
                  {validationErrors.message && (
                    <p id="message-error" className="text-red-500">
                      {validationErrors.message}
                    </p>
                  )}
                </div>
                <div>
                  <button
                    // className="bg-primary1 text-base0 font-semibold py-2 px-4 rounded-full"
                    className={`bg-${
                      isLoading ? "slate-400" : "primary1"
                    } text-base0 font-semibold py-2 px-4 rounded-full`}
                    type="submit"
                    onClick={handleSubmit}
                    disabled={isLoading}
                  >
                    {isLoading ? "Submitting..." : "Submit"}
                  </button>
                </div>
              </form>
            )}
          </div>
          <br />
          {/* <div className="p-8 border-2 rounded-md border-theme-orange">
            <h4 className="text-xl font-semibold mb-2">Contacts</h4>
            <br />
            <p>
              Phone:{" "}
              <a className="underline" href="tel:+919594646353">
                +919594646353
              </a>
            </p>
            <p>
              Email:{" "}
              <a className="underline" href="mailto:support@findigoo.com">
                support@findigoo.com
              </a>
            </p>
            <p>
              Address: 309/A, Bhavin Apartment, Chandansar Road, Virar East,
              401305.
            </p>
          </div> */}
        </div>
      </div>
      <br />
      <br />
      <br />
    </>
  );
}
