import React from "react";
import { Icon } from "@iconify/react";

export default function ContactUsSubmission() {
  return (
    <div className="bg-primary2 text-theme-text-light p-8 rounded-md text-center shadow transition-shadow mt-8">
      <div className="mb-4">
        <Icon
          className="text-5xl rounded-full mx-auto"
          icon="ic:round-done-all"
        />
      </div>
      <h2 className="text-2xl font-bold mb-4">Message Sent Successfully!</h2>
      <p className="text-base font-medium leading-relaxed">
        Thank you for reaching out to us. Your message has been successfully
        submitted. Our team will review your inquiry and get back to you as soon
        as possible.
      </p>
    </div>
  );
}
