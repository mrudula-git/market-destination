import "../styles/globals.css";
import { DM_Sans } from "next/font/google";
import Navigation from "../components/Sections/Navigation/navigation";
import Footer from "../components/Sections/Footer/footer";
import LoadingIndicator from "../components/UI/Indicators/loading-indicators";

const sans = DM_Sans({
  weight: ["300", "400", "500", "600", "700", "800", "900"],
  subsets: ["latin"],
});

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}): JSX.Element {
  return (
    <html lang="en">
      <body className={sans.className}>
        <LoadingIndicator />
        <Navigation />
        {children}
        <Footer />
      </body>
    </html>
  );
}
