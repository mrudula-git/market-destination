"use client";
import { Combobox } from "@headlessui/react";
import { useCallback, useEffect, useState } from "react";
import { debounce } from "underscore";
import { apis } from "../../constants/apis";
import apiKit from "../../utils/api/helper";
import { useRouter } from "next/navigation";
import { routes } from "../../constants/routes";

interface CompareSearchProps {
  onSelectionChange?: (value: any) => void;
  leftId: string;
}

export default function CompareSearch({ leftId }: CompareSearchProps) {
  const router = useRouter();

  const [input, setInput] = useState("");
  const [query, setQuery] = useState("");
  const [results, setResults] = useState([]);

  const debounceQuery = useCallback(
    debounce((_input: string) => {
      setQuery(_input);
    }, 1000),
    []
  );

  useEffect(() => {
    debounceQuery(input);
  }, [input, debounceQuery]);

  useEffect(() => {
    if (!leftId) return;
    if (!query) return;

    (async () => {
      try {
        const { listings } = await apiKit({
          api: apis.listingCompareSearch,
          method: "POST",
          body: {
            query: query,
            exclude: [leftId],
          },
        });

        setResults(listings);
      } catch (error) {
        setResults([]);
      }
    })();
  }, [query, leftId]);

  return (
    <div className="dm-compare">
      <Combobox
        onChange={(value) => {
          if (!value) return null;
          window.location.replace(routes.compareLeftRight(leftId, value?.id));
        }}
      >
        <Combobox.Input
          className="w-full border-0 flex-grow px-6 bg-transparent focus:outline-none focus:ring-0 border-theme-red shadow shadow-theme-orange focus:bg-opacity-50 rounded-full transition-colors"
          placeholder="Search to compare"
          onChange={(event) => {
            setInput(event.target.value);
          }}
          value={input}
        />

        <Combobox.Options className="sm:absolute z-10 rounded-xl overflow-hidden mt-2 text-theme-text-dark bg-base0 shadow-md">
          {results.map((item) => (
            <Combobox.Option key={item.id} value={item}>
              <div className="text-start p-3 cursor-pointer">
                <div className="font-medium">{item.name}</div>
                <div className="text-sm">
                  {item?.contacts?.address ||
                    "" + " " + item?.contacts?.city ||
                    "" + " " + item?.contacts?.state ||
                    ""}
                </div>
              </div>
            </Combobox.Option>
          ))}
        </Combobox.Options>
      </Combobox>
      {/* <pre>{JSON.stringify({ results }, null, 2)}</pre> */}
    </div>
  );
}
