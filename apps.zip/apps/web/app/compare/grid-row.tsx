import type { ReactNode } from "react";
import { humanize } from "underscore.string";

type GridRowProps = {
  label?: string;
  contents?: string[] | number[];
  children?: ReactNode[];
};

export default function GridRow({ label, contents, children }: GridRowProps) {
  let components = [];
  if (contents?.length) {
    components = contents;
  } else if (children?.length) {
    components = children;
    // components = Children.toArray(children).map((el) => el);
  }

  return (
    <div className="">
      <div className="flex divide-x divide-theme-orange border-b border-theme-orange divide-opacity-50 hover:bg-gray-100">
        <div className="p-2 flex-grow min-w-32 sm:min-w-48 max-w-min">
          {humanize(label as string)}
        </div>
        <div
          id="scroll-container"
          className="flex-grow flex divide-x divide-theme-orange overflow-x-scroll dm-scrollbar-hide divide-opacity-50 "
          onScroll={(event) => {
            const targetScrollLeft = event.target?.scrollLeft;
            const els = document.querySelectorAll("#scroll-container");
            els.forEach((el) => {
              el.scrollLeft = targetScrollLeft;
            });
          }}
        >
          {components.map((component, key) => (
            <div className="p-2 min-w-80 flex-1" key={key}>
              {component}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
