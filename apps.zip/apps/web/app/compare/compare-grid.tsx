import { Icon } from "@iconify/react";
import type {
  Contacts,
  Listings,
  ListingsAttributes,
  ListingsPackages,
  Locations,
  Media,
} from "database";
import { useCallback, useEffect, useMemo, useState } from "react";
import SocialMediaComponent from "../../components/socialMediaCompare";
import { apis } from "../../constants/apis";
import apiKit from "../../utils/api/helper";
import AutoAttributeDetails from "../[listing_name]/auto-attribute-details";
import CompareSearch from "./compare-search";
import GridRow from "./grid-row";
import GridRowGroup from "./grid-row-group";
import { humanize } from "underscore.string";

type CompareListings = Partial<Listings> & {
  contacts: Partial<Contacts>;
  location: Partial<Locations>;
  photos: Partial<Media>[];
  packages: ListingsPackages[];
  attributes: Partial<ListingsAttributes> &
    { value: string | number | boolean | null }[];
};

type CompareGridProps = {
  left: CompareListings;
  right?: CompareListings | null;
};

// async function getData({ idSet, idSet2, attributeIds, ids }: any) {
//   try {
//     const data = await apiKit({
//       api: apis.listingsAttributesCompare,
//       method: "POST",
//       body: {
//         categoriesId: idSet,
//         attributeGroupsId: idSet2,
//         attributeIds: attributeIds,
//         ids: ids,
//       },
//     });

//     // console.log(data);
//     return data;
//   } catch (error) {
//     console.error("Error fetching data:", error);
//     throw error;
//   }
// }

export default function CompareGrid({ left, right = null }: CompareGridProps) {
  // const [right, setRight] = useState(initialRight);

  // function onSelectionChange(value) {
  //   console.log(value);
  //   setRight(value);
  // }

  const [result, setResult] = useState({});

  const extractAttributeIds = (obj) => {
    if (!obj || Object.keys(obj).length === 0) return [];
    return obj?.attributes?.map((attribute) => attribute.id);
  };

  const allAttributeIds = [
    ...new Set([...extractAttributeIds(left), ...extractAttributeIds(right)]),
  ];

  useEffect(() => {
    // if (!right) return;

    const categoryIdsSet = new Set([
      ...(left?.categoriesId || []),
      ...(right?.categoriesId || []),
    ]);
    const attributesIdsSet = new Set([
      ...(left?.attributeGroupsId || []),
      ...(right?.attributeGroupsId || []),
    ]);

    const ids = [left?.id, right?.id];

    (async () => {
      try {
        const data = await apiKit({
          api: apis.listingsAttributesCompare,
          method: "POST",
          body: {
            categoriesId: categoryIdsSet,
            attributeGroupsId: attributesIdsSet,
            attributeIds: allAttributeIds,
            ids,
          },
        });

        console.log("result", data);
        setResult(data);
      } catch (error) {
        console.error("Error fetching data:", error);
        throw error;
      }
    })();
  }, []);

  const [ratingsKeys, setRatingsKeys] = useState([]);

  const serializeReviews = useCallback(() => {
    if (!result?.reviewSummary) return;

    const _ratingsSet = new Set();

    if (left) {
      left.reviewSummary = result.reviewSummary.find(
        (el) => el.listingsId === left.id
      );
      Object.keys(left?.reviewSummary ?? {}).forEach((el) =>
        _ratingsSet.add(el)
      );
    }

    if (right) {
      right.reviewSummary = result.reviewSummary.find(
        (el) => el.listingsId === right.id
      );
      Object.keys(right?.reviewSummary ?? {}).forEach((el) =>
        _ratingsSet.add(el)
      );
    }

    setRatingsKeys(Array.from(_ratingsSet));
  }, [result]);

  const populatedLeftAttributes = useMemo(() => {
    if (!result?.categories || !result?.attributeGroups) return null;

    const categories = result?.categories;
    const attributeGroups = result?.attributeGroups;
    const attributes = left.attributes;
    let _populatedAttributes = structuredClone([
      ...attributeGroups,
      ...categories,
    ]);
    let _attributesList = attributes.map((el) => el.id);
    _populatedAttributes.forEach((group) => {
      const _attributes = [];
      group.attributesId?.forEach((id) => {
        if (_attributesList.includes(id)) {
          _attributes.push(attributes.find((el) => el.id === id));
        }
      });
      group.attributes = _attributes;
    });

    // console.log("Left", _populatedAttributes);
    return _populatedAttributes;
    // }, [left, result?.categories, result?.attributeGroups]);
  }, [left, result]);

  const populatedRightAttributes = useMemo(() => {
    if (!result?.categories || !result?.attributeGroups) return null;

    const categories = result?.categories;
    const attributeGroups = result?.attributeGroups;
    const attributes = right?.attributes;
    let _populatedAttributes = structuredClone([
      ...attributeGroups,
      ...categories,
    ]);
    let _attributesList = attributes?.map((el) => el.id);
    _populatedAttributes?.forEach((group) => {
      const _attributes = [];
      group.attributesId?.forEach((id) => {
        if (_attributesList?.includes(id)) {
          _attributes.push(attributes?.find((el) => el.id === id));
        }
      });
      group.attributes = _attributes;
    });

    // console.log("Right", _populatedAttributes);
    return _populatedAttributes;
    // }, [right, result?.categories, result?.attributeGroups]);
  }, [right, result]);

  const [offeringsKey, setOfferingsKeys] = useState([]);

  const serializePopulatedAttributes = useCallback(() => {
    const _offeringsSet = new Set();

    if (left && populatedLeftAttributes) {
      left.attributes = populatedLeftAttributes;
      left.attributes.forEach((el) => _offeringsSet.add(el.name));
    }

    if (right && populatedRightAttributes) {
      right.attributes = populatedRightAttributes;
      right.attributes.forEach((el) => _offeringsSet.add(el.name));
    }

    setOfferingsKeys(Array.from(_offeringsSet));
  }, [left, populatedLeftAttributes, right]);

  useEffect(() => {
    if (result.reviewSummary) {
      serializeReviews();
    }

    if (result.categories || result.attributeGroups) {
      serializePopulatedAttributes();
    }

    // if (right && right !== null && right !== undefined) {
    //   let existingParams = new URLSearchParams(window.location.search);
    //   existingParams.set("right", `${right?.id}`);
    //   const newUrl = `${window.location.pathname}?${existingParams.toString()}`;
    //   router.push(newUrl);
    // }
  }, [result]);

  // console.log({ left, right });

  return (
    <div className="dm-compare-grid">
      <h1 className="text-2xl font-semibold">Comparison</h1>
      <br />

      <div className="mx-2">
        <GridRow key="compare-search">
          <div></div>
          <div className="py-4">
            <CompareSearch
              // onSelectionChange={onSelectionChange}
              leftId={left?.id!}
            />
          </div>
        </GridRow>

        <GridRow key="introduction">
          {[left, right].map((listing) => (
            <div key={listing?.id} className="flex flex-col">
              <div className="flex mb-2">
                <div className="flex-grow">
                  <h2 className="text-lg font-bold">{listing?.name}</h2>
                </div>
                <div>
                  <div className="text-right">
                    {listing?.slug && (
                      <a
                        href={listing.slug}
                        className="inline-flex items-center gap-2 hover:underline"
                      >
                        <span>Open</span>
                        <Icon icon={"ic:baseline-arrow-outward"} />
                      </a>
                    )}
                  </div>
                </div>
              </div>
              <div className="grid grid-cols-1">
                {listing?.photos[0]?.url && (
                  <div className="h-32 w-32 aspect-square place-self-center self-center mb-4 rounded-lg overflow-hidden">
                    <img
                      className="aspect-square object-center object-cover"
                      src={listing?.photos[0]?.url}
                    />
                  </div>
                )}
              </div>
            </div>
          ))}
        </GridRow>

        <div className="">
          <GridRowGroup label="Packages" key="packages-group">
            <GridRow>
              {[left, right].map((listing) => (
                <div key={listing?.id}>
                  {listing?.packages?.map((pkg, index) => (
                    <div
                      className="p-2 mb-2 grid grid-cols-5 gap-2"
                      key={index}
                    >
                      <div className="col-span-3">
                        <div className="p-2 font-bold">{pkg?.name}</div>
                        <div className="">
                          <div className="flex items-end gap-2">
                            <Icon
                              className="w-5 h-5"
                              icon={"ic:sharp-supervisor-account"}
                            />
                            <span className="text-sm font-black">{`${pkg?.persons}`}</span>
                            <span className="font-medium">Person(s)</span>
                          </div>
                        </div>
                      </div>
                      <div className="p-2 col-span-2 text-end text-sm font-black">
                        ₹ {pkg?.price?.amount}
                      </div>
                    </div>
                  ))}
                </div>
              ))}
            </GridRow>
          </GridRowGroup>

          <GridRowGroup label="Offerings" key="offerings-group">
            {offeringsKey.map((key) => (
              <>
                {left?.attributes.find(({ name }) => name === key)?.attributes
                  ?.length ||
                right?.attributes.find(({ name }) => name === key)?.attributes
                  ?.length ? (
                  <>
                    <GridRow label={key} key={key}>
                      {[left, right].map((listing) => (
                        <div key={listing?.id}>
                          {listing?.attributes.find(({ name }) => name === key)
                            ?.attributes?.length ? (
                            <div>
                              {listing?.attributes
                                .find(({ name }) => name === key)
                                ?.attributes?.map((attribute) => (
                                  <AutoAttributeDetails
                                    key={attribute.id}
                                    {...attribute}
                                  />
                                ))}
                            </div>
                          ) : null}
                        </div>
                      ))}
                    </GridRow>
                  </>
                ) : null}
              </>
            ))}
          </GridRowGroup>

          <GridRowGroup label="Things to do">
            <GridRow key="location">
              {[left, right].map((listing) => (
                <div key={listing?.id}>
                  <ul>
                    {listing?.thingsToDo && listing.thingsToDo.length > 0
                      ? listing.thingsToDo.map((item, index) => (
                          <li key={index} className="font-medium">
                            {humanize(item)}
                          </li>
                        ))
                      : null}
                  </ul>
                </div>
              ))}
            </GridRow>
          </GridRowGroup>

          <GridRowGroup label="Ratings" key="reviews-group">
            <GridRow key="reviews" label="Overall">
              {[left, right].map((listing) => (
                <div key={listing?.id}>
                  {listing?.reviewSummary &&
                    listing.id === listing.reviewSummary.listingsId && (
                      <p>
                        <span className="text-xl font-semibold">
                          {listing.reviewSummary.averageRating?.toFixed(1)}
                        </span>{" "}
                        <span>
                          {listing.reviewSummary.totalReviews ? (
                            <>{"/" + listing.reviewSummary.totalReviews}</>
                          ) : (
                            0
                          )}
                        </span>
                      </p>
                    )}
                </div>
              ))}
            </GridRow>

            {ratingsKeys.slice(3).map((key, index) => (
              <GridRow label={key} key={key}>
                {[left, right].map((listing) => (
                  <div key={listing?.id}>
                    {listing?.reviewSummary &&
                      listing.id === listing.reviewSummary.listingsId && (
                        <p>
                          <span className="font-semibold">
                            {listing?.reviewSummary &&
                            !isNaN(
                              parseFloat(listing.reviewSummary[key]?.average)
                            )
                              ? listing.reviewSummary[key].average.toFixed(1)
                              : "0"}
                          </span>
                        </p>
                      )}
                  </div>
                ))}
              </GridRow>
            ))}
          </GridRowGroup>

          <GridRowGroup label="General">
            <GridRow key="location" label="Location">
              {[left, right].map((listing) => (
                <div key={listing?.id}>
                  <p className="">{listing?.location?.name}</p>
                  <p className="">{listing?.contacts?.address}</p>
                  <p className="">
                    {listing?.contacts.city}, {listing?.contacts?.state}
                  </p>
                </div>
              ))}
            </GridRow>

            <GridRow key="language" label="language">
              {[left, right].map((listing) => (
                <div key={listing?.id}>
                  {listing?.languages &&
                    listing.languages.length > 0 &&
                    listing.languages.map((item, index) => (
                      <p key={index} className="">
                        {humanize(item)}
                      </p>
                    ))}
                </div>
              ))}
            </GridRow>
            <GridRow key="social media" label="Social Media">
              {[left, right].map((listing) => (
                <div key={listing?.id}>
                  <SocialMediaComponent
                    socialMediaURLs={listing?.socialMediaURLs}
                  />
                </div>
              ))}
            </GridRow>
          </GridRowGroup>

          {/* <ListingPackages packages={left?.packages} /> */}
        </div>
      </div>
    </div>
  );
}
