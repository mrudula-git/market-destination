"use client";

import { useEffect, useState } from "react";
import apiKit from "../../utils/api/helper";
import { apis } from "../../constants/apis";
import CompareGrid from "./compare-grid";
import type { Listings } from "database";
import Spinner from "../../components/spinner";
import { useSearchParams } from "next/navigation";

type ComparePageProps = {
  search: string;
  searchParams: {
    left: string;
    right: string | undefined;
  };
};

// /compare?left=65954cac0f0b3a88a21a84e9&right=65954a390f0b3a88a21a84e4
export default function ComparePage({ search }: ComparePageProps) {
  const searchParams = Object.fromEntries(useSearchParams());
  const { left: leftId, right: rightId } = searchParams;
  const [leftListing, setLeftListing] = useState(null);
  const [rightListing, setRightListing] = useState(null);

  useEffect(() => {
    (async () => {
      const { left, right } = await apiKit({
        api: apis.listingsCompare,
        method: "POST",
        body: {
          left: leftId,
          right: rightId,
        },
      });

      setLeftListing(left);
      setRightListing(right);
    })();
  }, []);

  return (
    <div className="bg-base0 text-primary1">
      <>
        <title>Findigoo | Compare</title>
        <meta
          title="title"
          content={`Compare ${leftListing?.name} and ${rightListing?.name} `}
        />
        <meta
          name="description"
          content={`Compare ${leftListing?.name} and ${rightListing?.name} `}
        />
        <meta name="type" content="website" />

        <meta
          property="og:title"
          content={`Compare ${leftListing?.name} and ${rightListing?.name} `}
        />
        <meta
          property="og:description"
          content={`Compare ${leftListing?.name} and ${rightListing?.name} `}
        />
        <meta property="og:type" content="website" />
      </>

      <div className="max-w-screen-lg mx-auto">
        {leftListing?.name ? (
          <CompareGrid left={leftListing} right={rightListing || null} />
        ) : (
          <div className="flex h-[60vh] items-center justify-center">
            <Spinner />
          </div>
        )}
      </div>
      <br />
      <br />
    </div>
  );
}
