import { Disclosure, Transition } from "@headlessui/react";
import type { ReactNode } from "react";
import { useState } from "react";
import { humanize } from "underscore.string";
import { Icon } from "@iconify/react";

type GridRowGroupProps = {
  label?: string;
  children?: ReactNode;
};

export default function GridRowGroup({ label, children }: GridRowGroupProps) {
  const [isOpen, setIsOpen] = useState(true);

  return (
    <div>
      <Disclosure defaultOpen={true}>
        <>
          <Disclosure.Button
            className="flex items-center w-full text-left relative"
            onClick={() => setIsOpen(!isOpen)}
          >
            <div className="flex-grow">
              <h3 className="py-3 px-6 border-b-2 border-theme-orange bg-theme-orange text-theme-text-light text-xl font-bold">
                {humanize(label as string)}
              </h3>
            </div>
            <div className="ml-2 text-theme-text-light absolute right-6 font-semibold text-2xl">
              {isOpen ? (
                <Icon icon="ion:chevron-up-sharp" />
              ) : (
                <Icon icon="ion:chevron-down-sharp" />
              )}
            </div>
          </Disclosure.Button>
          <Transition
            enter="transition duration-100 ease-out"
            enterFrom="transform scale-y-95 opacity-0"
            enterTo="transform scale-y-100 opacity-100"
            leave="transition duration-75 ease-out"
            leaveFrom="transform scale-y-100 opacity-100"
            leaveTo="transform scale-y-95 opacity-0"
          >
            <Disclosure.Panel>
              <div>{children}</div>
            </Disclosure.Panel>
          </Transition>
        </>
      </Disclosure>
    </div>
  );
}
