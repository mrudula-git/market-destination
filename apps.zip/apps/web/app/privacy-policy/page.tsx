export default function PrivacyPolicy() {
  return (
    <>
      <>
        <title>Findigoo | Privacy policy</title>
      </>
      <div className="bg-base0 text-primary1">
        <div className="max-w-screen-lg mx-auto px-2">
          <div className="min-h-[50vh]">
            <br />
            <h2 className="text-2xl font-semibold mb-2">Privacy Policy</h2>
            <p>
              This Privacy Policy governs the manner in which Findigoo collects,
              uses, maintains, and discloses information collected from users
              (referred to as “Users” or “you”) of the Findigoo website
              (“Website”) located at Findigoo.com. This Privacy Policy applies
              to the Website and all products and services offered by Findigoo
              Infotainment Pvt. Ltd.
            </p>
            <br />

            <h3 className="text-xl font-semibold mb-2">
              <u>Personal Information Collection</u>
            </h3>
            <ol type="a" className="ml-4 legal-contents-lists">
              <li>
                Findigoo may collect personal information from Users in various
                ways, including but not limited to when Users visit our Website,
                register on the Website, subscribe to our newsletter, respond to
                a survey, fill out a form, or interact with other features or
                services we provide on the Website.
              </li>
              <li>
                The types of personal information that may be collected include,
                but are not limited to, name, email address, phone number,
                postal address, and other information voluntarily submitted by
                Users.
              </li>
            </ol>
            <br />

            <h3 className="text-xl font-semibold mb-2">
              <u>Non-Personal Information Collection</u>
            </h3>
            <ol type="a" className="ml-4 legal-contents-lists">
              <li>
                Findigoo may collect non-personal information about Users
                whenever they interact with our Website. Non-personal
                information may include the browser name, the type of computer
                or device used, and technical information about Users’ means of
                connection to our Website, such as the operating system and
                internet service providers utilized.
              </li>
            </ol>
            <br />

            <h3 className="text-xl font-semibold mb-2">
              <u>Web Browser Cookies</u>
            </h3>
            <ol type="a" className="ml-4 legal-contents-lists">
              <li>
                Our Website may use “cookies” to enhance User experience. Users’
                web browsers place cookies on their hard drives for
                record-keeping purposes and sometimes to track information about
                them. Users may choose to set their web browsers to refuse
                cookies or to alert when cookies are being sent. However, doing
                so may limit some functionalities of the Website.
              </li>
            </ol>
            <br />

            <h3 className="text-xl font-semibold mb-2">
              <u>How We Use Collected Information</u>
            </h3>
            <ol type="a" className="ml-4 legal-contents-lists">
              <li>
                Findigoo may collect and use Users’ personal information for the
                following purposes: – To personalize User experience: We may use
                information to understand how our Users interact with the
                Website and provide content and offers that align with their
                preferences. – To improve our Website: We continually strive to
                enhance our Website based on the feedback and information we
                receive from Users. – To send periodic emails: We may use the
                email address to respond to inquiries, questions, and other
                requests. If Users opt to subscribe to our mailing list, they
                will receive emails that may include company news, updates,
                promotions, or related information. Users can unsubscribe from
                receiving future emails at any time.
              </li>
            </ol>
            <br />

            <h3 className="text-xl font-semibold mb-2">
              <u>Protection of Information</u>
            </h3>
            <ol type="a" className="ml-4 legal-contents-lists">
              <li>
                Findigoo adopts appropriate data collection, storage, and
                processing practices and security measures to protect against
                unauthorized access, alteration, disclosure, or destruction of
                Users’ personal information, username, password, transaction
                information, and data stored on our Website.
              </li>
            </ol>
            <br />

            <h3 className="text-xl font-semibold mb-2">
              <u>Sharing Personal Information</u>
            </h3>
            <ol type="a" className="ml-4 legal-contents-lists">
              <li>
                Findigoo does not sell, trade, or rent Users’ personal
                information to others. We may share generic aggregated
                demographic information not linked to any personal information
                regarding visitors and Users with our business partners, trusted
                affiliates, and advertisers for the purposes outlined above.
              </li>
            </ol>
            <br />

            <h3 className="text-xl font-semibold mb-2">
              <u>Changes to this Privacy Policy</u>
            </h3>
            <ol type="a" className="ml-4 legal-contents-lists">
              <li>
                Findigoo has the discretion to update this Privacy Policy at any
                time. When we do, we will post a notification on the main page
                of our Website, revise the updated date at the bottom of this
                page, and send an email to Users who have provided their email
                address. We encourage Users to frequently check this page for
                any changes to stay informed about how we are protecting the
                personal information we collect. You acknowledge and agree that
                it is your responsibility to review this Privacy Policy
                periodically and become aware of modifications.
              </li>
            </ol>
            <br />

            <h3 className="text-xl font-semibold mb-2">
              <u>Acceptance of these Terms</u>
            </h3>
            <ol type="a" className="ml-4 legal-contents-lists">
              <li>
                By using this Website, you signify your acceptance of this
                Privacy Policy. If you do not agree to this policy, please do
                not use our Website. Your continued use of the Website following
                the posting of changes to this policy will be deemed your
                acceptance of those changes.
              </li>
            </ol>
            <br />

            <h3 className="text-xl font-semibold mb-2">
              <u>Contacting Us</u>
            </h3>
            <ol type="a" className="ml-4 legal-contents-lists">
              <li>
                If you have any questions about this Privacy Policy, the
                practices of this Website, or your dealings with this Website,
                please contact us at: Email: support@findigoo.com
              </li>
            </ol>
            <br />
            <p>This Privacy Policy was last updated on 31 January 2024</p>

            <br />
            <br />
            <br />
          </div>
        </div>
      </div>
    </>
  );
}
