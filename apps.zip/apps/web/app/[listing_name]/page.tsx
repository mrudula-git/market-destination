import type { Contacts, Locations, Media } from "database";
import { apis } from "../../constants/apis";
import {
  Attribute,
  AttributeGroup,
  Category,
  Listing,
  Package,
} from "../../constants/types";
import apiKit from "../../utils/api/helper";
import Attributes from "./attributes";
import ListingIntroduction from "./listing-introduction";
import ListingNearbyMap from "./listing-map-nearby";
import ListingOffers from "./listing-offers";
import ListingPackages from "./listing-packages";
import ReviewList from "./reviews-details/review-list";
import SwiperGallery from "./swiper-gallery";
import ThingsToKnow from "./things-to-know/things-to-know";
// import Backbutton from "../../components/UI/Backbutton/back-button";
// import SimilarProperties from "./similar-properties";
import ListingCompareSuggestions from "../../components/listing-compare-suggestions";
import ListingRatingsTitle from "./listings-rating-title";
import Tags from "./tags";
import ThingsToDo from "./things-to-do";
import { notFound, redirect } from "next/navigation";
import Uniques from "./uniques";

// import { useReviewsStore } from "../../stores/zustand/review.store";

// const { listing } = data;

// const ReviewFetcher = dynamic(() => import('./reviews-details/reviewFecher'), { ssr: false })
interface PageProps {
  params: {
    listing_name: string;
  };
  reviews: any;
}

async function getData(slug: string) {
  const data = await apiKit({
    api: apis.listing(slug),
  });

  const listing: Listing = data.listing as Listing;
  // if (!listing) redirect("/404");
  if (!listing) notFound();
  return { listing };
}

export default async function ListingPage({
  params,
}: PageProps): Promise<JSX.Element | null> {
  // const [reviews, setReviews] = useState([]);
  // const reviews = useReviewsStore(state => state.reviews);
  const data = await getData(params.listing_name);
  const { listing } = data;

  // if (!listing) return notFound();

  const { contacts } = listing;
  const line1 = `${contacts.address || ""}, ${contacts.city || ""} ${
    contacts.pinCode || ""
  }`;
  const line2 = `${contacts.district || ""} ${contacts.state || ""}`;

  return (
    <div className="bg-base0 text-primary1">
      <div className="max-w-screen-lg mx-auto p-2">
        <>
          <title>{`${listing.name} | Findigoo`}</title>

          <meta title="title" content={listing.name ?? ""} />
          <meta name="description" content={listing.description ?? ""} />
          <meta
            name="keywords"
            content={listing.keywords ? listing.keywords.join(", ") : ""}
          />
          <meta name="type" content="website" />

          <meta property="og:title" content={listing.name} />
          <meta property="og:description" content={listing.description ?? ""} />
          <meta
            property="og:image"
            content={listing.photos[0]?.thumbUrl || "/favicon.ico"}
          />
          <meta
            property="og:url"
            content={process.env.NEXT_PUBLIC_ORIGIN + "/" + params.listing_name}
          />
          <meta property="og:type" content="website" />
        </>

        <br />
        <div className="flex justify-between">
          <div>
            <h1 className=" text-3xl md:text-4xl  font-extrabold">
              {listing.name}
            </h1>
            <div>
              <p>{line1}</p>
              <p>{line2}</p>
            </div>
          </div>
          <ListingRatingsTitle />
        </div>

        <br />
        <SwiperGallery photos={listing.photos as Media[]} />

        <br />
        <div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-y-3 md:gap-x-3">
            <div className="col-span-2">
              <ListingIntroduction
                description={listing.description as string}
                contacts={listing.contacts as Contacts}
                socialMediaURLs={listing.socialMediaURLs}
              />
              <Uniques uniques={listing.uniques} />
              <br />
              {/* Badges & Awards */}
              {/* Attractions */}
              <ThingsToDo listing={listing} />
              <ListingOffers />
              <Attributes
                attributes={listing.attributes as unknown as Attribute[]}
                categories={listing.categories as unknown as Category[]}
                attributeGroups={
                  listing.attributeGroups as unknown as AttributeGroup[]
                }
              />

              <br />
              <ListingCompareSuggestions listing={listing} />
            </div>
            <div className="col-span-1">
              <ListingPackages
                packages={listing.packages as unknown as Package[]}
              />
            </div>
          </div>

          <br />
          <ListingNearbyMap
            location={listing.location as Locations}
            // places={listing.places}
          />

          <br />
          <br />
          <div>
            <ReviewList
              listingsId={listing?.id || ""}
              showMore={true}
              showAll={false}
            />
          </div>

          <br />
          <br />
          {/* <div className="border h-64 w-full">ads box</div> */}

          {/* <ThingsToKnow
            attributes={listing.attributes as unknown as Attribute[]}
          /> */}

          {/* <SimilarProperties properties={properties} /> */}
        </div>

        <br />
        <br />
        <ThingsToKnow
          attributes={listing.attributes as unknown as Attribute[]}
          categories={listing.categories as unknown as Category[]}
          attributeGroups={
            listing.attributeGroups as unknown as AttributeGroup[]
          }
        />

        <br />
        <br />
        {/* <Tags tags={listing.tags} /> */}

        <br />
        <br />
        {/* <SimilarProperties properties={properties} /> */}
      </div>
    </div>
  );
}
