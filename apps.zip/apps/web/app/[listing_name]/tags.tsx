import React from "react";
import { humanize } from "underscore.string";

function Tags({ tags }: any) {
  return (
    <div>
      {tags.length > 0 && (
        <>
          <div className="font-semibold mb-2">Tags</div>
          <div className="flex flex-wrap gap-2">
            {tags.map((item: string) => (
              <div key={item}>
                <span className="text-sm border border-primary1 border-opacity-80 text-primary1 text-opacity-80 py-2 px-4 rounded-full">
                  {humanize(item)}
                </span>
              </div>
            ))}
          </div>
        </>
      )}
    </div>
  );
}

export default Tags;
