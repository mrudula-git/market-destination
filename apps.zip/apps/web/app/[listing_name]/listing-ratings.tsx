"use client";

import { useWindowSize } from "@uidotdev/usehooks";
import type { ReviewDetails, Reviewers, Reviews } from "database";
import Image from "next/image";
import { useEffect, useMemo, useState } from "react";
import { ErrorBoundary } from "react-error-boundary";
import { SolarStarsBoldDuotone } from "./icons/solar-stars-bold-duotone";
import { calculateRatings } from "./reviews-details/calculateRating";

type Review = Partial<Reviews> & {
  details: ReviewDetails;
  reviewer: Reviewers;
};

type ListingRatingsProps = {
  reviews: Review[];
};

type Rating = {
  name: string;
  icon?: string;
  value: string;
};

export default function ListingRatings({ reviews }: ListingRatingsProps) {
  const { width } = useWindowSize();

  const [ratings, setRatings] = useState<Rating[]>([]);

  useEffect(() => {
    const fetchAndCalculateRatings = async () => {
      const calculatedRatings = await calculateRatings(reviews);
      setRatings(calculatedRatings);
    };
    fetchAndCalculateRatings();
  }, [reviews]);

  return (
    <div>
      <div className="pt-2">
        {/* <img
          alt="logo"
          className=" p-4 ms-2 fill-current h-24 w-24"
          src="https://cdn-icons-png.flaticon.com/128/2107/2107957.png"
        /> */}

        <div className="flex justify-center md:justify-start items-center gap-2">
          <div>
            <ErrorBoundary fallback={<span>{ratings[0]?.value}</span>}>
              {/* <Icon icon={"solar:stars-bold-duotone"} /> */}
              <SolarStarsBoldDuotone className="text-theme-red w-16 h-16" />
            </ErrorBoundary>
          </div>
          <div>
            <p className="text-xs">{ratings[0]?.name}</p>
            <p className="text-5xl font-extrabold">{ratings[0]?.value}</p>
          </div>
        </div>

        <br />
        <div className="mx-2 md:mx-4 grid grid-cols-4 justify-items-center md:block">
          {ratings.slice(1).map((el, key) => (
            <div key={key}>
              <div className="flex items-center gap-4">
                <div className="flex gap-2">
                  <Image
                    src={el.icon}
                    width={width >= 768 ? 36 : 24}
                    height={width >= 768 ? 36 : 24}
                  />
                  <p className="md:hidden text-lg font-bold">
                    {isNaN(el.value) ? (
                      <span className="text-xs">None</span>
                    ) : (
                      el.value
                    )}
                  </p>
                </div>
                <div className="hidden md:block">
                  <p className="text-xs">{el.name}</p>
                  <p className="text-lg font-bold">
                    {isNaN(el.value) ? (
                      <span className="text-xs">No ratings</span>
                    ) : (
                      el.value
                    )}
                  </p>
                </div>
              </div>
              <p className="md:hidden text-xs">{el.name}</p>
              <br />
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
