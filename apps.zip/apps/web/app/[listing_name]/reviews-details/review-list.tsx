"use client";

import { useEffect, useState, useRef, lazy, Suspense, use } from "react";
import ListingRatings from "../listing-ratings";
import Modal from "../../../components/UI/Modals/modal";
import ReviewsTabs from "../../../components/UI/Tabs/reviews-tabs";
import ReviewCard from "../../../components/UI/Cards/review-card";
import { twMerge } from "tailwind-merge";
import { Spinner } from "flowbite-react";
import { useReviewsStore } from "../../../stores/zustand/review.store";
import { ErrorBoundary } from "react-error-boundary";
import { ReviewFetcher } from "./reviewFecher";

interface ReviewListProps {
  listingsId: string;
  showMore: boolean;
  showAll: boolean;
}

export default function ReviewList({
  listingsId,
  showMore,
  showAll,
}: ReviewListProps): JSX.Element {
  const reviews = useReviewsStore((state) => state.reviews);

  const [openModal, setOpenModal] = useState(false);
  const [writeReviewTab, setWriteReviewTab] = useState(false);

  let displayedReviews = showAll ? reviews : reviews?.slice(0, 3);
  // console.log(displayedReviews[0]);
  const [scaleResponsive, setSacleResponsive] = useState("");

  useEffect(() => {
    if (!window) return;
    if (showMore) return;

    // console.log("dpr", window.devicePixelRatio);
    let dpi = window.devicePixelRatio;

    if (dpi >= 1.5) {
      setSacleResponsive("h-[12rem] sm:h-[24rem] md:pl-4 overflow-y-scroll");
    } else if (dpi >= 1.25 && dpi < 1.5) {
      setSacleResponsive("h-[22rem] sm:h-[32rem] md:pl-4 overflow-y-scroll");
    } else {
      setSacleResponsive("h-[28rem] sm:h-[36rem] md:pl-4 overflow-y-scroll");
    }
  }, [window, showMore]);

  const targetRef = useRef<HTMLDivElement>(null);

  return (
    <div className="h-full">
      <ErrorBoundary fallback={<></>}>
        <ReviewFetcher listingsId={listingsId} />
      </ErrorBoundary>

      {showMore && (
        <>
          <div className="flex flex-col md:flex-row lg:flex-row justify-between ">
            <h3 className="text-xl font-bold">
              What people have to say about this listing
            </h3>
            <div>
              <button
                className="px-6 py-2 mt-4 md:mt-0 lg:mt-0 rounded-full border border-btn-primary text-btn-primary font-semibold hover:underline"
                onClick={() => {
                  setOpenModal(true);
                  setWriteReviewTab(true);
                }}
                type="button"
              >
                Write a review
              </button>{" "}
            </div>
          </div>
          <br />
        </>
      )}

      {reviews?.length > 0 ? (
        <div className="h-full grid grid-cols-1 md:grid-cols-4">
          <div className="col-span-1">
            <ListingRatings reviews={reviews} />
          </div>
          <div className="col-span-3 overflow-scroll scrollbar-hide">
            <Suspense
              fallback={
                <div className="text-center justify-center mt-20">
                  <Spinner aria-label="loader" size="xl" />
                </div>
              }
            >
              {/* <div className={twMerge(scaleResponsive)}> */}
              <div className="">
                {displayedReviews.map((review) => (
                  <div key={review.id}>
                    <ReviewCard {...review} />
                  </div>
                ))}
              </div>
              <br />
              {showMore && (
                <button
                  className="px-6 py-2 rounded-full border border-btn-primary text-btn-primary font-semibold hover:underline"
                  onClick={() => {
                    setOpenModal(true);
                    setWriteReviewTab(false);
                  }}
                  type="button"
                >
                  Show all reviews
                </button>
              )}
            </Suspense>
          </div>
        </div>
      ) : (
        <div className="text-center">
          <h3 className="text-xl justify-items-center font-bold">
            No one has added any reviews in this listing yet.
          </h3>
        </div>
      )}

      <Modal onClose={() => setOpenModal(false)} open={openModal}>
        <ReviewsTabs
          activeWriteAReview={writeReviewTab}
          listingsId={listingsId}
        />
      </Modal>
    </div>
  );
}
