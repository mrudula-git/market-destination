import { useState, useEffect } from "react";
import { FaStar, FaRegStar } from "react-icons/fa";
import { twMerge } from "tailwind-merge";

export default function StarRating({ totalStars, value, onChange, size }) {
  const [rating, setRating] = useState(0);

  useEffect(() => {
    setRating(value);
  }, [value]);

  const handleStarClick = (starIndex) => {
    const newRating = starIndex + 1;
    setRating(newRating);
    onChange && onChange(newRating);
  };

  return (
    <>
      {[...Array(totalStars)].map((_, index) => (
        <span
          key={index}
          className={twMerge(
            size,
            "cursor-pointer",
            index < rating ? "text-primary1" : "text-primary1"
          )}
          onClick={() => handleStarClick(index)}
        >
          {index < rating ? <FaStar /> : <FaRegStar />}
        </span>
      ))}
    </>
  );
}
