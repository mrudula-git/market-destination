import React, { SyntheticEvent } from "react";

function OTPInput({ value, onChange }) {
  const handleDigitChange = (e: SyntheticEvent) => {
    onChange(e);
  };

  return (
    <input
      id="otp-input"
      type="text"
      name="otp"
      placeholder="Enter your verification code"
      maxLength={6}
      value={value || ""}
      onChange={(e) => handleDigitChange(e)}
      className="block w-full px-4 rounded-full border border-primary1 focus:border-primary1 bg-transparent focus:outline-none focus:ring-0"
      aria-label="OTP Digit"
    />
  );
}

export default OTPInput;
