import React, { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import apiKit from "../../../utils/api/helper";
import { apis } from "../../../constants/apis";
import ReviewFormRating, { uploadMedia } from "./reviewForms/writeReview";
import ReviewerForm from "./reviewForms/addReviewer";
import ReviewSubmission from "./reviewForms/reviewSubmission";
import { formErrors, validateField } from "./validationUtils";

type WriteAReviewProps = {
  listingsId: string;
};

export default function WriteAReview({ listingsId }: WriteAReviewProps) {
  const { handleSubmit } = useForm();

  const [formData, setFormData] = useState({
    title: "",
    ratingValue: 0,
    content: "",
    name: "",
    email: "",
    cleanlinessRating: 0,
    comfortRating: 0,
    valueRating: 0,
    servicesRating: 0,
    photos: [],
    reviewersId: "",
    otp: "",
  });

  const [reviewers, setReviewers] = useState("");

  const [uploadedImages, setUploadedImages] = useState([]);
  const [storedImages, setStoredImages] = useState([]);
  const [isSubmit, setIsSubmit] = useState(false);

  const [activeStep, setActiveStep] = useState(1);
  const [isVerify, setISVerify] = useState(false);

  const [validationErrors, setValidationErrors] = useState({
    title: "",
    ratingValue: "",
    content: "",
    name: "",
    email: "",
  });

  const handleNextStep = () => {
    setActiveStep((prevStep) => prevStep + 1);
  };

  const handlePrevStep = () => {
    setActiveStep((prevStep) => prevStep - 1);
    const _formData = {
      ...formData,
    };
    setFormData(_formData);
    handleValidation(formData);
  };

  // useEffect(() => {
  //   localStorage.setItem("reviewFormData", JSON.stringify(formData));
  // }, [formData]);

  const handleUpload = (uploadedResults: React.SetStateAction<never[]>) => {
    // console.log("Uploaded images:", uploadedResults);
    setUploadedImages(uploadedResults);
  };

  const handleValidationError = (
    errors: React.SetStateAction<{
      title: string;
      ratingValue: string;
      content: string;
      name: string;
      email: string;
    }>
  ) => {
    setValidationErrors(errors);
  };

  const handleIsVerifyChange = (
    value: boolean | ((prevState: boolean) => boolean)
  ) => {
    setISVerify(value);
  };

  const handleReviewersChange = (value: React.SetStateAction<string>) => {
    setReviewers(value);
  };

  const onSubmit = async (data: {
    title: string;
    ratingValue: number;
    content: string;
    photos: never[];
    reviewersId: string;
    name: string;
    email: string;
    servicesRating: number;
    comfortRating: number;
    valueRating: number;
    cleanlinessRating: number;
    otp: string;
  }) => {
    try {
      setIsSubmit(true);
      // console.log("form submit");
      setFormData((prevData) => ({
        ...prevData,
        ...data,
      }));
      if (activeStep < 2) {
        // console.log("form submit1");
        handleNextStep();
      } else {
        // console.log("form submit2");
        formData.reviewersId = reviewers;
        const _formData = structuredClone(formData);
        _formData.reviewersId = reviewers;
        // console.log("isVerify", isVerify);
        let _uploaded = [];
        if (isVerify) {
          setIsSubmit(true);
          // console.log(1, uploadedImages);
          const uploads = [];
          for (const file of uploadedImages) {
            try {
              uploads.push(uploadMedia(file));
            } catch (error) {
              // console.error("Error uploading image:", error);
            }
          }
          _uploaded = await Promise.all(uploads);
          // console.log(2, _uploaded);
          setStoredImages(_uploaded);

          // console.log(3);

          const payload = {
            listingsId: listingsId,
            title: _formData.title,
            ratingValue: _formData.ratingValue,
            content: _formData.content,
            reviewersId: _formData.reviewersId,
            details: {
              servicesRating: _formData.servicesRating,
              comfortRating: _formData.comfortRating,
              valueRating: _formData.valueRating,
              cleanlinessRating: _formData.cleanlinessRating,
            },
            photos: _uploaded.map(({ id }) => ({ id })),
          };
          const { review } = await apiKit({
            method: "POST",
            api: apis.reviews,
            body: payload,
          });
          // console.log("reponse review---", review?.id);

          if (review?.id) {
            // Successful API call, handle response

            // console.log("API response:", review);
            // Reset form data and state
            setFormData({
              title: "",
              ratingValue: 0,
              content: "",
              photos: [],
              reviewersId: "",
              name: "",
              email: "",
              cleanlinessRating: 0,
              comfortRating: 0,
              valueRating: 0,
              servicesRating: 0,
              otp: "",
            });
            // Reset active step or redirect to another page if needed
            setActiveStep(3);
            // Clear stored form data in localStorage
            localStorage.removeItem("reviewFormData");
          } else {
            // console.error("API error:", review);
            setIsSubmit(false);
          }
        }
      }
    } catch (error) {
      // console.error(error);
    }
  };

  const handleValidation = (_formData: any = null) => {
    // console.log({ formData });

    const fd = _formData || structuredClone(formData);
    // console.log({ fd });
    const errors = {
      ratingValue: "",
      title: "",
      content: "",
      name: "",
      email: "",
    };

    if (activeStep === 1) {
      errors.title = validateField("title", fd.title, {
        required: true,
        minLength: 3,
        maxLength: 50,
      });
      if (!fd.ratingValue) {
        errors.ratingValue = formErrors.ratingError.minimum;
      }
      errors.content = validateField("content", fd.content, {
        required: true,
        minLength: 20,
        maxLength: 1200,
      });
    } else if (activeStep === 2) {
      errors.name = validateField("name", fd.name, {
        required: true,
        minLength: 3,
        maxLength: 50,
      });
      errors.email = validateField("email", fd.email, {
        required: true,
      });
    } else {
    }
    setValidationErrors({ ...errors });
    return errors;
  };

  const handleContinue = () => {
    const errors = handleValidation();
    if (Object.values(errors).some((error) => error !== "")) {
      const errorFieldElement = document.querySelector("error-message");
      if (errorFieldElement) {
        errorFieldElement.scrollIntoView({
          behavior: "smooth",
          block: "center",
        });
      }
    } else {
      handleNextStep();
    }
  };

  // const handleContinue = () => {
  //   const errors = handleValidation();
  //   // console.log("handleContinue", { errors });
  //   setValidationErrors({ ...errors });

  //   // Check if there are any errors
  //   if (!errors.title && !errors.ratingValue && !errors.content) {
  //     handleNextStep();
  //   }
  // };

  const handleChange = (e) => {
    try {
      const { name, value } = e.target;

      setValidationErrors((prevErrors) => ({
        ...prevErrors,
        [name]: "",
      }));

      const _formData = {
        ...formData,
        [name]: value,
      };
      setFormData(_formData);

      const fieldErrors = validateField(name, value, {
        required: true,
        minLength: name === "content" ? 20 : 3,
        maxLength: name === "content" ? 1200 : 50,
      });

      setValidationErrors((prevErrors) => ({
        ...prevErrors,
        [name]: fieldErrors,
      }));
    } catch (error) {
      // console.log(error);
    }
  };

  const handleRatingChange = (ratingType: string, value: any) => {
    try {
      console.log(ratingType);
      let _formData = structuredClone(formData);
      if (ratingType === "ratingValue") {
        _formData["ratingValue"] = value;
        _formData["cleanlinessRating"] = value;
        _formData["comfortRating"] = value;
        _formData["valueRating"] = value;
        _formData["servicesRating"] = value;
      } else {
        _formData[ratingType] = value;
      }

      setFormData(_formData);
      const errors = {
        ...validationErrors,
        [ratingType]: validateField(ratingType, value, {
          required: true,
          minLength: 0,
          maxLength: 0,
        }),
      };
      setValidationErrors(errors);
      // handleValidation(_formData);
      // console.log("validation sate", validationErrors);
    } catch (error) {
      // console.log;
    }
  };

  return (
    <div className="container mx-auto h-[40rem] sm:h-[36rem] overflow-scroll">
      {/* <pre>{JSON.stringify(formData, null, 2)}</pre> */}
      <form className="text-left" onSubmit={handleSubmit(onSubmit)}>
        {activeStep === 1 && (
          <ReviewFormRating
            formData={formData}
            uploadedImages={uploadedImages}
            handleChange={handleChange}
            handleRatingChange={handleRatingChange}
            handleUpload={handleUpload}
            // handleNextStep={handleNextStep}
            validationErrors={validationErrors}
            handleContinue={handleContinue}
          />
        )}

        {activeStep === 2 && (
          <ReviewerForm
            formData={formData}
            handleChange={handleChange}
            onReviewersChange={handleReviewersChange}
            onIsVerifyChange={handleIsVerifyChange}
            handlePrevStep={handlePrevStep}
            handleSubmit={handleSubmit}
            validationErrors={validationErrors}
            onValidationError={handleValidationError}
            isSubmit={isSubmit}
          />
        )}
        {activeStep === 3 && <ReviewSubmission />}
      </form>

      <br />
      <br />
    </div>
  );
}
