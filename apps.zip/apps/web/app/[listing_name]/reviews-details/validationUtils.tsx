export const formErrors = {
  title: {
    required: "Title is required",
    minimum: "Title must contain 3 characters",
    maximum: "Title should not exceed 50 characters",
  },
  ratingError: {
    required: "Rating is required",
    minimum: "Rating should have at least one star",
    maximum: "Rating can have most 5 stars",
  },
  
  content: {
    required: "Description is required",
    minimum: "Description must contain 20 characters",
    maximum: "Description should not exceed 1200 characters",
  },

  name: {
    required: "Name is required",
    minimum: "Name should have at least 3 characters",
    maximum: "Name should not exceed 50 characters",
  },
  email: {
    required: "Email is required",
  },
};

export function validateField(
  name: string,
  value: any,
  rules: { required: boolean; minLength?: number; maxLength?: number }
) {
  if (rules.required) {
    if (!value.toString().trim()) {
      return formErrors[name].required;
    }
  }

  if (rules.minLength) {
    if (value.length < rules.minLength) {
      return formErrors[name].minimum;
    }
  }

  if (rules.maxLength) {
    if (value.length > rules.maxLength) {
      return formErrors[name].maximum;
    }
  }

  if (name === "name") {
    if (!/^[a-zA-Z]+(?: [a-zA-Z]+)*$/.test(value)) {
      return "Name should contain alphabetic characters only with spaces between words";
    }
  }

  if (name === "email") {
    const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    if (!emailRegex.test(value)) {
      return "Email is not valid";
    }
  }

  return "";
}
