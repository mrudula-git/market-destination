import React, { useEffect, useState } from "react";
import StarRating from "../star-rating";
import ImageUpload, { imagekit } from "../../../../components/image-upload";
import apiKit from "../../../../utils/api/helper";

export async function uploadMedia(file) {
  try {
    const imageKitResult = await imagekit.upload({
      file: file,
      fileName: file.name,
      folder: `/marketplace/reviews`,
    });

    const { media } = await apiKit({
      api: "/media",
      method: "POST",
      body: {
        url: imageKitResult.url,
        thumbUrl: imageKitResult.thumbnailUrl,
      },
    });

    return media;
  } catch (error) {
    // console.log(error, "error uploadMedia");
  }
}

function ReviewFormRating({
  formData,
  uploadedImages,
  handleChange,
  handleRatingChange,
  handleUpload,
  validationErrors,
  handleContinue,
}) {
  const [rating, setRating] = useState(formData?.ratingValue ?? 0);
  const [cleanliness, setCleanliness] = useState(
    formData?.cleanlinessRating ?? 0
  );
  const [comfort, setComfort] = useState(formData?.comfortRating ?? 0);
  const [value, setValue] = useState(formData?.valueRating ?? 0);
  const [service, setService] = useState(formData?.servicesRating ?? 0);

  useEffect(() => {
    setRating(formData?.ratingValue ?? 0);
    setCleanliness(formData?.cleanlinessRating ?? 0);
    setComfort(formData?.comfortRating ?? 0);
    setValue(formData?.valueRating ?? 0);
    setService(formData?.servicesRating ?? 0);
  }, [
    formData?.ratingValue,
    formData?.cleanlinessRating,
    formData?.comfortRating,
    formData?.valueRating,
    formData?.servicesRating,
  ]);

  return (
    <div className="text-primary1 max-w-sm mx-auto">
      <div>
        <label className="block font-semibold mb-2" htmlFor="ratingValue">
          How would you rate your experience?
        </label>
        <div className="flex w-full justify-center items-center gap-2">
          <StarRating
            size={"text-4xl"}
            onChange={(value) => {
              handleRatingChange("ratingValue", value);
            }}
            totalStars={5}
            value={rating}
          />
        </div>
        {validationErrors.ratingValue && (
          <p className="text-red-500 error-message">{validationErrors.ratingValue}</p>
        )}
      </div>
      <br />
      <div>
        <label className="block font-semibold" htmlFor="title">
          Title your review
        </label>
        <input
          className="block w-full px-4 rounded-full border border-primary1 focus:border-primary1 bg-transparent focus:outline-none focus:ring-0"
          id="title"
          name="title"
          placeholder="Give us the gist of your experience"
          onChange={handleChange}
          value={formData.title}
        />
        {validationErrors.title && (
          <p className="text-red-500 error-message">{validationErrors.title}</p>
        )}
      </div>

      <br />
      <div>
        <label className="block font-semibold" htmlFor="content">
          Describe your review
        </label>
        <textarea
          className="block w-full p-4 rounded-lg border border-primary1 focus:border-primary1 bg-transparent focus:outline-none focus:ring-0"
          id="content"
          name="content"
          placeholder="Describe your review"
          onChange={handleChange}
          value={formData.content}
        />
        {validationErrors.content && (
          <p className="text-red-500 error-message">{validationErrors.content}</p>
        )}
      </div>

      <br />
      <p className="block font-medium mb-4">What was your experience like?</p>

      <div className="grid grid-cols-3 items-center mb-2">
        <label className="block col-span-1 font-semibold">Cleanliness</label>
        <div className="col-span-2 justify-self-end flex gap-2">
          <StarRating
            size={"text-2xl"}
            onChange={(value) => {
              handleRatingChange("cleanlinessRating", value);
            }}
            value={cleanliness}
            totalStars={5}
          />
        </div>
      </div>

      <div className="grid grid-cols-3 items-center mb-2">
        <label className="block col-span-1 font-semibold">Comfort</label>
        <div className="col-span-2 justify-self-end flex gap-2">
          <StarRating
            size={"text-2xl"}
            onChange={(value) => {
              handleRatingChange("comfortRating", value);
            }}
            value={comfort}
            totalStars={5}
          />
        </div>
      </div>

      <div className="grid grid-cols-3 items-center mb-2">
        <label className="block col-span-1 font-semibold">Value</label>
        <div className="col-span-2 justify-self-end flex gap-2">
          <StarRating
            size={"text-2xl"}
            onChange={(value) => {
              handleRatingChange("valueRating", value);
            }}
            value={value}
            totalStars={5}
          />
        </div>
      </div>

      <div className="grid grid-cols-3 items-center mb-2">
        <label className="block col-span-1 font-semibold">Services</label>
        <div className="col-span-2 justify-self-end flex gap-2">
          <StarRating
            size={"text-2xl"}
            onChange={(value) => {
              handleRatingChange("servicesRating", value);
            }}
            value={service}
            totalStars={5}
          />
        </div>
      </div>

      <br />
      <div>
        <label className="block text-lg font-semibold" htmlFor="file">
          Add some photos
        </label>
        <ImageUpload onUpload={handleUpload} uploadedImages={uploadedImages} />
      </div>

      <br />
      <button
        className="bg-primary1 text-base0 font-medium py-2 px-4 rounded-full"
        type="button"
        onClick={handleContinue}
      >
        Continue
      </button>
    </div>
  );
}

export default ReviewFormRating;
