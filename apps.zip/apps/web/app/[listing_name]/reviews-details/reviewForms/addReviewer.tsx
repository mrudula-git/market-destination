import React, { useEffect, useRef, useState } from "react";
import { SiAmazonsimpleemailservice } from "react-icons/si";
import OTPInput from ".././custom-otp-input";
import apiKit from "../../../../utils/api/helper";
import { apis } from "../../../../constants/apis";
import { IoArrowBackCircleOutline } from "react-icons/io5";
import { validateField } from "../validationUtils";

function ReviewerForm({
  formData,
  handleChange,
  onReviewersChange,
  onIsVerifyChange,
  handlePrevStep,
  handleSubmit,
  validationErrors,
  onValidationError,
  isSubmit,
}) {
  const [isSendingOtp, setIsSendingOtp] = useState(false);
  const [isContinue, setIsContinue] = useState(false);
  const [isVerifyingOtp, setIsVerifyingOtp] = useState(false);
  const [otpSent, setOtpSent] = useState(false);
  const [isVerify, setISVerify] = useState(false);
  const [isExistingReviewer, setIsExistingReviewer] = useState(false);
  const [otpResent, setOtpResent] = useState(false);
  const [otpVerificationMessage, setOtpVerificationMessage] = useState("");
  const submitButtonRef = useRef(null);

  useEffect(() => {
    if (isVerify) {
      // If verification is successful, click the submit button
      if (submitButtonRef.current) {
        submitButtonRef.current.click();
      }
    }
  }, [isVerify]);

  const handleGetOtp = async () => {
    try {
      const email = formData.email;
      const query = { email };
      const errors = {
        name: validateField("name", formData.name, {
          required: true,
          minLength: 3,
          maxLength: 50,
        }),
        email: validateField("email", formData.email, {
          required: true,
        }),
      };

      //   console.log("responseexist", reviewer);
      if (errors.name || errors.email) {
        // There are validation errors, don't proceed
        onValidationError(errors);
        return;
      } else {
        setIsContinue(true);
        const { reviewer } = await apiKit({
          api: apis.reviewer,
          method: "GET",
          queryParams: query,
        });

        if (reviewer?.verified) {
          // Reviewer found and verified
          // console.log("Hi 1");
          setIsExistingReviewer(true);
          setISVerify(true);
          onReviewersChange(reviewer.id);
          onIsVerifyChange(true);
        } else {
          try {
            // Call the API to send OTP
            setIsContinue(true);
            // console.log("Hi 2");
            setIsSendingOtp(true);
            const response = await apiKit({
              method: "POST",
              api: apis.reviewer,
              body: {
                email: formData.email,
                name: formData.name,
                //   otp: formData.otp,
              },
            });

            // console.log("reponse otp---", response);

            if (response.message === "Reviewer created/updated successfully.") {
              // Show the OTP verification section
              const reviewerId = response.reviewer?.id || null;
              setOtpSent(true);
              onReviewersChange(reviewerId);
              onIsVerifyChange(true);
              // console.log("otpsent", otpSent);
            } else {
              // console.error("Failed to send OTP:", response.message);
              setOtpSent(false);
              setIsContinue(false);
              setIsSendingOtp(false);
            }
          } catch (error) {
            // console.error("Error sending OTP:", error);
            setIsSendingOtp(false);
            setIsContinue(false);
          } finally {
            setIsContinue(false);
            setIsSendingOtp(false);
          }
        }
      }
    } catch (error) {
      // console.error("Error fetching reviewer details:", error);
    }
  };

  const handleOtpVerification = async () => {
    try {
      setIsVerifyingOtp(true);
      const response = await apiKit({
        method: "POST",
        api: apis.verify,
        body: {
          name: formData.name,
          email: formData.email,
          // id:formData.reviewerId,
          otp: formData.otp,
        },
      });
      if (response.message == "OTP verification successful.") {
        setISVerify(true);
        setOtpVerificationMessage("OTP is Verified ");
      } else {
        setOtpVerificationMessage("OTP did not match.");        
        // console.error("Failed to verify OTP.");
        setISVerify(false);
        setIsVerifyingOtp(false);
      }
    } catch (error) {
      // console.error("Error verifying OTP:", error);
      setISVerify(false);
      setIsVerifyingOtp(false);
      setOtpVerificationMessage("Error verifying OTP"); 
    }
    finally{
        setTimeout(() => {
          setOtpVerificationMessage("");
        }, 3000);
    }
  };

  const handleResendOtp = async () => {
    try {
      await handleGetOtp();
      setOtpResent(true);
      setTimeout(() => {
        setOtpResent(false);
      }, 3000);
    } catch (error) {
      // console.error("Error resending OTP:", error);
    }
  };
  return (
    <div className="text-primary1 max-w-sm mx-auto">
      <div className="flex items-center gap-2">
        <IoArrowBackCircleOutline
          className="text-3xl"
          type="button"
          onClick={handlePrevStep}
        />
        <h4 className="text-lg font-semibold">Update ratings</h4>
      </div>
      <p>Got a second? Just a few more details...</p>
      <br />
      {!otpSent || isVerify ? (
      <>
      <div className="">
          <label className="block font-semibold" htmlFor="name">
            Name
          </label>
          <input
            className="block w-full px-4 rounded-full border border-primary1 focus:border-primary1 bg-transparent focus:outline-none focus:ring-0 disabled:opacity-50 disabled:cursor-not-allowed"
            id="name"
            name="name"
            placeholder="Enter your name"
            onChange={handleChange}
            disabled={isVerify}
            type="text"
            value={formData.name} />
          {validationErrors.name && (
            <p className="text-red-500 error-message">{validationErrors.name}</p>
          )}
        </div>
        <br />
        <div>
            <label className="block font-semibold" htmlFor="email">
              Email
            </label>
            <input
              className="block w-full px-4 rounded-full border border-primary1 focus:border-primary1 bg-transparent focus:outline-none focus:ring-0 disabled:opacity-50 disabled:cursor-not-allowed"
              id="email"
              name="email"
              placeholder="Enter your email"
              onChange={handleChange}
              disabled={isVerify}
              type="email"
              value={formData.email} />
            {validationErrors.email && (
              <p className="text-red-500 error-message">{validationErrors.email}</p>
            )}
          </div>
      </>
      ): null }
      {otpSent && !isExistingReviewer && !isVerify ? (
        <div>
          <p className="flex items-center gap-2 text-primary1 font-bold ">
            <SiAmazonsimpleemailservice className="text-3xl" />
            <span className="ml-2 text-lg">Verification</span>
          </p>
          <p className="text-sm">We have sent you a email containing an OTP.</p>

          <br />
          <div>
            <label className="block font-semibold" htmlFor="otp">
              Enter verification code
            </label>
            <OTPInput onChange={handleChange} value={formData.otp} />
            <div className="text-sm">
            {otpVerificationMessage && <p className={`${
                isVerifyingOtp || isVerify
                  ? "text-primary1"
                  : "text-red-400 error-message"
              }`}>{otpVerificationMessage}</p>}
            </div>
          </div>
          <div className="flex items-center gap-2">
            <div className="text-sm">
              Haven't received the verification code?{" "}
            </div>
            <a
              className="font-bold cursor-pointer underline"
              onClick={handleResendOtp}
            >
              Resend
            </a>
          </div>
          {otpResent && (
            <p className="text-primary1">OTP resent successfully.</p>
          )}
          <br />
          <div>
            <button
              className={`bg-primary1 text-base0 font-semibold py-2 px-4 rounded-full ${
                isVerifyingOtp || isVerify
                  ? "disabled:opacity-50 disabled:cursor-not-allowed bg-slate-400"
                  : ""
              }`}
              disabled={isVerifyingOtp || isVerify || isSubmit}
              onClick={handleOtpVerification}
              type="button"
            >
              Verify
            </button>
          </div>
        </div>
      ) : null}

      <br />
      <div className="flex flex-col sm:flex-row">
        {!otpSent && !isVerify ? (
          <button
            className={`bg-primary1 text-base0 font-semibold py-2 px-4 rounded-full ${
              isContinue || isSendingOtp || otpSent
                ? "disabled:opacity-50 disabled:cursor-not-allowed bg-slate-400"
                : ""
            }`}
            disabled={isSendingOtp || otpSent || isContinue}
            onClick={handleGetOtp}
            hidden={isVerify}
            type="button"
          >
            {isSendingOtp ? "Sending OTP..." : "Continue"}
          </button>
        ) : (
          <button
          ref={submitButtonRef}
            className={`bg-primary1 text-base0 font-semibold py-2 px-4 rounded-full ${
              isSubmit || !isVerify
                ? "disabled:opacity-50 disabled:cursor-not-allowed bg-slate-400"
                : ""
            }`}
            disabled={!isVerify || isSubmit}
            hidden={!isVerify}
            type="submit"
            onClick={handleSubmit}
          >
            Submit
          </button>
        )}
      </div>
    </div>
  );
}

export default ReviewerForm;
