import { Icon } from "@iconify/react";

export default function ReviewSubmission() {
  return (
    <div className="text-theme-text-light">
      <div className="bg-primary2 p-4 sm:p-8 rounded-tl-3xl rounded-br-3xl text-center shadow shadow-primary2 transition-shadow">
        <div>
          <div className="justify-items-center grid grid-cols-12">
            <div className="col-span-3"></div>
            <div className="col-span-6">
              <Icon
                className="text-5xl rounded-full text-white"
                icon="ic:round-done-all"
              />
            </div>
            <div className="col-span-3"></div>
          </div>
          <div>
            <br />
            <h2 className="text-xl font-bold">Thank You for Your Review!</h2>
            <br />
            <p className="text-sm sm:text-base font-medium">
              We appreciate you taking the time to provide your feedback. We are
              delighted that you are on this journey with us. Your feedback will
              soon be reflected on the listing.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
