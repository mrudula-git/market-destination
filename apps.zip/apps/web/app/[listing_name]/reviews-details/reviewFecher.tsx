"use client";

import { useEffect } from "react";
import apiKit from "../../../utils/api/helper";
import { apis } from "../../../constants/apis";
import { useReviewsStore } from "../../../stores/zustand/review.store";

export function ReviewFetcher({ listingsId }: { listingsId: string }) {
  const { setReviews } = useReviewsStore();

  useEffect(() => {
    async function fetchReviews() {
      try {
        const data = await apiKit({
          api: apis.review(listingsId),
        });
        console.log("hiifetchReviews", data);
        setReviews(data.reviews || []);
      } catch (error) {
        console.error("Error fetching reviews:", error);
      }
    }
    if (listingsId) {
      fetchReviews();
    }
  }, [listingsId, setReviews]);

  return null;
}
