import { FaStar, FaRegStar, FaStarHalf, FaStarHalfAlt } from "react-icons/fa";

export default function Rating({ value }) {
  const filledStars = Array.from({ length: Math.floor(value) }, (_, index) => (
    <FaStar key={index} className="text-primary1" />
  ));

  const hasHalfStar = value % 1 !== 0;

  const emptyStars = Array.from(
    { length: hasHalfStar ? 4 - Math.floor(value) : 5 - Math.ceil(value) },
    (_, index) => (
      <FaRegStar
        key={index + (hasHalfStar ? Math.ceil(value) : Math.floor(value))}
        className="text-primary1"
      />
    )
  );

  const halfStar = hasHalfStar ? (
    <FaStarHalfAlt className="text-primary1" />
  ) : null;

  return (
    <div className="flex items-center">
      {filledStars}
      {halfStar}
      {emptyStars}
    </div>
  );
}
