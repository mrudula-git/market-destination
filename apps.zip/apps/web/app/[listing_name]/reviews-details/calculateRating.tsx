import type { ReviewDetails, Reviewers, Reviews } from "database";

type Review = Partial<Reviews> & {
  details: ReviewDetails;
  reviewer: Reviewers;
};

type Rating = {
  name: string;
  icon?: string;
  value: string;
};

export const calculateRatings = async (reviews: Review[]): Promise<any[]> => {
  if (!Array.isArray(reviews)) {
    console.error("Reviews is not an array:", reviews);
    return [];
  }

  let sumRatingValue = 0,
    numRatingValue = 0;
  let sumCleanlinessRating = 0,
    numCleanlinessRating = 0;
  let sumComfortRating = 0,
    numComfortRating = 0;
  let sumValueRating = 0,
    numValueRating = 0;
  let sumServicesRating = 0,
    numServicesRating = 0;

  reviews?.forEach((el) => {
    // console.log(
    //   el.details.cleanlinessRating,
    //   el.details.comfortRating,
    //   el.details.valueRating,
    //   el.details.servicesRating
    // );

    if (el.ratingValue) {
      sumRatingValue += el?.ratingValue ?? 0;
      numRatingValue += 1;
    }

    if (el.details.cleanlinessRating) {
      sumCleanlinessRating += el.details?.cleanlinessRating ?? 0;
      numCleanlinessRating += 1;
    }

    if (el.details.comfortRating) {
      sumComfortRating += el.details?.comfortRating ?? 0;
      numComfortRating += 1;
    }

    if (el.details.valueRating) {
      sumValueRating += el.details?.valueRating ?? 0;
      numValueRating += 1;
    }

    if (el.details.servicesRating) {
      sumServicesRating += el.details?.servicesRating ?? 0;
      numServicesRating += 1;
    }
  });

  return [
    {
      name: "Overall Rating",
      value: (sumRatingValue / numRatingValue).toFixed(1),
    },
    {
      name: "Cleanliness",
      icon: "/assets/icons/ratings/cleanliness.png",
      value: (sumCleanlinessRating / numCleanlinessRating).toFixed(1),
    },
    {
      name: "Comfort",
      icon: "/assets/icons/ratings/comfort.png",
      value: (sumComfortRating / numComfortRating).toFixed(1),
    },
    {
      name: "Value",
      icon: "/assets/icons/ratings/value.png",
      value: (sumValueRating / numValueRating).toFixed(1),
    },
    {
      name: "Services",
      icon: "/assets/icons/ratings/services.png",
      value: (sumServicesRating / numServicesRating).toFixed(1),
    },
  ];
};
