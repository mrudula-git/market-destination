import React from "react";
import packagesData from "./data.json";

function Packages() {
  const packages = packagesData.listing.packages || [];

  return (
    <>
      {/* Packages Card section */}
      <div className="grid grid-cols-1 md:grid-cols-1 gap-2 m-auto p-2">
        {packages.map((packageItem) => (
          <div key={packageItem.id} className="bg-white p-4 rounded-md shadow-md border mb-2">
            <h2 className="text-2xl font-semibold mb-2">{packageItem.name}</h2>

            <div className="mb-2">
              <h3 className="text-lg font-semibold">Package Info</h3>
              <p className="text-gray-600">{packageItem.description}</p>
            </div>

            <div className="mb-2">
              <h3 className="text-lg font-semibold">Price</h3>
              <p className="text-gray-600">{`$${packageItem.price.amount} ${packageItem.price.currency} per ${packageItem.duration}`}</p>
            </div>

            <div className="mb-4">
              <h3 className="text-lg font-semibold">Guest Details</h3>
              <p className="text-gray-600">{`Max guests: ${packageItem.persons}`}</p>
            </div>

            <button className="bg-fuchsia-700 text-white py-2 px-4 rounded-md">
              Book Now
            </button>
          </div>
        ))}
      </div>
    </>
  );
}

export default Packages;