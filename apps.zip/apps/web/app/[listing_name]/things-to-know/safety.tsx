"use client";

import { useMemo, useState } from "react";
import type { Attribute, AttributeGroup } from "../../../constants/types";
import AutoAttributeDetails from "../auto-attribute-details";
import Modal from "../../../components/UI/Modals/modal";

type SafetyProps = {
  attributes?: Attribute[];
  attributeGroups?: AttributeGroup[];
};

export default function Safety({ attributes, attributeGroups }: SafetyProps) {
  const [openModal, setOpenModal] = useState(false);

  const attributesSlice = useMemo(() => {
    // console.log(attributes);
    return attributes
      ?.filter((attr) => {
        // if (attr?.type === "boolean") return true;
        if (attr?.type === "boolean" && attr.value === true) return true;
        if (attr?.name?.toLowerCase().endsWith("time")) return true;
      })
      .slice(0, 5);
  }, []);

  return (
    <div>
      <h3 className="text-lg font-semibold">Safety & Property</h3>
      {/* <pre>{JSON.stringify(attributesSlice, null, 2)}</pre> */}
      <div>
        {attributesSlice?.map((attribute) => (
          <AutoAttributeDetails key={attribute.id} {...attribute} />
        ))}
      </div>

      <br />
      <button
        className="font-medium underline"
        onClick={() => {
          setOpenModal(true);
        }}
        type="button"
      >
        More
      </button>

      {/* <pre>{JSON.stringify(attributes, null, 2)}</pre> */}

      <Modal
        onClose={() => {
          setOpenModal(false);
        }}
        open={openModal}
      >
        <div className="h-full overflow-hidden">
          <div className="h-full overflow-scroll">
            <h3 className="text-2xl mb-4 font-bold">
              Safety & Properties info
            </h3>
            <br />
            {attributeGroups.map((group) => (
              <>
                {group.attributes?.length ? (
                  <div key={group.id}>
                    <h4 className="text-xl font-semibold">{group.name}</h4>

                    <br />

                    {group.attributes?.map((attribute) => (
                      <AutoAttributeDetails key={attribute.id} {...attribute} />
                    ))}

                    <hr className="mt-4 mb-6" />
                  </div>
                ) : null}
              </>
            ))}
          </div>
        </div>
      </Modal>
    </div>
  );
}
