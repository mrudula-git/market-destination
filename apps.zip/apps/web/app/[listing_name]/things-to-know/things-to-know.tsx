"use client";

import { useMemo } from "react";
import { Attribute, AttributeGroup, Category } from "../../../constants/types";
import Policies from "./policies";
import Rules from "./rules";
import Safety from "./safety";

type ThingsToKnowProps = {
  attributes?: Attribute[];
  categories?: Category[];
  attributeGroups?: AttributeGroup[];
};

export default function ThingsToKnow({
  attributes,
  categories,
  attributeGroups,
}: ThingsToKnowProps) {
  // console.log({ attributes, categories, attributeGroups });

  const populatedAttributeGroups = useMemo(() => {
    const _attributeGroups = structuredClone(attributeGroups);
    const _attributeIds = attributes?.map(({ id }) => id);
    _attributeGroups.forEach((group) => {
      const _attributes = [];
      group.attributesId?.forEach((id) => {
        if (_attributeIds?.includes(id)) {
          _attributes.push(attributes.find((attr) => attr.id === id));
        }
      });
      group["attributes"] = _attributes;
    });
    return _attributeGroups;
  }, [attributeGroups, attributes]);

  const rulesKw = ["rules"];
  const safetyKw = ["safety"];
  const policiesKw = ["policies"];

  const rulesAttributeGroups = useMemo(() => {
    return populatedAttributeGroups?.filter((group) =>
      rulesKw.includes(group?.name?.toLowerCase())
    );
  }, [populatedAttributeGroups]);

  const safetyAttributeGroups = useMemo(() => {
    return populatedAttributeGroups?.filter(
      (group) =>
        safetyKw.includes(group?.name?.toLowerCase()) ||
        safetyKw.includes(group?.name?.toLowerCase().startsWith())
    );
  }, [populatedAttributeGroups]);

  const policiesAttributeGroups = useMemo(() => {
    return populatedAttributeGroups?.filter(
      (group) =>
        policiesKw.includes(group?.name?.toLowerCase()) ||
        policiesKw.includes(group?.name?.toLowerCase().startsWith())
    );
  }, [populatedAttributeGroups]);

  return (
    <div className="dm-thing-to-know">
      <h2 className="text-xl font-bold">Things to know</h2>
      <br />

      {/* <pre>{JSON.stringify(populatedAttributeGroups, null, 2)}</pre> */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Rules
          attributes={rulesAttributeGroups?.at(0)?.attributes}
          attributeGroups={rulesAttributeGroups}
        />
        <Safety
          attributes={safetyAttributeGroups?.at(0)?.attributes}
          attributeGroups={safetyAttributeGroups}
        />
        <Policies
          attributes={policiesAttributeGroups?.at(0)?.attributes}
          attributeGroups={policiesAttributeGroups}
        />
      </div>
    </div>
  );
}
