type AutoAttributeDetailsProps = {
  name: string;
  type: string;
  value: string | number | boolean;
  iconUrl?: string;
};

export default function AutoAttributeDetails({
  name,
  type,
  value,
  iconUrl,
}: AutoAttributeDetailsProps) {
  return (
    <div className="attribute-details pl-2 pr-4 my-3">
      {
        {
          string: <StringDetails name={name} value={value as string} />,
          // select: <StringDetails name={name} value={value as string} />,
          "long-string": (
            <StringDetails
              iconUrl={iconUrl}
              name={name}
              value={value as string}
              long={true}
            />
          ),
          number: (
            <NumberDetails
              iconUrl={iconUrl}
              name={name}
              value={value as number}
            />
          ),
          boolean: (
            <BooleanDetails
              iconUrl={iconUrl}
              name={name}
              value={value as boolean}
            />
          ),
          time: (
            <StringDetails
              iconUrl={iconUrl}
              name={name}
              value={value as string}
            />
          ),
        }[type]
      }
    </div>
  );
}

function NumberDetails({
  name,
  value,
  iconUrl,
}: {
  name: string;
  value: number;
  iconUrl?: string;
}) {
  return (
    <div className="grid grid-cols-3">
      <div className="col-span-2 place-self-start">
        <Label iconUrl={iconUrl} name={name} />
      </div>
      <div className="col-span-1 justify-self-end">
        <Value value={value} />
      </div>
    </div>
  );
}

function StringDetails({
  name,
  value,
  iconUrl,
  long,
}: {
  name: string;
  value: string;
  iconUrl?: string;
  long?: boolean;
}) {
  return (
    <div className="grid grid-cols-2">
      <div className="col-span-1 place-self-start">
        <Label iconUrl={iconUrl} name={name} />
      </div>
      <div className="col-span-1 justify-self-end">
        <Value long={long} value={value} />
      </div>
    </div>
  );
}

function BooleanDetails({
  name,
  value,
  iconUrl,
}: {
  name: string;
  value: boolean;
  iconUrl?: string;
}) {
  if (!value) return null;
  return (
    <div className="grid grid-cols-1">
      <div className="col-span-1 place-self-start">
        <Label iconUrl={iconUrl} name={name} />
      </div>
    </div>
  );
}

function Label({ iconUrl, name }: { iconUrl?: string; name: string }) {
  return (
    <div className="flex items-center gap-3">
      {iconUrl ? (
        <img className="w-8 h-8 dm-attr-icon mb1" src={iconUrl || ""} alt="" />
      ) : (
        <div className="w-8 h-8 dm-attr-icon-spaces">{iconUrl}</div>
      )}
      <p className="font-medium dm-attr-label">{name}</p>
    </div>
  );
}

function Value({ value, long = false }: { value: any; long?: boolean }) {
  return (
    <div>
      {long ? (
        <p className="text-sm text-justify">{value}</p>
      ) : (
        <p className="">{value}</p>
      )}
    </div>
  );
}
