"use client";
import { useEffect, useState } from "react";
import { Swiper, SwiperSlide } from "swiper/react";
import {
  Autoplay,
  EffectFade,
  FreeMode,
  Mousewheel,
  Navigation,
  Pagination,
  Thumbs,
} from "swiper/modules";
import type { Swiper as TSwiper } from "swiper/types";
import type { Media } from "database";

import "swiper/css";
import "swiper/css/navigation";
import "swiper/css/pagination";

const urls = [
  "https://images.pexels.com/photos/61129/pexels-photo-61129.jpeg?auto=compress&cs=tinysrgb&w=800",
  "https://images.pexels.com/photos/1782123/pexels-photo-1782123.jpeg?auto=compress&cs=tinysrgb&w=800",
  "https://images.unsplash.com/photo-1562859797-0aa1d9876507?w=800&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MjB8fHdhdGVyJTIwcGFya3xlbnwwfHwwfHx8MA%3D%3D",
  "https://images.unsplash.com/photo-1623718649591-311775a30c43?w=800&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTJ8fHdhdGVyJTIwcGFya3xlbnwwfHwwfHx8MA%3D%3D",
  "https://images.pexels.com/photos/261429/pexels-photo-261429.jpeg?auto=compress&cs=tinysrgb&w=800",
  "https://images.unsplash.com/photo-1546699718-5871c27b4197?w=800&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTh8fHdhdGVyJTIwcGFya3xlbnwwfHwwfHx8MA%3D%3D",
  "https://images.unsplash.com/photo-1626840365510-3201b731eb13?w=800&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTl8fHdhdGVyJTIwcGFya3xlbnwwfHwwfHx8MA%3D%3D",
  "https://images.pexels.com/photos/1291448/pexels-photo-1291448.jpeg?auto=compress&cs=tinysrgb&w=800",
  "https://images.unsplash.com/photo-1628238996362-a90f37d35b33?w=800&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8M3x8d2F0ZXIlMjBwYXJrfGVufDB8fDB8fHww",
  "https://images.unsplash.com/photo-1625254417927-3f586db72af5?w=800&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTV8fHdhdGVyJTIwcGFya3xlbnwwfHwwfHx8MA%3D%3D",
  "https://images.unsplash.com/photo-1532531565-a7682232341d?w=800&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTR8fHdhdGVyJTIwcGFya3xlbnwwfHwwfHx8MA%3D%3D",
  "https://images.unsplash.com/photo-1629834598512-77a443808b73?w=800&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8d2F0ZXIlMjBwYXJrfGVufDB8fDB8fHww",
];

type SwiperGalleryProps = {
  photos: Media[];
};

export default function SwiperGallery({
  photos,
}: SwiperGalleryProps): JSX.Element {
  const [photoUrls, setPhotoUrls] = useState<string[]>([]);
  const [selectedPhotoIndex, setSelectedPhotoIndex] = useState<number | null>(
    null
  );
  const [swiper, setSwiper] = useState<TSwiper>();
  const [thumbnails, setThumbnails] = useState<TSwiper | null>(null);

  useEffect(() => {
    if (!photos.length) return;
    const _photosUrl = photos.map((el) => el.url);
    setPhotoUrls(_photosUrl);
  }, [photos]);

  function handleThumbnailClick(index: number): void {
    setSelectedPhotoIndex(index);
    if (swiper) {
      swiper.slideTo(index);
    }
  }

  return (
    <div>
      {photoUrls.length > 0 ? (
        <div>
          <Swiper
            className="h-[12rem] sm:h-[24rem] xl:h-[32rem]"
            modules={[
              FreeMode,
              Pagination,
              Navigation,
              Mousewheel,
              EffectFade,
              Autoplay,
              Thumbs,
            ]}
            rewind
            navigation
            pagination
            autoplay={{
              delay: 2500,
              disableOnInteraction: false,
            }}
            thumbs={thumbnails ? { swiper: thumbnails } : undefined}
            onSlideChange={(_swiper) => {
              setSelectedPhotoIndex(_swiper.activeIndex);
            }}
            onSwiper={(_swiper) => {
              console.log("swiper", _swiper);
              setSwiper(_swiper);
            }}
          >
            {photoUrls.map((url, key) => (
              <SwiperSlide className="rounded-xl" key={key}>
                <div className="relative h-full rounded-2xl overflow-hidden">
                  <img
                    alt=""
                    className="absolute inset-0 w-full h-full"
                    src={url}
                  />
                  <div className="absolute inset-0 backdrop-blur-lg flex justify-center">
                    <img
                      alt=""
                      className="h-full object-center object-cover"
                      src={url}
                    />
                  </div>
                </div>
              </SwiperSlide>
            ))}
          </Swiper>

          <Swiper
            className="thumbnails my-1"
            modules={[FreeMode, Navigation, Thumbs]}
            freeMode
            loop
            onSwiper={(_swiper) => {
              console.log("thumbnails", _swiper);
              setThumbnails(_swiper);
            }}
            slidesPerView={12}
            spaceBetween={4}
            watchSlidesProgress
          >
            {photoUrls.map((url, index) => (
              <SwiperSlide key={index}>
                <img
                  alt=""
                  className={`w-full aspect-square cursor-pointer object-cover object-center ${
                    selectedPhotoIndex === index ? "opacity-100" : "opacity-60"
                  }`}
                  onClick={() => {
                    handleThumbnailClick(index);
                  }}
                  src={url}
                />
              </SwiperSlide>
            ))}
          </Swiper>
        </div>
      ) : null}
    </div>
  );
}
