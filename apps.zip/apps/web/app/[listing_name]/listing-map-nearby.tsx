"use client";

import { Locations } from "database";
import ListingMap from "../../components/GoogleMaps/listing-map";

type ListingNearbyMapProps = {
  location: Locations;
  // places: Locations[];
};

const MAP_KEY = process.env.NEXT_PUBLIC_GOOGLE_MAPS_KEY;

export default function ListingNearbyMap({
  location,
  // places,
}: ListingNearbyMapProps) {
  return (
    <div>
      <h3 className="text-xl font-bold">Where this place is & whats nearby</h3>
      {/* <pre>{JSON.stringify(places, null, 2)}</pre> */}
      <br />
      {location ? (
        <iframe
          width="100%"
          height="360px"
          style={{ border: "0" }}
          // src={`https://www.google.com/maps/embed/v1/place?key=${MAP_KEY}&&q=place_id:ChIJkX7Ig0ir5zsREhVRVzPfV1s`}
          src={`https://www.google.com/maps/embed/v1/place?key=${MAP_KEY}&&q=${encodeURIComponent(
            location?.name!
          )}`}
        ></iframe>
      ) : null
      // <div className="h-[360px]">
      //   <ListingMap center={{ lat: location?.lat!, lng: location?.lng! }} />
      //   <p className="text-sm">Tap the name for more</p>
      // </div>
      }

      {/* <button
        onClick={() => {
          const placeId = "ChIJkX7Ig0ir5zsREhVRVzPfV1s";
          window.open(
            `https://www.google.com/maps/place/?q=place_id:${placeId}`
          );
        }}
      >
        Get Direction
      </button> */}
    </div>
  );
}
