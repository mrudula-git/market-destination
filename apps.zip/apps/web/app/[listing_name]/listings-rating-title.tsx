"use client";
import { useMemo } from "react";
import { ErrorBoundary } from "react-error-boundary";
import { SolarStarsBoldDuotone } from "./icons/solar-stars-bold-duotone";
import { useReviewsStore } from "../../stores/zustand/review.store";

export default function ListingRatingsTitle() {
  const reviews = useReviewsStore((state) => state.reviews);

  const ratings = useMemo(() => {
    let sumRatingValue = 0,
      numRatingValue = 0;

    reviews?.forEach((el) => {
      if (el.ratingValue) {
        sumRatingValue += el.ratingValue;
        numRatingValue += 1;
      }
    });

    return [
      {
        name: "Overall Rating",
        value: (sumRatingValue / numRatingValue).toFixed(1),
      },
    ];
  }, [reviews]);

  return (
    <div>
      <div className="pt-2">
        <div className="flex justify-center md:justify-start items-center gap-2">
          <div>
            <ErrorBoundary fallback={<span>No reviews available</span>}>
              <SolarStarsBoldDuotone className="text-theme-red w-16 h-16" />
            </ErrorBoundary>
          </div>
          <div>
            {reviews ? (
              <>
                <p className="text-xs">{reviews[0]?.name}</p>
                <p className="text-2xl md:text-4xl font-extrabold">
                  {isNaN(ratings[0]?.value) ? null : ratings[0]?.value}
                </p>
              </>
            ) : (
              <p>No reviews available</p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
