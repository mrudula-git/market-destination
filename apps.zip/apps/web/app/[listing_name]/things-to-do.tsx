"use client";
import { Icon } from "@iconify/react/dist/iconify.js";
import React from "react";
import { humanize } from "underscore.string";

function ThingsToDo({ listing }: any) {
  let { thingsToDo, bestTimings, operationalTimings, languages, travelInstructions } = listing;
  
  function formatTime(timeString: string): string {
    const [hours, minutes] = timeString.split(':');
    const formattedTime = new Date(0, 0, 0, parseInt(hours), parseInt(minutes)).toLocaleTimeString('en-US', {
      hour: 'numeric',
      minute: 'numeric',
      hour12: true,
    });
    return formattedTime;
  }

  return (
    <div>
      {thingsToDo.length > 0 && (
        <div className="flex items-center pb-4">
          <Icon
            className="w-6 h-6 mb-1 mr-1"
            icon="material-symbols:things-to-do"
          />
          <div className="font-semibold text-xl">Things To Do</div>
        </div>
      )}
      <div className="md:grid grid-cols-1 gap-3 pb-1 ">
        {thingsToDo.map((item: string, index: number) => (
          <div key={index} className="md:flex md:items-center ">
            <span className="ml-2">{humanize(item)}</span>
          </div>
        ))}
      </div>

      {/* {bestTimings.length > 0 && (
        <div className="flex items-center pb-4">
          <Icon className="w-6 h-6 mt-4 mr-1" icon="carbon:time-filled" />
          <div className="font-semibold text-xl pt-4">Best Timings</div>
        </div>
      )}
      <div className="md:grid md:grid-cols-2 gap-3 pb-1 ">
        {bestTimings.map((item: string, index: number) => (
          <div key={index} className="flex items-center">
            <span className="ml-2">{humanize(item)}</span>
          </div>
        ))}
      </div> */}

      {bestTimings.length > 0 && (
        <div className="flex items-center pb-4">
          <Icon className="w-5 h-5 mt-4 mr-1" icon="bi:calendar-heart-fill" />
          <div className="font-semibold text-xl pt-4">Best Timings</div>
        </div>
      )}
      <div className="md:grid md:grid-cols-2 gap-3 pb-1 ">
        {bestTimings.map((timing: { start: string, end: string }, index: number) => (
          <div key={index} className="flex items-center">
            <span className="ml-2">{`${timing.start} - ${timing.end}`}</span>
          </div>
        ))}
      </div>

      {operationalTimings.length > 0 && (
        <div className="flex items-center pb-4">
          <Icon className="w-6 h-6 mt-4 mr-1" icon="carbon:time-filled" />
          <div className="font-semibold text-xl pt-4">Operational Timings</div>
        </div>
      )}
      <div className="md:grid md:grid-cols-2 gap-3 pb-1 ">
        {operationalTimings.map((timing: { name: string, start: string, end: string }, index: number) => (
          <div key={index} className="flex items-center">
            <span className="ml-2 capitalize">
              {timing.name === 'weekdays' || timing.name === 'weekends' ? (
                <span style={{ fontWeight: 'bold' }}>{humanize(timing.name)}</span>
              ) : (
                humanize(timing.name)
              )}
              : {formatTime(timing.start)} - {formatTime(timing.end)}
            </span>
          </div>
        ))}
      </div>

      {languages.length > 0 && (
        <div className="flex items-center pb-4 text-primary1">
          <Icon className="w-6 h-6 mt-4 mr-1" icon="clarity:language-solid" />
          {/* <img
            className="bg-base0  h-6 w-6 mt-4 mr-2"
            src="/asset/language.png"
            alt=""
          /> */}
          <div className="font-semibold text-xl pt-4">Languages</div>
        </div>
      )}
      <div className="md:grid md:grid-cols-2 gap-3 pb-1 ">
        {languages.map((item: string, index: number) => (
          <div key={index} className="flex items-center  ">
            <span className="ml-2">{humanize(item)}</span>
          </div>
        ))}
      </div>

      {travelInstructions.length > 0 && (
        <div className="flex items-center pb-4">
          <Icon className="w-6 h-6 mt-4 mr-1" icon="ic:baseline-directions" />
          {/* <img className="w-8 h-8 mt-4 " src="https://cdn-icons-png.flaticon.com/128/4571/4571137.png" alt="travel instruction"/> */}
          <div className="font-semibold text-xl pt-4">Travel Instructions</div>
        </div>
      )}
      <div className="md:grid md:grid-cols-1 gap-3 pb-1 ">
        {travelInstructions.map((item: string, index: number) => (
          <div key={index} className="md:flex md:items-center">
            <span className="ml-2">{humanize(item)}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

export default ThingsToDo;
