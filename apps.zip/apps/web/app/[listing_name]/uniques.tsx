"use client"
import { Icon } from "@iconify/react/dist/iconify.js";
import React from "react";
import { humanize } from "underscore.string";

function Uniques({ uniques }: any) {
  return (
    <div>
      {uniques.length > 0 && (
        <>
        <div className="flex items-center pb-4">
          <Icon
            className="w-6 h-6 mt-4 mr-1 mb-3"
            icon="pajamas:issue-type-feature"
          />
          <div className="font-semibold text-xl">Unique Features</div>
          </div>
          <div className="">
            {uniques.map((item: string) => (
              <div key={item}>
                <span className="text-primary1 md:grid md:grid-cols-2 gap-3 pb-1 font-semibold">
                  {humanize(item)}
                </span>
              </div>
            ))}
          </div>
        </>
      )}
    </div>
  );
}

export default Uniques;
