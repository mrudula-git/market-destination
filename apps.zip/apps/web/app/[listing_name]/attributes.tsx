"use client";

import { useMemo, useState } from "react";
// import { Accordion } from "flowbite-react";
import AttributesAccordions from "../../components/UI/Accordions/attributes-accordions";
import Modal from "../../components/UI/Modals/modal";
import type {
  Attribute,
  AttributeGroup,
  Category,
} from "../../constants/types";
import AutoAttributeDetails from "./auto-attribute-details";
import { Icon } from "@iconify/react/dist/iconify.js";

type AttributesProps = {
  // attributes: (Partial<ListingsAttributes> & { value: any })[];
  // categories: Partial<ListingsCategories>[];
  // attributeGroups: Partial<ListingsAttributesGroup>[];

  attributes?: Attribute[];
  categories?: Category[];
  attributeGroups?: AttributeGroup[];
};

export default function Attributes({
  attributes,
  categories,
  attributeGroups,
}: AttributesProps) {
  const [openModal, setOpenModal] = useState(false);

  const FacilitiesAG = attributeGroups.find(
    (ag) => ag.name?.toLowerCase() === "facilities"
  );

  const WaterParksAG = categories.find(
    (ag) => ag.name?.toLowerCase() === "water park"
  );

  const highlightedAttributes = useMemo(() => {
    return attributes
      .filter((attribute) => {
        if (attribute.iconUrl) return true;
        if (attribute.type === "boolean" && attribute.value === true)
          return true;
      })
      .slice(0, 10);
  }, [attributes]);

  return (
    <div>
      {/* <pre>{JSON.stringify({ categories, attributeGroups }, null, 2)}</pre> */}
      <div className="grid grid-cols-1 md:grid-cols-2">
        {highlightedAttributes.map((attribute) => (
          <div key={attribute.id} className="flex items-center">
            {/* {attribute.iconUrl ? (
              <img className="w-9 h-9" src={attribute.iconUrl || ""} alt="" />
            ) : (
              <div className="w-6 h-6"></div>
            )}
            {attribute.type === "boolean" && attribute.value === true ? (
              <p className="">{attribute.name}</p>
            ) : null}
            {attribute.type === "number" &&
            attribute.value &&
            attribute.value > 0 ? (
              <p className="">
                {attribute.name}: {attribute.value}
              </p>
            ) : null} */}

            <AutoAttributeDetails {...attribute} />
          </div>
        ))}

        {/* {Object.entries(amenitiesData).map(([category, items]) => (
          <div key={category}>
            {items.map((amenity) => (
              <div key={amenity.id} className="flex items-center gap-5">
                <div className="mr-2">
                  <img src={amenity.iconUrl} alt="icon" className="h-8" />
                </div>
                <div>{amenity.name}</div>
              </div>
            ))}
          </div>
        ))} */}
      </div>

      <br />
      <button
        className="w-full md:w-auto px-6 py-2 border border-btn-primary text-btn-primary rounded-full font-bold hover:underline"
        onClick={() => {
          setOpenModal(true);
        }}
        type="button"
      >
        Show all offering
      </button>

      <Modal
        onClose={() => {
          setOpenModal(false);
        }}
        open={openModal}
      >
        <div className="h-full overflow-scroll">
          <div className="h-[80vh] sm:h-[40rem]">
            <div className="pt-3 flex items-center pb-4">
              <Icon
                className="w-6 h-6 mr-1 mb-3 text-primary1"
                icon="ic:round-local-offer"
              />
              <h3 className="text-2xl mb-4 font-bold text-primary1">
                What this place offers
              </h3>
            </div>
            <AttributesAccordions
              categories={categories}
              attributeGroups={attributeGroups}
              attributes={attributes}
            />
            {/* <br />
            <FacilitiesAccordion
              attributesGroup={FacilitiesAG}
              attributes={attributes}
            />
            <br />
            <WaterparksAccordion
              category={WaterParksAG}
              attributes={attributes}
            /> */}
          </div>

          {/*<Accordion>
            {Object.entries(amenitiesData).map(([category, items]) => (
              <Accordion.Panel key={category}>
                <Accordion.Title className="p-4">{category}</Accordion.Title>
                <Accordion.Content className="p-4">
                  {items.map((amenity) => (
                    <>
                      <div key={amenity.id} className="flex items-center gap-5">
                        <div className="mr-2">
                          <img
                            src={amenity.iconUrl}
                            alt="icon"
                            className="h-8"
                          />
                        </div>
                        <div>{amenity.name}</div>
                      </div>
                      <hr className="my-4 border-t border-gray-300" />
                    </>
                  ))}
                </Accordion.Content>
              </Accordion.Panel>
            ))}
          </Accordion>*/}
        </div>
      </Modal>
    </div>
  );
}
