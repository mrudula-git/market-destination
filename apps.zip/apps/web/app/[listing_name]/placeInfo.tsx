"use client";
import React, { useState } from "react";
// import { Button, Modal, Accordion } from "flowbite-react";
import packagesData from "./data.json";

const amenitiesData = {
  Internet: [
    {
      heading: "Internet",
      id: 4,
      name: "Wifi",
      iconUrl: "https://cdn-icons-png.flaticon.com/128/2696/2696335.png",
    },
    {
      heading: "Internet",
      id: 5,
      name: "Security cameras",
      iconUrl: "https://cdn-icons-png.flaticon.com/128/2933/2933760.png",
    },
  ],
  "Kitchen and dining": [
    {
      heading: "Kitchen and dining",
      id: 3,
      name: "Kitchen",
      iconUrl: "https://cdn-icons-png.flaticon.com/128/1980/1980708.png",
    },
  ],
  "Scenic views": [
    {
      heading: "Scenic views",
      id: 1,
      name: "Garden view",
      iconUrl: "https://cdn-icons-png.flaticon.com/128/2545/2545521.png",
    },
    {
      heading: "Scenic views",
      id: 2,
      name: "Mountain views",
      iconUrl: "https://cdn-icons-png.flaticon.com/128/1020/1020719.png",
    },
  ],

  " Play area": [
    {
      heading: "Play area",
      id: 6,
      name: "Kids Play Area",
      iconUrl: "https://cdn-icons-png.flaticon.com/128/11365/11365521.png",
    },
  ],
};

export default function PlaceInfo() {
  const { description } = packagesData.listing;

  // State to handle toggling additional text
  const [showMoreText, setShowMoreText] = useState(false);

  // Function to toggle more text
  const toggleMoreText = () => {
    setShowMoreText(!showMoreText);
  };

  const [openModal, setOpenModal] = useState(false);

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 m-auto p-2 sm:p-5">
      <div className="max-w-2xl p-2 sm:p-5 bg-white md:col-span-2">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-2xl font-bold">Farm stay in Pune, India</h2>
        </div>

        <div className="mb-4">
          <p className="text-gray-700">
            2 guests · 1 bedroom · 2 beds · 1 bath
          </p>
          <p className="text-gray-700">Dedicated workspace</p>
        </div>
        <hr className="my-4 border-t border-gray-300" />

        <div className="">
          <p>
            {description}
            {showMoreText ? (
              <>
                <p>
                  - Private home theatre in the living room with an Ultra HD
                  projector
                </p>
                <p>- Private pool with a huge private deck area</p>
                <p>- 3 Master bedrooms</p>
                <button
                  className="text-blue-500 underline"
                  onClick={toggleMoreText}
                >
                  Show less
                </button>
              </>
            ) : (
              <>
                <p>
                  - Private home theatre in the living room with an Ultra HD
                  projector
                </p>
                <button
                  className="text-blue-500 underline"
                  onClick={toggleMoreText}
                >
                  Show more
                </button>
              </>
            )}
          </p>
        </div>

        <hr className="my-4 border-t border-gray-300" />
        <div className="container mx-auto mt-4 ml-2 sm:ml-5">
          <section className="">
            <h2 className="text-2xl font-bold mb-4">What this place offers</h2>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2">
              {Object.entries(amenitiesData).map(([category, items]) => (
                <div key={category} className="mb-4">
                  <h2 className="text-xl font-semibold mb-2">{category}</h2>
                  <div className="grid grid-cols-2">
                    {items.map((amenity) => (
                      <div key={amenity.id} className="flex items-center gap-2">
                        <div className="mr-2">
                          <img
                            src={amenity.iconUrl}
                            alt="icon"
                            className="h-6"
                          />
                        </div>
                        <div>{amenity.name}</div>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>

            <div className="mt-4">
              <button
                className="border px-4 py-2 text-black rounded-full hover:bg-cyan-200"
                onClick={() => setOpenModal(true)}
              >
                Show all amenities
              </button>
              {/* <Modal
                show={openModal}
                onClose={() => setOpenModal(false)}
                className="flex flex-col bg-gray-500 z-10"
              >
                <Modal.Header>What this place offers</Modal.Header>
                <Modal.Body style={{ maxHeight: "300px", overflowY: "auto" }}>
                  <div className="container mx-auto">
                    <Accordion>
                      {Object.entries(amenitiesData).map(
                        ([category, items]) => (
                          <Accordion.Panel key={category}>
                            <Accordion.Title className="p-4">
                              {category}
                            </Accordion.Title>
                            <Accordion.Content className="p-4">
                              {items.map((amenity) => (
                                <div
                                  key={amenity.id}
                                  className="flex items-center gap-2"
                                >
                                  <div className="mr-2">
                                    <img
                                      src={amenity.iconUrl}
                                      alt="icon"
                                      className="h-6"
                                    />
                                  </div>
                                  <div>{amenity.name}</div>
                                </div>
                              ))}
                            </Accordion.Content>
                          </Accordion.Panel>
                        )
                      )}
                    </Accordion>
                  </div>
                </Modal.Body>
              </Modal> */}
            </div>
          </section>
        </div>
        {/* <hr className="my-4 border-t border-gray-300" /> */}
      </div>
    </div>
  );
}
