"use client";

import { Contacts } from "database";
import { useState } from "react";
import { Icon } from "@iconify/react";

type ListingIntroductionProps = {
  description?: string;
  contacts?: Contacts;
  socialMediaURLs?: {
    instagram?: string;
    website?: string;
    youtube?: string;
  };
};

const icons = {
  facebook: "fa6-brands:facebook",
  instagram: "fa6-brands:instagram",
  x: "fa6-brands:square-x-twitter",
  youtube: "fa6-brands:youtube",
  website: "fa6-solid:globe",
};

export default function ListingIntroduction({
  description,
  contacts,
  socialMediaURLs,
}: ListingIntroductionProps) {
  // console.log(socialMediaURLs);
  return (
    <div>
      <div className="flex gap-3">
        <div>
          {socialMediaURLs?.instagram ? (
            <a
              href={socialMediaURLs?.instagram}
              target="_blank"
              rel="noreferrer"
            >
              <Icon className="w-6 h-6" icon={icons.instagram} />
            </a>
          ) : null}
        </div>
        <div>
          {socialMediaURLs?.youtube ? (
            <a href={socialMediaURLs?.youtube} target="_blank" rel="noreferrer">
              <Icon className="w-6 h-6" icon={icons?.youtube} />
            </a>
          ) : null}
        </div>
        <div className="border-l pl-2">
          {socialMediaURLs?.website ? (
            <a
              className="flex items-center gap-1"
              href={socialMediaURLs?.website}
              target="_blank"
              rel="noreferrer"
            >
              {/* <Icon className="w-4 h-4" icon={icons.website} /> */}
              <span className="hover:underline max-w-36 md:max-w-fit truncate">
                Website
              </span>
            </a>
          ) : null}
        </div>
      </div>

      <br />
      <div>{description}</div>

      {/* <br />
      <div>
        {showMoreText ? (
          <>
            <p>
              Private home theatre in the living room with an Ultra HD
              projector.
            </p>
            <p>Private pool with a huge private deck area.</p>
            <p>3 Master bedrooms.</p>
          </>
        ) : (
          <p>
            Private home theatre in the living room with an Ultra HD projector.
          </p>
        )}
      </div> */}

      {/* <br />
      {showMoreText || (
        <button
          className="text-blue-500 underline pb-4"
          onClick={toggleMoreText}
        >
          Show more
        </button>
      )} */}

      {/* Card section (temporary image) */}
      {/* <div className="p-2 sm:pr-5 md:col-span-1">
        <div className="bg-white p-6 rounded-md shadow-md mb-4 border">
          <h2 className="text-2xl font-semibold mb-4">Package 1</h2>

          <div className="mb-4">
            <h3 className="text-lg font-semibold">Package Info</h3>
            <p className="text-gray-600">
              Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do
              eiusmod tempor incididunt ut labore et dolore magna aliqua.
            </p>
          </div>

          <div className="mb-4">
            <h3 className="text-lg font-semibold">Price</h3>
            <p className="text-gray-600">$100 per night</p>
          </div>

          <div className="mb-4">
            <h3 className="text-lg font-semibold">Guest Details</h3>
            <p className="text-gray-600">Max guests: 2</p>
          </div>

          <button className="bg-fuchsia-700 text-white py-2 px-4 rounded-md">
            Book Now
          </button>
        </div>
      </div> */}
    </div>
  );
}
