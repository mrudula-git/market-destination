"use client"

import { Icon } from "@iconify/react/dist/iconify.js";

export default function ListingOffers() {
  return (
    <div className="pt-3 flex items-center pb-4">
      <Icon  className="w-6 h-6 mr-1" icon="ic:round-local-offer" />
      <h2 className="text-xl font-bold">What this place offers</h2>
      <br />
    </div>
  );
}
