"use client";

import { useState } from "react";
import ReviewCard from "../../components/UI/Cards/review-card";
import Modal from "../../components/UI/Modals/modal";
import ReviewsTabs from "../../components/UI/Tabs/reviews-tabs";
import type { ReviewDetails, Reviewers, Reviews } from "database";

type Review = Partial<Reviews> & {
  details: ReviewDetails;
  reviewer: Reviewers;
};
interface ListingReviewsProps {
  reviews: Review[];
  showMore: boolean;
  showAll: boolean;
  writeReview: boolean;
  setOpen: boolean;
  setClose: () => void;
}

export default function ListingReviews({
  reviews,
  showMore,
  showAll = true,
  writeReview = false,
  setOpen = false,
  setClose,
}: ListingReviewsProps) {
  let displayedReviews = showAll ? reviews : reviews.slice(0, 3);

  const [openModal, setOpenModal] = useState(setOpen);
  const [writeReviews, setWriteReviews] = useState(writeReview);

  let listingsId;
  reviews.map((review) => {
    listingsId = review.listingsId;
  });

  return (
    <div>
      <div className="md:mx-4">
        {displayedReviews.map((review) => (
          <div key={review.id}>
            <ReviewCard {...review} />
          </div>
        ))}

        <br />

        {showMore && (
          <button
            className="px-6 py-2 rounded-full border border-btn-primary text-btn-primary font-bold hover:underline"
            onClick={() => {
              setOpenModal(true);
              setWriteReviews(false);
            }}
            type="button"
          >
            Show all reviews
          </button>
        )}
      </div>

      {/* <Modal
        onClose={() => {
          setOpenModal(false);
        }}
        open={openModal}
      >
        <ReviewsTabs
          activeWriteAReview={writeReviews}
          listingsId={listingsId}
        />
      </Modal> */}
    </div>
  );
}
