"use client";

import { Icon } from "@iconify/react";
import { useState } from "react";
import type { Package } from "../../constants/types";

type PackagesProps = {
  packages: Package[];
};

export default function ListingPackages({ packages }: PackagesProps) {
  const [visiblePackages, setVisiblePackages] = useState(3);

  function handleShowMore() {
    setVisiblePackages((prevVisiblePackages) => prevVisiblePackages + 5);
  }

  return (
    <div className="sticky top-20">
      {packages.slice(0, visiblePackages).map((_package) => (
        <div
          key={_package.id}
          className="p-6 rounded-xl mb-3 text-theme-text-light bg-opacity-75 bg-gradient-to-b from-theme-orange to-theme-red transition-all inset-0"
        >
          <div className="grid grid-cols-2 rounded-xl ">
            <div className="p-2 col-span-2 font-bold">{_package.name}</div>
            <div className="p-2 col-span-2">
              <div className="flex items-end gap-2">
                <Icon
                  className="w-6 h-6"
                  icon={"ic:sharp-supervisor-account"}
                />
                <span className="text-xl font-black">{`${_package.persons}`}</span>
                <span className="font-semibold">Person(s)</span>
              </div>
              {/* <div>{`${_package.persons}`} Children</div> */}
              {/* <div>{`${_package.persons}`} Teenagers</div> */}
              {/* <div>{`${_package.persons}`} Adults</div> */}
              {/* <div>{`${_package.persons}`} Seniors</div> */}
              {/* <div>{`${_package.persons}`} Seniors</div> */}
            </div>
            <div className="p-2 col-span-1"></div>
            <div className="p-2 col-span-1 text-end text-xl font-black">{`₹ ${_package.price.amount}`}</div>
          </div>
        </div>
      ))}

      {visiblePackages < packages.length && (
        <button
          onClick={handleShowMore}
          className="w-full md:w-auto py-2 rounded-full font-bold hover:underline mb-4"
        >
          Show More
        </button>
      )}
      <br />
      {/* <div className="border w-full aspect-square">ads box</div> */}
    </div>
  );
}
