import React from "react";

const SimilarProperties = ({ properties }: any) => {
  return (
    <div className="relative">
      <h2 className="text-2xl ml-2 sm:ml-5 font-bold mb-4">Similar Places</h2>
      <div className="flex space-x-2 overflow-x-auto relative">
        <div className="scroll-indicator absolute top-1/2 right-4 transform -translate-y-1/2 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
          {/* Scroll Indicator Icon */}
          <div className="productCard_arrowIconBox__O_S5n  true">
            <img src="https://cdn-icons-png.flaticon.com/128/318/318275.png" alt="icon"/>
          </div>
        </div>
        <div className="flex space-x-2 overflow-x-auto">
          {properties.map((property: any) => (
            <div
              key={property.id}
              className="w-full sm:w-1/2 md:w-1/3 lg:w-1/3 xl:w-1/3 px-2 mb-4 custom-property-card"
              style={{ minWidth: "300px" }}
            >
              <div className="property-card border bg-white p-4 rounded-md shadow-md">
                {/* Property Image */}
                <div className="property-image">
                  <img
                    src={property.image}
                    alt={property.name}
                    className="w-full h-40 object-cover mb-4 rounded-md"
                  />
                </div>
                {/* Property Details */}
                <div className="property-details text-center">
                  <p className="property-name text-lg font-semibold mb-2">
                    {property.name}
                  </p>
                  {/* Other property details */}
                  <p className="property-rating items-center mb-2">
                    <span className="rating text-yellow-500 mr-1">
                      {property.rating}
                    </span>
                    <span className="rating-text">Very Good</span>
                  </p>
                  <p className="property-price text-green-600 text-xl mb-1">
                    ₹ {property.price}
                  </p>
                  <p className="property-per-night text-gray-600 mb-2">
                    Per Night
                  </p>
                  <button className="select-stay-btn bg-fuchsia-700 text-white px-4 py-2 rounded-md mb-2">
                    SELECT STAY
                  </button>
                  {/* Additional property information */}
                  <p className="property-cancellation text-gray-600 mb-1">
                    Free Cancellation
                  </p>
                  <p className="property-breakfast text-gray-600">
                    Free Breakfast Available at Higher Price
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default SimilarProperties;
