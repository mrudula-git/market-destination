"use client";

import { Icon } from "@iconify/react";
import { useSearchParams } from "next/navigation"; // Import useSearchParams
import ListingsCard from "../../components/UI/Cards/listings-card";
import Pagination from "../../components/UI/pagination";
import { routes } from "../../constants/routes";

export default function ListingsResults({ count, listings }: any) {
  const searchParams = useSearchParams();

  const handleClearFilters = () => {
    let params = Object.fromEntries(searchParams);

    // console.log(params);
    delete params["data"];
    // console.log(params);

    const qs = new URLSearchParams(params);

    // console.log(searchParams.toString());
    const newUrl = `${routes.search}?${qs.toString()}`;
    location.replace(newUrl);
  };

  if (!listings || listings.length === 0) {
    return (
      <div className="lg:flex lg:flex-rows-4 lg:gap-40">
        <div className=" lg:flex-row-3"></div>
        <div className="items-center lg:flex-rows-4 justify-items-center text-center mt-5 md:mt-20 lg:mt-10">
          <div className="justify-items-center grid grid-cols-12">
            <div className="col-span-3"> </div>
            <div className="col-span-6">
              <Icon
                className="text-4xl rounded-full text-white bg-primary1"
                icon="ic:baseline-wifi-find"
              />
            </div>
            <div className="col-span-3"> </div>
          </div>
          <h3 className="font-bold mt-5">Sorry, no result found</h3>
          <p className="text-xs">
            Please update your filters to see more results
          </p>
          <button
            className="text-white bg-primary1 px-4 py-2 rounded-full mt-5"
            onClick={handleClearFilters}
          >
            Clear filters
          </button>
        </div>
      </div>
    );
  }

  return (
    <div>
      <h4 className="ml-4">
        Total {count} result{count > 1 ? "s" : ""} found.
      </h4>
      <br />
      <div>{/* <pre>{JSON.stringify(listings, null, 2)}</pre> */}</div>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-y-6">
        {listings?.map((listing: any, index: any) => (
          <ListingsCard key={index} listing={listing} />
        ))}
      </div>

      {/* <Model
        open={showModal}
        onClose={() => {
          setShowModal(false);
        }}
      >
        <ListingsFilters />
      </Model> */}
      <Pagination listings={listings} count={count} />
    </div>
  );
}
