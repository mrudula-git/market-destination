"use client";

import { Icon } from "@iconify/react";
import { useWindowSize } from "@uidotdev/usehooks";
import { useRouter, useSearchParams } from "next/navigation";
import { useEffect, useMemo, useState } from "react";
import { twMerge } from "tailwind-merge";
import LocationsAccordion from "../../components/UI/Accordions/locations-accordion";
import SuggestedFiltersAccordion from "../../components/UI/Accordions/suggested-filters-accordion";
import Modal from "../../components/UI/Modals/modal";
import useCheckboxStore from "../../stores/zustand/checkbox.store";
import { useCustomStore } from "../../stores/zustand/search.store1";
import { useIndicatorsStore } from "../../stores/zustand/indicators.store";
import ReviwsFilterAccordion from "../../components/UI/Accordions/reviews-filter-accordion";

interface Result {
  categories: Array<{ [key: string]: boolean }>;
  attributegroup: Array<{ [key: string]: boolean }>;
  locations?: Array<string>;
  reviews?: string | number;
}

type ListingsFiltersProps = {
  props: any;
  visible?: boolean;
  expanded?: boolean;
  onApply?: () => void;
};

type List = {
  id?: string;
  _id?: string;
  name: string;
};
export default function ListingsFilters({
  props,
  visible,
  expanded = false,
  onApply,
}: ListingsFiltersProps) {
  const router = useRouter();
  const searchParams = useSearchParams();

  const customStore = useCustomStore();
  let checkedValues = customStore.checkedValues;

  const { setPageLoading } = useIndicatorsStore();

  const { width } = useWindowSize();
  const [responsiveVisibility, setResponsiveVisibility] = useState(visible);

  const [locationsFilters, setLocationsFilters] = useState([]);
  const [reviewFilters, setReviewFilters] = useState("");

  useEffect(() => {
    if (!width) return;
    if (visible === undefined) {
      // not passed from outside then calculte otherwise do as said
      if (width < 768) setResponsiveVisibility(false);
      else setResponsiveVisibility(true);
    }
  }, [width]);

  const transformDataStructure = (input: any) => {
    const result: Result = {
      categories: [],
      attributegroup: [],
      locations: [],
    };

    for (const key in input) {
      const categoryOrAttributeGroup = input[key];
      for (const id in categoryOrAttributeGroup) {
        if (id) {
          result[key === "category" ? "categories" : "attributegroup"].push({
            [id]: true,
          });
        }
      }
    }

    return result;
  };

  const result = transformDataStructure(checkedValues);
  const checkboxStore = useCheckboxStore(); // Add this line to get the checkbox store instance
  const [showModal, setShowModal] = useState(false);

  const handleApplyClick = () => {
    setShowModal(false);
    setPageLoading(true);

    if (onApply) onApply();
    let existingParams = new URLSearchParams(window.location.search);

    result["locations"] = locationsFilters;
    result["reviews"] = reviewFilters;
    // console.log(result);

    let encodedData = encodeURIComponent(JSON.stringify(result));
    existingParams.set("data", encodedData);

    // const checkedItemsParam = encodeURIComponent(JSON.stringify(checkedItems));
    // existingParams.set("checkedItems", checkedItemsParam);

    const newUrl = `${window.location.pathname}?${existingParams.toString()}`;
    router.push(newUrl);
  };

  const list = useMemo(() => {
    return props.map(({ _id, name }: List) => ({ id: _id, name }));
  }, [props]);

  const listJSON = JSON.stringify(list);

  useEffect(() => {
    // console.log(lis  tJSON);
    localStorage.setItem("list", listJSON);
  }, [listJSON]);

  return (
    <div className="h-full text-primary1 pl-2">
      <div className={twMerge("md:block", !responsiveVisibility && "hidden")}>
        <div className="text-lg font-semibold mb-4">Filters</div>
        {/* <pre>{JSON.stringify(responsiveVisibility)}</pre> */}

        {/* <AmenitiesAccordion /> */}
        {/* <br />

      <hr />
      <br /> */}
        <div className="relative">
          <button
            className="w-full sticky top-16 z-10 py-1.5 px-4 border bg-base0 border-btn-primary text-btn-primary rounded-full font-semibold hover:bg-btn-primary hover:text-base0"
            type="button"
            onClick={handleApplyClick}
          >
            Apply filters
          </button>
        </div>

        <br />
        <LocationsAccordion
          initialState={locationsFilters}
          onSelectionChange={(values) => {
            setLocationsFilters(values);
          }}
        />

        <br />
        <ReviwsFilterAccordion
          initialState={locationsFilters}
          onSelectionChange={(values) => {
            setReviewFilters(values);
          }}
        />

        <br />
        <SuggestedFiltersAccordion
          props={props}
          expanded={expanded}
          showModel={showModal}
        />

        {/* <pre>{JSON.stringify(checkboxStore.checkedItems, null, 2)}</pre> */}
      </div>

      <div
        className={twMerge("block md:hidden", responsiveVisibility && "hidden")}
      >
        <button
          className="w-full py-2 inline-flex justify-center items-center gap-2 border border-primary1 rounded-full"
          onClick={() => {
            setShowModal(true);
          }}
        >
          <Icon className="w-5 h-5" icon={"ic:round-filter-alt"} />
          <span>Filter</span>
        </button>

        <Modal
          open={showModal}
          onClose={() => {
            setShowModal(false);
          }}
        >
          <ListingsFilters
            props={props}
            visible={true}
            expanded={true}
            onApply={() => {
              handleApplyClick();
              setShowModal(false);
            }}
          />
          {/* <h2 className="font-semibold mb-2">Suggested Filters</h2> */}
        </Modal>
      </div>
    </div>
  );
}
