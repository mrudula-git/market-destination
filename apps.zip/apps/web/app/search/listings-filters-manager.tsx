"use client";

import { useSearchParams } from "next/navigation";
import { useEffect } from "react";
import { Listing } from "../../constants/types";
import { useSearchFiltersStore } from "../../stores/zustand/search-filters.store";

type ListingsFiltersManagerProps = {
  listings?: Listing[];
};

export default function ListingsFiltersManager({
  listings,
}: ListingsFiltersManagerProps) {
  if (!listings) return null;

  const searchParams = useSearchParams();
  const filterData = searchParams.get("data");

  const { setLocationCities } = useSearchFiltersStore();

  useEffect(() => {
    if (!filterData) return;

    let appliedFilters = JSON.parse(decodeURIComponent(filterData));
    console.log({ appliedFilters });
  }, [filterData]);

  useEffect(() => {
    const _contacts = listings.map((listing) => listing.contacts);
    const _locationCities = new Set();
    _contacts.forEach((c) => {
      if (!c.city) return;
      _locationCities.add(c.city);
    });
    setLocationCities(Array.from(_locationCities) as string[]);
  }, []);

  return <div></div>;
}
