"use client";

import { useEffect, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { Icon } from "@iconify/react";
import { useCustomStore } from "../../stores/zustand/search.store1";
import { useSearchFiltersStore } from "../../stores/zustand/search-filters.store";
import type {
  Listings,
  ListingsAttributes,
  ListingsAttributesGroup,
  ListingsCategories,
} from "database";
import apiKit from "../../utils/api/helper";
import { apis } from "../../constants/apis";
import { SearchParamsContext } from "next/dist/shared/lib/hooks-client-context.shared-runtime";
import { routes } from "../../constants/routes";

type ListingsAppliedProps = {
  listings: Partial<
    Listings & {
      categories: Partial<ListingsCategories>;
      attributeGroups: Partial<ListingsAttributesGroup>;
    }
  >[];
};

export default function ListingsFiltersApplied({
  listings,
}: ListingsAppliedProps) {
  const router = useRouter();
  const searchParams = useSearchParams();
  const customStore = useCustomStore();
  const data = searchParams.get("data");

  let appliedFilter1s = decodeURIComponent(data || "");

  const {
    categoriesIds,
    setCategoriesIds,
    categories,
    setCategories,
    attributeGroupsIds,
    setAttributeGroupsIds,
    attributeGroups,
    setAttributeGroups,
    attributes,
    setAttributes,
  } = useSearchFiltersStore();

  const [filters, setFilters] = useState<ListingsAttributes[]>();

  useEffect(() => {
    if (!listings) return;

    let categoriesIds = new Set();
    let attributeGroupsIds = new Set();

    listings.forEach((listing) => {
      listing.categoriesId?.forEach((id) => categoriesIds.add(id));
      listing.attributeGroupsId?.forEach((id) => attributeGroupsIds.add(id));
    });

    (async () => {
      const data = await apiKit({
        api: apis.listingsAttributes,
        method: "POST",
        body: {
          categoriesId: Array.from(categoriesIds),
          attributeGroupsId: Array.from(attributeGroupsIds),
        },
      });

      const _attributes = data.attributes as ListingsAttributes[];

      setAttributes(_attributes);

      const __categories = data.categories as ListingsCategories[];
      const __attributeGroups =
        data.attributeGroups as ListingsAttributesGroup[];
      setCategoriesIds(Array.from(categoriesIds) as string[]);
      setAttributeGroupsIds(Array.from(attributeGroupsIds) as string[]);

      const _categories = [];
      categoriesIds.forEach((id) => {
        const category = {
          id: id,
          name: __categories.find((c) => c.id === id)?.name,
          attributes: _attributes.filter((attribute) =>
            attribute.categoriesId.includes(id as string)
          ),
        };
        _categories.push(category);
      });
      setCategories(_categories as ListingsCategories[]);

      const _attributeGroups = [];
      attributeGroupsIds.forEach((id) => {
        const attributeGroup = {
          id: id,
          name: __attributeGroups.find((ag) => ag.id === id)?.name,
          attributes: _attributes.filter((attribute) =>
            attribute.listingAttributeGroupsId.includes(id as string)
          ),
        };
        _attributeGroups.push(attributeGroup);
      });
      setAttributeGroups(_attributeGroups as ListingsAttributesGroup[]);
    })();
  }, [listings]);

  // if (!data) return <div></div>;

  useEffect(() => {
    if (!data || !attributes.length) return;

    let appliedFilters = decodeURIComponent(data);
    appliedFilters = JSON.parse(appliedFilters);

    const _attributeIds = new Set();
    appliedFilters.attributegroup.forEach((el) => {
      _attributeIds.add(Object.keys(el)[0]);
    });
    appliedFilters.categories.forEach((el) => {
      _attributeIds.add(Object.keys(el)[0]);
    });
    const _filters = attributes.filter(({ id }) =>
      Array.from(_attributeIds).includes(id)
    );

    setFilters(_filters);
  }, [data, attributes]);

  function handleRemoveFilter(id: string) {
    customStore.removeItemById(id);

    if (!data) return;
    const newArray = filters?.filter((item) => item.id !== id);

    // setFilters(newArray);
    let appliedFilters = decodeURIComponent(data);
    appliedFilters = JSON.parse(appliedFilters);

    const _appliedFilters = {};
    // for (const key of Object.keys(appliedFilters)) {
    //   _appliedFilters[key] = appliedFilters[key].filter(
    //     (f) => !f.hasOwnProperty(id)
    //   );
    // }
    for (const key of Object.keys(appliedFilters)) {
      if (Array.isArray(appliedFilters[key])) {
        _appliedFilters[key] = appliedFilters[key].filter(
          (f) => !f.hasOwnProperty(id)
        );
      } else {
        _appliedFilters[key] = appliedFilters[key];
      }
    }

    const searchParams = new URLSearchParams(location.search);
    searchParams.set(
      "data",
      encodeURIComponent(JSON.stringify(_appliedFilters))
    );
    const nextPage = `${routes.search}?${searchParams.toString()}`;
    router.push(nextPage);
  }
  const [showAllFilters, setShowAllFilters] = useState(false);

  function handleMoreButtonClick() {
    setShowAllFilters((prev) => !prev);
  }
  return (
    <div>
      <div>
        {/* <pre>{JSON.stringify(filters, null, 2)}</pre> */}
        {/* <pre>
          {JSON.stringify(
            { categoriesIds, attributeGroupsIds, attributes },
            null,
            2
          )}
        </pre> */}
      </div>

      <div className="relative">
        <div
          className={`flex gap-2 ${
            showAllFilters ? "flex-wrap" : "overflow-x-auto scrollbar-hide"
          }`}
        >
          {/* Render only a subset of filters based on showAllFilters state */}
          {(showAllFilters ? filters : filters)?.map((item, key) => (
            <button
              className="whitespace-nowrap inline-flex items-center gap-2 px-3.5 py-1.5 border border-primary1 text-primary1 rounded-full text-md hover:text-base0 hover:bg-primary1"
              key={key}
              type="button"
            >
              <span>{item.name}</span>
              <Icon
                className=""
                icon={"carbon:close-outline"}
                onClick={() => handleRemoveFilter(item.id)}
              />
            </button>
          ))}
        </div>
        <br />
        {filters && filters.length > 6 && (
          <div className="absolute right-0 top-0 z-10 bg-base0 pl-5 ">
            <button
              className="whitespace-nowrap inline-flex items-center gap-2 px-3.5 py-2 rounded-full    text-primary1 hover:underline"
              onClick={handleMoreButtonClick}
              type="button"
            >
              {showAllFilters ? "Less" : "More"}
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
