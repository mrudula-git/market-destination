"use client";
import React, { useState } from "react";
import Listingcard from "../../components/listingcard";
import Search from "../../components/search";
import List from "../../components/listingcard1";
import Pagination from "../../components/pagination";
import Map from "../../components/map";
import ModalExample from "../../components/model";
import { Icon } from "@iconify/react/dist/iconify.js";

const SidebarCardLayout: React.FC = () => {
  // const [openedIndexes, setOpenedIndexes] = useState<number[]>([0, 1]);

  // ... other state and functions

  const data: { [key: string]: string[] } = {
    popular: [
      "Option 1",
      "Option 2",
      "Option 3",
      "Option 4",
      "Option 1",
      "Option 2",
      "Option 3",
      "Option 4",
    ],
    property_types: ["Option A", "Option B", "Option C", "Option D", "hi"],
    amenities: ["Option X", "Option Y", "Option Z", "Option W", "hi"],
    distance_from: [
      "Option Alpha",
      "Option Beta",
      "Option Gamma",
      "Option Delta",
      "hi",
    ],
    neighbourhoods: [
      "Option One",
      "Option Two",
      "Option Three",
      "Option Four",
      "hi",
    ],
    traveller_rating: [
      "Option 1 Star",
      "Option 2 Stars",
      "Option 3 Stars",
      "Option 4 Stars",
      "hi",
    ],
    hotel_className: [
      "Option Budget",
      "Option Standard",
      "Option Premium",
      "Option Luxury",
      "hi",
    ],
  };

  const [openedIndexes, setOpenedIndexes] = useState<number[]>([0, 1]);
  const areAllIndexesOpened = openedIndexes.length === Object.keys(data).length;

  

  const [isModalVisible, setIsModalVisible] = useState(false);
  const [currentFieldIndex, setCurrentFieldIndex] = useState<number>(0);

  const handleShowMoreClick = (index: number) => {
    setIsModalVisible(true);
    setCurrentFieldIndex(index);
  };

  const handleCloseModal = () => {
    setIsModalVisible(false);
  };

  const toggleDropdown = (index: number) => {
    const isIndexOpened = openedIndexes.includes(index);

    if (isIndexOpened) {
      setOpenedIndexes(openedIndexes.filter((i) => i !== index));
    } else {
      setOpenedIndexes([...openedIndexes, index]);
    }
  };
  return (
    <div>
      <div className=" mx-auto items-center">
        <div></div>
        <div className="sticky  top-0 z-40 w-full bg-white">
          <div className="container mx-auto">
            <Search />
          </div>
        </div>
        <div className="mx-auto ">
          <div className="container mx-auto">
            <div className="grid md:grid-cols-5 sm:grid-cols-4  md:gap-4 relative pb-36">
              <div className="col-span-5 md:col-span-3">
                <div className="grid grid-cols-3 relative gap-4">
                  {/* Sidebar */}

                  <div className="hidden lg:block pr-7 col-span-1 text-center pt-6">
                  {Object.keys(data).map((field, index) => (
                  <div key={index} className="mb-4">
                    <div
                      className="flex items-center justify-between"
                      onClick={() => toggleDropdown(index)}
                    >
                      <h3>{field}</h3>
                      <span className="cursor-pointer">
                        {openedIndexes.includes(index) ? (
                          <Icon icon="fe:arrow-up" />
                        ) : (
                          <Icon icon="fe:arrow-down" />
                        )}
                      </span>
                    </div>
                    {openedIndexes.includes(index) && (
                      <div className="mt-2">
                        {data[field]!.map((option, i) => (
                          <div
                            key={i}
                            className={`flex items-center mb-2 ${
                              i > 3 ? "hidden" : ""
                            }`}
                          >
                            <input
                              type="checkbox"
                              id={`${field}-${option}-${i}`}
                              name={`${field}-${option}-${i}`}
                              className="mr-2 form-checkbox h-5 w-5 text-black-600 border-gray-300 rounded focus:text-black accent-black"
                            />
                            <label htmlFor={`${field}-${option}-${i}`}>
                              {option}
                            </label>
                          </div>
                        ))}
                        {data[field]!.length > 4 && (
                          <button
                            className="cursor-pointer text-slate-950 font-bold flex items-center"
                            onClick={() => handleShowMoreClick(index)}
                          >
                            {"Show All"}
                            <span className="cursor-pointer ml-1 text-slate-950">
                              <Icon icon="fe:arrow-down" />
                            </span>
                          </button>
                        )}
                      </div>
                    )}
                    <hr className="my-4" />
                  </div>
                ))}
                    <div className="w-full h-screen pt-7">
                      <img
                        src="https://images.unsplash.com/photo-1505144808419-1957a94ca61e?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MjN8fG5hdHVyZXxlbnwwfHwwfHx8MA%3D%3D"
                        alt="nature"
                      />
                    </div>
                  </div>

                  {/* Cards */}
                  <div className="col-span-3 lg:col-span-2 lg:col-start-2 overflow-y-auto ">
                    <List />
                    <div>
                      <Listingcard />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div
            className="hidden md:block md:w-2/5 right-0 top-2 h-full fixed pt-12"
            style={{ zIndex: "0" }}
          >
            <div className="hidden md:block col-span-2 lg:col-span-2 lg:col-start-4   z-10 sticky  pl-5">
              {/* Override width for the map component */}
              {!areAllIndexesOpened && (
                <div className="w-full h-full">
                  <Map />
                </div>
              )}
            </div>
          </div>

          <div className="text-end md:w-3/5 md:flex justify-end">
            <Pagination />
          </div>
        </div>
      </div>

      <ModalExample open={isModalVisible} onClose={handleCloseModal}>
        <div key={currentFieldIndex} className="checkbox-group">
          {data[Object.keys(data)[currentFieldIndex ?? 0]!]?.map((option, i) => (
            <div key={i} className="checkbox">
              <input
                type="checkbox"
                id={`${Object.keys(data)[currentFieldIndex]}-${option}-${i}`}
                name={`${Object.keys(data)[currentFieldIndex]}-${option}-${i}`}
                className="pr-2"
                // Other checkbox attributes...
              />
              <label
                htmlFor={`${Object.keys(data)[currentFieldIndex]}-${option}-${i}`}
                className="px-3"
              >
                {option}
              </label>
            </div>
          ))}
        </div>
      </ModalExample>
    </div>
  );
};
export default SidebarCardLayout;
