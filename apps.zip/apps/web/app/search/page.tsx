import Head from "next/head";
import { ErrorBoundary } from "react-error-boundary";
import SearchField from "../../components/search-field";
import { apis } from "../../constants/apis";
import apiKit from "../../utils/api/helper";
import ListingsFilters from "./listings-filters";
import ListingsFiltersApplied from "./listings-filters-applied";
import ListingsFiltersManager from "./listings-filters-manager";
import ListingsResults from "./listings-results";
// import { useCustomStore } from "../../stores/zustand/search.store1";

interface PageProps {
  searchParams: GetDataProps;
}

// export function generateStaticParams() {
//   const queries = [{ query: "one" }, { query: "two" }];
//   return queries;
// }

type GetDataProps = {
  query: string;
  category: string;
  data: string;
  page: number | string;
  checkedItems: any;
};

async function getData({
  query,
  category,
  data,
  page,
  checkedItems,
}: GetDataProps) {
  let filter = data ? JSON.parse(decodeURIComponent(data)) : [];
  // if (
  //   (filter.category && filter.category.length > 0) ||
  //   (filter.attributegroup && filter.attributegroup.length > 0)
  // ) {
  // } else {
  //   filter = [];
  // }

  const body = {
    query,
    category,
    filter,
    page,
    checkedItems: checkedItems
      ? JSON.parse(decodeURIComponent(checkedItems))
      : null,
  };

  // console.log(body, "body");

  const { count, listings, reviewSummary } = await apiKit({
    method: "POST",
    api: apis.search,
    body,
  });

  // const count = data?.count;
  // const listings = data?.listings;
  // const reviewSummary = data?.reviewSummary;

  return { listings, count, reviewSummary };
}

export default async function Page({ searchParams }: PageProps) {
  // const data = getSearchQueries(searchParams.query);
  console.log(searchParams, "searchParams");
  const { count, listings, reviewSummary } = await getData(searchParams);

  const pageTitle = `Findigoo | ${searchParams.query}`;
  const pageDescription = `Findigoo | ${searchParams.category} | Search`;

  return (
    <div className="bg-base0">
      <>
        <title>{pageTitle}</title>
        <meta name="description" content={pageDescription} />
        <meta name="type" content="website" />

        <meta property="og:title" content={pageTitle} />
        <meta property="og:description" content={pageDescription} />
        <meta property="og:type" content="website" />
      </>
      {/* <>
      <meta title="title" content={listings?.[0]?.name ?? ""} />
      <meta name="description" content={listings?.[0]?.description ?? ""}/>
      </> */}
      <div className="sticky top-0 z-30 bg-base0">
        <div className="max-w-screen-lg mx-auto px-2 py-3 bg-base0">
          {/* <form className="flex items-center gap-4">
                <input
                  className="flex-grow px-6 rounded-full"
                  placeholder="Search..."
                />
                <button type="submit">Search</button>
              </form> */}
          <ErrorBoundary fallback={<div>CSR Inside</div>}>
            <SearchField />
          </ErrorBoundary>
        </div>
      </div>

      <div className="relative">
        {/* <div className="absolute top-0 inset-x-0 z-0 h-screen grid grid-cols-11">
          <div className="col-span-6"></div>
          <div className="col-span-5 h-screen">
            <Map />
          </div>
        </div> */}
        <div className="">
          <ListingsFiltersManager listings={listings} />
          <div className="container mx-auto px-2">
            <div className="relative grid md:grid-cols-12">
              <div className="md:col-span-12 pt-3 z-10 bg-base0">
                <div className="grid grid-cols-1 md:grid-cols-4 lg:grid-cols-6 gap-3">
                  <div className="col-span-1">
                    <ListingsFilters props={listings} />
                  </div>
                  <div className="md:col-span-3 lg:col-span-5">
                    <ErrorBoundary fallback={<div>CSR Inside</div>}>
                      <ListingsFiltersApplied listings={listings} />
                    </ErrorBoundary>

                    {/* <ErrorBoundary fallback={<div>CSR Inside</div>}> */}
                    <ListingsResults count={count} listings={listings} />
                    {/* </ErrorBoundary> */}
                  </div>
                </div>
              </div>
            </div>

            <div></div>

            {/* <div className="fixed hidden h-screen w-2/4 -z-0 md:block right-0 inset-y-0">
              <GoogleMaps listings={data?.listings} />
            </div> */}
          </div>
        </div>
      </div>

      <br />
      <br />

      {/* <div>
        <p>Page</p>
        <p>Query Params</p>
      </div> */}
      {/* <SearchLayout>
          <pre>{JSON.stringify(data, null, 2)}</pre>
        </SearchLayout> */}
    </div>
  );
}
