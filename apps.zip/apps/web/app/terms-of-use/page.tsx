export default function TermsOfUse() {
  return (
    <>
      <>
        <title>Findigoo | Terms of us</title>
      </>
      <div className="bg-base0 text-primary1">
        <div className="max-w-screen-lg mx-auto px-2">
          <div className="min-h-[50vh]">
            <br />
            <h2 className="text-2xl font-semibold mb-2">Terms of Use</h2>
            <br />
            <p>
              FINDIGOO.COM –WATERPARK, RESORT &amp; AGROTOURISM BOOKING WEBSITE
              TERMS AND CONDITIONS
            </p>
            <br />
            <p>
              Welcome to Findigoo (the “Website”) By accessing and using this
              website, you agree to comply with the following terms and
              conditions. Please read these terms carefully before proceeding
              with any booking or using any services offered by Findigoo. If you
              do not agree with any of these terms, you must refrain from using
              our services.
            </p>
            <br />

            <h3 className="text-xl font-semibold mb-2">
              <u>Website Usage</u>
            </h3>
            <ol type="a" className="ml-4 legal-contents-lists">
              <li>
                The Findigoo website is intended for personal and commercial use
                only.
              </li>
              <li>
                You must be at least 18 years of age or older to make bookings
                on this website. If you are under 18, you must use this website
                under the supervision of a parent or legal guardian.
              </li>
              <li>
                You agree to provide accurate and complete information during
                the booking process and ensure the details provided are true.
              </li>
              <li>
                You are responsible for maintaining the confidentiality of your
                account login credentials and for all activities performed under
                your account.
              </li>
              <li>
                Findigoo reserves the right to refuse service, terminate
                accounts, or cancel bookings at its sole discretion without
                prior notice, if we suspect any violation of these terms or any
                fraudulent activity.
              </li>
            </ol>
            <br />

            <h3 className="text-xl font-semibold mb-2">
              <u>Booking and Payment</u>
            </h3>
            <ol type="a" className="ml-4 legal-contents-lists">
              <li>
                All bookings made through Findigoo are subject to availability.
              </li>
              <li>
                By making a booking, you agree to pay the total amount as
                displayed, including applicable taxes and fees, at the time of
                booking.
              </li>
              <li>
                Payment methods accepted on the website may include credit
                cards, debit cards, and other forms of electronic payment.
              </li>
              <li>
                Findigoo reserves the right to change the prices and
                availability of bookings at any time without prior Intimation.
              </li>
            </ol>
            <br />

            <h3 className="text-xl font-semibold mb-2">
              <u>Cancellation and Refund</u>
            </h3>
            <ol type="a" className="ml-4 legal-contents-lists">
              <li>
                Cancellation policies vary based on the type of booking,
                specific accommodation, and other factors. It is essential to
                review the cancellation policy before making a booking.
              </li>
              <li>
                Refunds, if applicable, will be processed based on the
                cancellation policy and within a reasonable timeframe.
              </li>
              <li>
                Findigoo will not be liable for any charges or expenses incurred
                as a result of a cancelled booking.
              </li>
            </ol>
            <br />

            <h3 className="text-xl font-semibold mb-2">
              <u>User Content</u>
            </h3>
            <ol type="a" className="ml-4 legal-contents-lists">
              <li>
                Users may have the option to post reviews, comments, photos, or
                other content on the website. By doing so, you grant Findigoo’s
                a non-exclusive, royalty-free, perpetual, and worldwide license
                to use, modify, reproduce, and display such content for
                promotional and other business purposes.
              </li>
              <li>
                You agree not to post any content that is illegal, offensive,
                harmful, defamatory, or infringes upon the rights of others.
                Findigoo reserves the rights to delete such comment or post.
              </li>
            </ol>
            <br />

            <h3 className="text-xl font-semibold mb-2">
              <u>Intellectual Property</u>
            </h3>
            <ol type="a" className="ml-4 legal-contents-lists">
              <li>
                All content on the Findigoo website, including text, graphics,
                logos, images, software, and other materials, is the property of
                Findigoo or its content suppliers and protected by applicable
                intellectual property laws.
              </li>
              <li>
                You may not reproduce, distribute, display, perform, or create
                derivative works of the website’s content without prior written
                consent from Findigoo.
              </li>
            </ol>
            <br />

            <h3 className="text-xl font-semibold mb-2">
              <u>Liability Disclaimer</u>
            </h3>
            <ol type="a" className="ml-4 legal-contents-lists">
              <li>
                Findigoo strives to provide accurate and up-to-date information
                on the website. However, we do not guarantee the accuracy,
                completeness, or reliability of the content, including the
                information about accommodations, amenities, Facilities and
                services.
              </li>
              <li>
                Findigoo will not be liable for any damages or losses arising
                from the use of this website.
              </li>
            </ol>
            <br />

            <h3 className="text-xl font-semibold mb-2">
              <u>Governing Law and Jurisdiction</u>
            </h3>
            <ol type="a" className="ml-4 legal-contents-lists">
              <li>
                These terms and conditions are governed by the laws of
                Maharashtra, India, and any disputes shall be subject to the
                exclusive jurisdiction of the courts located in Mumbai,
                Maharashtra.
              </li>
            </ol>
            <br />

            <h3 className="text-xl font-semibold mb-2">
              <u>Modification of Terms</u>
            </h3>
            <ol type="a" className="ml-4 legal-contents-lists">
              <li>
                Findigoo reserves the right to modify or update these terms and
                conditions at any time without prior notice. It is your
                responsibility to review these terms regularly for any changes.
              </li>
            </ol>
            <br />

            <p>
              By using Findigoo’s services and website, you acknowledge that you
              have read, understood, and agreed to these terms and conditions.
              If you do not agree with any part of these terms, you must refrain
              from using our services.
            </p>

            <br />
            <br />
            <br />
          </div>
        </div>
      </div>
    </>
  );
}
