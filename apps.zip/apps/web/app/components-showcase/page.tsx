"use client";

import Footer from "../../components/Sections/Footer/footer";
import NavigationBar from "../../components/Sections/Navigation/navigation-bar";
import HeroSection from "../../components/hero-section";
import Colors from "./colors";

export default function ComponentsShowcasePage() {
  return (
    <div>
      {/* <h1>Components Showcase</h1> */}

      {/* <NavigationBar /> */}
      <HeroSection />
      <br />
      <Colors />
      <br />
      <br />
      {/* <Footer /> */}
    </div>
  );
}
