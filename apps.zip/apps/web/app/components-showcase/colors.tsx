export default function Colors() {
  return (
    <div className="container mx-auto">
      <div className="grid grid-cols-12 h-32">
        <div className="bg-primary1"></div>
        <div className="bg-primary2"></div>
        <div className="bg-secondary1"></div>
        <div className="bg-secondary2"></div>
        <div className="bg-base0"></div>
      </div>
    </div>
  );
}
