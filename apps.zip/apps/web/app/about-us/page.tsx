export default function AboutUsPage() {
  return (
    <>
      <>
        <title>Findigoo | About us</title>
      </>
      <div className="bg-base0 text-primary1">
        <div className="max-w-screen-lg mx-auto px-2">
          <div className="min-h-[50vh]">
            <br />
            <h2 className="text-2xl font-semibold mb-2">About Us</h2>
            <p  className="mb-4">
              Welcome to Findigoo, your gateway to a world of aquatic adventures
              and luxurious getaways! We are thrilled to be your go-to
              destination for booking unforgettable experiences at water parks
              and resorts.
            </p>

            <p >
              At Findigoo, we understand the importance of creating lasting
              memories with family and friends. Our mission is to simplify the
              process of planning and booking your dream waterpark, resort &amp;
              Agrotourism vacations. Whether you&#39;re seeking thrilling water
              slides, relaxing poolside retreats, or a perfect blend of both, we
              have you covered.
            </p>
            <br />
            <h3 className="text-xl font-semibold mb-4 underline">
              WHY CHOOSE US ?
            </h3>
            <ol type="a" className="ml-4 legal-contents-lists">
              <li className="mb-4">
                Diverse Destinations: Explore a curated selection of the finest
                waterparks, resorts &amp; Agrotourisum, each offering a unique
                blend of excitement and relaxation.
              </li>
              <li  className="mb-4">
                Easy Booking: Our user-friendly platform allows you to
                effortlessly browse and book your preferred destinations with
                just a few clicks. We believe in making the booking process as
                seamless as the experiences we offer with the option of
                comparison according to your choice and expectation.
              </li>
              <li  className="mb-4">
                Exclusive Deals: Enjoy access to exclusive deals and special
                packages that will enhance your vacation while keeping your
                budget in mind.
              </li>
              <li  className="mb-4">
                Customer-Centric Approach: Our dedicated team is committed to
                ensuring your satisfaction. From pre-booking inquiries to
                post-vacation feedback, we are here to assist you every step of
                the way.
              </li>
              <li>
                Safety First: We prioritize the safety and well-being of our
                customers. Rest assured that the waterparks and resorts featured
                on our platform adhere to the highest safety standards.
              </li>
            </ol>
            <br />

            <h3 className="text-xl font-semibold mb-4 underline">
              Who We Are ?
            </h3>
            <p  className="mb-4">
              Findigoo is not just a booking platform; it&#39;s a community of
              adventure-seekers and relaxation enthusiasts. Here we give right
              platform for our guest, We are passionate about connecting people
              with incredible experiences, creating bonds, and fostering a love
              for exploration and leisure.
            </p>
            <p>
              Join us on this journey as we continue to expand our offerings,
              introducing you to new and exciting destinations that will
              redefine your understanding of the perfect getaway.
            </p>
            <br />

            <h3 className="text-xl font-semibold mb-4 underline">Our Journy</h3>
            <p>
              Being in 20 th century where every body and everything is
              available online, people are selling everything including
              experiences online. In the race of selling the products and
              experiences we felt that the guests or visitors are getting
              disappointed, as they carry assumptions displayed by various
              online platform and the reality or experience is different, which
              has triggered us to think on providing a platform where visitor
              can see the real image of what they want to experience and they
              can compare the options available online. In addition to this we
              felt that verification of data provided online is true or not is
              must and hence we have decided to create a platform where we will
              ensure correct information and we will enable visitors to choose
              correct option so that there will be no dissatisfaction.
            </p>
            <br />
            <h3 className="text-xl font-semibold mb-4">
              <u>What are you waiting for......</u>
            </h3>
            <p>
              Make your next move now and secure your waterpark adventure
              destination! Don&#39;t wait another moment to dive into a world of
              excitement and laughter with your love ones. Click the button and
              embark on an unforgettable fun journey. Your ultimate destination
              experience awaits. Let the fun begin!
            </p>
            <br />
            <div className="p-8 border-2 rounded-md border-theme-orange">
              <h4 className="text-xl font-semibold mb-4">Contact Us</h4>
              {/* <br /> */}
              <div>
                {/* <p>
                  Phone:{" "}
                  <a className="underline" href="tel:+919594646353">
                    +919594646353
                  </a>
                </p> */}
                <p>
                  <span className="font-bold"> Email:{" "}</span>
                  <a className="underline" href="mailto:support@findigoo.com">
                  support@findigoo.com
                  </a>
                </p>
                <p>
                <span className="font-bold">Address:{" "}</span>
                  309/A, Bhavin Apartment, Chandansar Road, Virar East, Pin Code – 401305.
                </p>
              </div>
            </div>
          </div>
          <br />
          <br />
          <br />
        </div>
      </div>
    </>
  );
}
