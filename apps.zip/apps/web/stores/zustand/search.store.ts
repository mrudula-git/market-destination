import { create } from "zustand";
import type { ListingTypes, Listings } from "database";

type State = {
  query: string;
  listings: Listings[];
  availableFilters?: {
    region?: string[];
    type?: ListingTypes[];
    event?: string[];
  };
  appliedFilters?: {
    region?: string[];
    type?: ListingTypes[];
    event?: string[];
  };
};

type Action = {
  setQuery: (query: State["query"]) => void;
  setListings: (listings: State["listings"]) => void;
  setAvailableFilters: (filters: State["availableFilters"]) => void;
};

export const useSeachStore = create<State & Action>((set) => ({
  query: "",
  listings: [],
  availableFilters: {},
  setQuery: (_query) => {
    set(() => ({ query: _query }));
  },
  setListings: (_listings) => {
    set(() => ({ listings: _listings }));
  },
  setAvailableFilters: (_filters) => {
    set(() => ({
      availableFilters: _filters,
    }));
  },
}));
