import { create } from "zustand";

type State = {
  categories: Record<string, string[]>;
  attributeGroups: Record<string, string[]>;
  attributes: Record<string, { id: string; name: string }[]>;
  checkedValues: Record<string, Record<string, Record<string, boolean>>>;
  removeSelectedItem: (filter: string | undefined) => void;
  removeItemById: (id: string) => void;
};

type Action = {
  setCategories: (categories: State["categories"]) => void;
  setAttributeGroups: (attributeGroups: State["attributeGroups"]) => void;
  setAttributes: (attributes: State["attributes"]) => void;
  setCheckedValue: (
    type: string,
    group: string,
    name: string,
    checked: boolean
  ) => void;
};

export const useCustomStore = create<State & Action>((set) => ({
  categories: {},
  attributeGroups: {},
  attributes: {},
  checkedValues: {},
  setCategories: (categories) => {
    set({ categories });
  },
  setAttributeGroups: (attributeGroups) => {
    set({ attributeGroups });
  },
  setAttributes: (attributes) => {
    set({ attributes });
  },

  setCheckedValue: (type, group, name, checked) => {
    set((state) => {
      const newCheckedValues = { ...state.checkedValues };
      if (!newCheckedValues[type]) {
        newCheckedValues[type] = {};
      }
      if (!newCheckedValues[type]![group]) {
        newCheckedValues[type]![group] = {};
      }
      if (checked) {
        // If checked is true, update the entry
        newCheckedValues[type]![group]![name] = true;
      } else {
        // If checked is false, remove the entry
        if (newCheckedValues[type]![group]) {
          delete newCheckedValues[type]![group]![name];

          // Optionally, clean up empty groups
          if (Object.keys(!newCheckedValues[type]![group]).length === 0) {
            delete newCheckedValues[type]![group];
          }
        }

        // Optionally, clean up empty types
        // if (Object.keys(!newCheckedValues[type]).length === 0) {
        //   delete newCheckedValues[type];
        // }
      }

      return { checkedValues: newCheckedValues };
    });
  },
  removeSelectedItem: (filter) =>
    set((state) => {
      const updatedCheckedValues = { ...state.checkedValues };

      Object.keys(updatedCheckedValues).forEach((type) => {
        const matchingKeys = Object.keys(updatedCheckedValues[type]!).filter(
          (key) => Object.keys(updatedCheckedValues[type]![key]!)[0] === filter
        );

        matchingKeys.forEach((key) => {
          delete updatedCheckedValues[type]![key];
          if (Object.keys(updatedCheckedValues[type]!).length === 0) {
            delete updatedCheckedValues[type];
          }
        });
      });

      return { checkedValues: updatedCheckedValues };
    }),

  removeItemById: (id) =>
    set((state) => {
      const newData = { ...state.checkedValues };

      for (const key in newData) {
        if (Object.hasOwnProperty.call(newData, key)) {
          if (newData[key]![id]) {
            delete newData[key]![id];
          }
        }
      }

      return { checkedValues: newData };
    }),
}));
