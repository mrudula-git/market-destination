import { create } from "zustand";

type State = {
  pageLoading: boolean;
};

type Action = {
  setPageLoading(pageLoading: State["pageLoading"]): void;
};

export const useIndicatorsStore = create<State & Action>((set) => ({
  pageLoading: false,

  setPageLoading: (pageLoading) => {
    set({ pageLoading });
    setTimeout(() => {
      set({ pageLoading: false });
    }, 7000);
  },
}));
