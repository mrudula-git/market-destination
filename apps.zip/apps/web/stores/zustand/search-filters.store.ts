import { create } from "zustand";
import type {
  ListingsAttributes,
  ListingsAttributesGroup,
  ListingsCategories,
} from "database";
import { Attributes } from "react";

type State = {
  categoriesIds: string[];
  categories?: Partial<
    ListingsCategories & { attributes: ListingsAttributes[] }
  >[];

  attributeGroupsIds: string[];
  attributeGroups?: Partial<
    ListingsAttributesGroup & { attributes: ListingsAttributes[] }
  >[];

  attributes: Partial<Attributes>[];

  locationCities: string[];
};

type Action = {
  setCategoriesIds(categoriesIds: State["categoriesIds"]): void;
  setCategories(categories: State["categories"]): void;

  setAttributeGroupsIds(attributeGroupsIds: State["attributeGroupsIds"]): void;
  setAttributeGroups(categories: State["attributeGroups"]): void;

  setAttributes(categories: State["attributes"]): void;

  setLocationCities(locationCities: State["locationCities"]): void;
};

export const useSearchFiltersStore = create<State & Action>((set) => ({
  categoriesIds: [],
  categories: [],

  attributeGroupsIds: [],
  attributeGroups: [],

  attributes: [],

  locationCities: [],

  setCategoriesIds: (categoriesIds) => {
    set({ categoriesIds });
  },

  setCategories: (categories) => {
    set({ categories });
  },

  setAttributeGroupsIds(attributeGroupsIds) {
    set({ attributeGroupsIds });
  },

  setAttributeGroups: (attributeGroups) => {
    set({ attributeGroups });
  },

  setAttributes: (attributes) => {
    set({ attributes });
  },

  setLocationCities: (locationCities) => {
    set({ locationCities });
  },
}));
