import { create } from "zustand";
import type { Reviews } from "database";

type State = {
  reviews: Reviews[];
};

type Action = {
  setReviews: (reviews: State["reviews"]) => void;
};

export const useReviewsStore = create<State & Action>((set) => ({
  reviews: [],
    setReviews: (reviews) => {
    set(() => ({ reviews: reviews }));
  },
}));
