// checkboxStore.js
import { create } from "zustand";

type State = {
  checkedItems: { name: string; checked: boolean }[];
};

type Action = {
  setCheckedItems: (checkedItems: State["checkedItems"]) => void;
  setCheckedItem: (name: string | undefined, checked: boolean) => void;
  getCheckedItem: (name: string) => { checked: boolean };
  removeCheckedItem: (name: string) => void;
};

const useCheckboxStore = create<State & Action>((set) => ({
  checkedItems: [],

  setCheckedItems: (checkedItems) => {
    set((state) => ({
      checkedItems: checkedItems,
    }));
  },

  setCheckedItem: (name: any, checked) => {
    set((state) => {
      const newCheckedItems = [...state.checkedItems];

      const index = newCheckedItems.findIndex((item) => item.name === name);

      if (index !== -1) {
        newCheckedItems[index]!.checked = checked;
      } else {
        newCheckedItems.push({ name, checked });
      }

      return { checkedItems: newCheckedItems };
    });
  },

  getCheckedItem: (name: string) => {
    const foundItem: any = useCheckboxStore
      .getState()
      .checkedItems.find((item) => item.name === name && item.checked);

    return foundItem ? { checked: true } : undefined;
  },

  removeCheckedItem: (name: string) => {
    set((state) => ({
      checkedItems: state.checkedItems.filter((item) => item.name !== name),
    }));
  },
}));

export default useCheckboxStore;
