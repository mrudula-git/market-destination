import { NextFunction, Request, Response } from "express";

declare global {
  namespace Express {
    interface Request {
      allQuery?: any;
      prismaFilters?: {
        where?: any;
        take?: number;
        skip?: number;
      };
    }
  }
}

const RESULTS_PER_PAGE = 10;

export function searchParams(req: Request, res: Response, next: NextFunction) {
  try {
    req.allQuery = { ...req.allQuery, ...req.query };

    const { search, page, take } = req.allQuery;
    req.allQuery.page = +page;

    req.prismaFilters = {};

    // req.prismaFilters.where = {
    //   deleted: { equals: false },
    // };

    if (search) {
      req.prismaFilters.where = {
        name: { contains: search, mode: "insensitive" },
      };
    }

    // if (req.allQuery !== null) {
    //   req.prismaFilters.where = {
    //     name: { contains: search, mode: "insensitive" },
    //   };
    // }

    if (page) {
      req.prismaFilters.skip = (+page - 1) * RESULTS_PER_PAGE;
    }

    req.prismaFilters.take = RESULTS_PER_PAGE;
    if (take === "all") {
      req.prismaFilters.take = undefined;
    }

    next();
  } catch (error) {
    console.log("Error at searchParams", error);
    return res.status(500).json(error);
  }
}

export function excludeDeleted(prismaFilters: any) {
  if (!prismaFilters) {
    prismaFilters = {};
  }

  prismaFilters.where = {
    ...prismaFilters.where,
    deleted: { equals: false },
  };
}
