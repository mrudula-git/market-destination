import { prisma } from "database";
import type { ListingsCategories } from "database";
import Fuse from "fuse.js";

class SearchService {
  categories: ListingsCategories[] | [] = [];
  categoriesFuse: Fuse<ListingsCategories> | undefined;
  constructor() {}

  async loadCategories() {
    try {
      this.categories = await prisma.listing_categories.findMany();
      if (!this.categories) return;
      // console.log(this.categories);
      this.categoriesFuse = new Fuse(this.categories, {
        keys: ["name"],
        includeScore: true,
        // threshold: 0.3,
      });
      console.log("Loaded Categories for SearchService");
    } catch (error) {
      console.log("Failed to Load Categories for SearchService");
    }
  }
  fuzzySearchCategories(category: string) {
    if (!category) return [];
    const results = this.categoriesFuse?.search(category);
    // console.log(results);
    const _results = results
      // ?.filter((r) => r?.score! >= 0.5)
      ?.map((e) => e.item)
      .at(0);
    return _results;
  }
}

export const globalSearchService = new SearchService();

export function initGlobalSearchService() {
  globalSearchService.loadCategories();
}
