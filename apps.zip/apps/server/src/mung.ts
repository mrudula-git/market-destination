import mung from "express-mung";

export const rewriteBody = mung.json((body, request, response) => {
  // console.log("mung logs", {});
});
