import e, { Request, Response } from "express";
import cookieParser from "cookie-parser";
import cors from "cors";
import { apiRouter } from "./controllers";
// import ingest from "ingest";
// import { ingestRouter } from "./controllers/ingest";
import { host, port } from "./config";
import { rewriteBody } from "./mung";

const app = e();

app.use(cookieParser());
app.use(e.urlencoded({ extended: true }));
app.use(e.json());
app.use(
  cors({
    origin: [
      /http(|s):\/\/(|www\.)localhost:(3000|3001)$/,
      /http(|s):\/\/(|www\.)127.0.0.1:(3000|3001)$/,
      /http(|s):\/\/(|www\.)192.168.29.217:(3000|3001)$/,
      /http(|s):\/\/findigoo.com/,
      /http(|s):\/\/admin.findigoo.com/,
      /http(|s):\/\/stg.findigoo.com/,
      /http(|s):\/\/stg-admin.findigoo.com/,
      /http(|s):\/\/13.201.203.188:(3000|3001)$/,
      /http(|s):\/\/13.200.75.211:(3000|3001)$/,
      "http://findigoo.com",
      "https://findigoo.com",
      "http://admin.findigoo.com",
      "https://admin.findigoo.com",
      "http://stg.findigoo.com",
      "https://stg.findigoo.com",
      "http://stg-admin.findigoo.com",
      "https://stg-admin.findigoo.com",
      // /http(|s):\/\/(|www\.)localhost:[0-9]{4,}$/,
      "*",
    ],
    credentials: true,
  })
);
// app.use(rewriteBody);

app.use("/api", apiRouter);

// app.use("/ingest", ingest.single("file"), ingestRouter);

app.get("/*", async (req: Request, res: Response) => {
  return res.sendStatus(404);
});

app.listen(port, () => {
  console.log(`Express listening on ${host}:${port}`);
});
