import { Router } from "express";
import { prisma } from "database";

export const mediaRouter = Router();
interface CustomMediaCreateInput {
  url: string;
  thumbUrl: string;
  cdnType?: string;
  cdnAuthKey?: string;
  listingsId?: string;
  reviewsId?: string;
  ikFileId?:string;
}

mediaRouter.post("/", async (req, res) => {
  // console.log(req.body,"hi");
  
  try {
    const {
      url,
      thumbUrl,
      cdnType,
      cdnAuthKey,
      listingsId,
      reviewsId,
      ikFileId
    }: CustomMediaCreateInput = req.body;

    // Validate required fields
    if (!url || !thumbUrl ) {
      return res.status(400).json({ error: "URL and thumbUrl are required" });
    }

    // Create a new media entry in the database
    const mediaEntry = await prisma.media.create({
      data: {
        url,
        thumbUrl,
        cdnType,
        ikFileId,
        cdnAuthKey,
        listings: { connect: { id: listingsId } }, 
        // reviews: { connect: { id: reviewsId || undefined } },
      },
    });

    return res.status(201).json({ mediaEntry });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ error: "Internal Server Error" });
  }
});

mediaRouter.delete('/:id',async (req , res)=>{
  try{
       
        const mediaId = req.params.id;
  
        const media = await prisma.media.findUnique({
          where: { id: mediaId },
        });
    
        if (!media) {
          return res.status(404).json({ message: 'Media not found' });
        }
        await prisma.media.delete({
          where: { id: mediaId },
        });
        console.log("Media deleted successfully");
        return res.json({ message: 'Media deleted successfully' });
  }
  catch(error){
    console.error('Error deleting media:', error);
    return res.status(500).json({ message: 'Internal Server Error' });
  }
})