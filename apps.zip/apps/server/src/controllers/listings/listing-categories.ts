import { prisma } from "database";
import { Router } from "express";

export const listingCategoriesRouter = Router();

listingCategoriesRouter.put("/", async (req, res) => {
  try {
    const { body, params, allParams, query } = req;
    const { categories } = body;
    console.log(categories,allParams);
    
    // const listing = await prisma.listings.update({
    //   where: { id: +allParams.id },
    //   data: {
    //     attributes,
    //   },
    // });
    // return res.status(200).json({ listing });
    res.send(null)
  } catch (error) {
    console.log("listingAttributesRouter.put", error);
    return res.status(500).json(error);
  }
});
