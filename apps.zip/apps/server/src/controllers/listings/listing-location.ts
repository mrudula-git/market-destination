import { prisma } from "database";
import { Router } from "express";
import { ObjectId } from "mongodb";

export const listingLocationRouter = Router();

listingLocationRouter.patch("/", async (req, res) => {
  try {
    const { body, allParams } = req;
    const { id: listingId } = allParams;
    const { id, ...rest } = body;

    console.log(id, rest, listingId);
    const location = await prisma.locations.upsert({
      where: { id: id || new ObjectId().toString() },
      update: {
        ...rest,
      },
      create: {
        ...rest,
        listings: {
          connect: [{ id: listingId }],
        },
      },
    });

    return res.status(200).json({ location });
  } catch (error) {
    console.log("locationRouter.patch", error);
    return res.status(500).json(error);
  }
});
