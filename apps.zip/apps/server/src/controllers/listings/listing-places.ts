import { prisma } from "database";
import { Router } from "express";

export const listingPlacesRouter = Router();

listingPlacesRouter.post("/", async (req, res) => {
  try {
    const { body, allParams, params } = req;
    const { location, ...rest } = body;
    const { id: listingsId } = allParams;

    let { lat, lng } = location;
    location.lat = isNaN(parseFloat(lat)) ? undefined : lat;
    location.lng = isNaN(parseFloat(lng)) ? undefined : lng;

    const place = await prisma.places.create({
      data: {
        ...rest,
        location: {
          create: {
            ...location,
          },
        },
        listings: {
          connect: {
            id: listingsId,
          },
        },
      },
    });

    return res.status(200).json({ place });
  } catch (error) {
    console.log("listingPlacesRouter.post", error);
    return res.status(500).json(error);
  }
});

listingPlacesRouter.patch("/:id", async (req, res) => {
  try {
    const { body, allParams, params } = req;
    const { id, location, ...rest } = body;
    const { id: locationsId, ...locationRest } = location;

    delete rest.listingsId;
    delete rest.locationsId;

    const place = await prisma.places.update({
      where: { id: id },
      data: {
        ...rest,
      },
    });

    const _location = await prisma.locations.update({
      where: { id: locationsId },
      data: { ...locationRest },
    });

    return res.status(200).json({ place: { ...place, location: _location } });
  } catch (error) {
    console.log("listingPlacesRouter.patch", error);
    return res.status(500).json(error);
  }
});
