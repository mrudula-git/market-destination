import { prisma } from "database";
import { Router } from "express";
import { ACL, forwardParams, searchParams } from "../../middlewares";
import { filterAttributesRouter } from "./filter-attributes";
import { listingAttributesRouter } from "./listing-attributes";
import { listingCategoriesRouter } from "./listing-categories";
import { listingPackagesRouter } from "./listing-packages";
import { listingLocationRouter } from "./listing-location";
import { listingPlacesRouter } from "./listing-places";
import { listingBadgesRouter } from "./listing-badges";
import { excludeDeleted } from "../../middlewares/search-params";

export const listingsRouter = Router({});

listingsRouter.use("/filter-attributes", filterAttributesRouter);

listingsRouter.get("/", searchParams, async (req, res) => {
  try {
    const { allQuery, prismaFilters } = req;

    excludeDeleted(prismaFilters);

    const count = await prisma.listings.count({ where: prismaFilters?.where });

    const listings = await prisma.listings.findMany({
      ...prismaFilters,
      include: {
        categories: {
          select: { id: true, name: true },
        },
      },
    });

    return res.status(200).json({ listings, count });
  } catch (error) {
    console.error("listingsRouter.get", error);
    res.status(500).json({ error: "Internal Server Error" });
  }
});

listingsRouter.use("/:id/attributes", forwardParams, listingAttributesRouter);
listingsRouter.use("/:id/categories", forwardParams, listingCategoriesRouter);
listingsRouter.use("/:id/packages", forwardParams, listingPackagesRouter);
listingsRouter.use("/:id/location", forwardParams, listingLocationRouter);
listingsRouter.use("/:id/places", forwardParams, listingPlacesRouter);
listingsRouter.use("/:id/badges", forwardParams, listingBadgesRouter);

listingsRouter.get("/:id", async (req, res) => {
  try {
    const { body, params, query } = req;
    let listing = await prisma.listings.findFirst({
      where: { id: params.id },
      include: {
        contacts: true,
        photos: true,
        categories: {
          include: { attributes: true },
        },
        attributeGroups: {
          include: { attributes: true },
        },
        location: true,
        places: {
          include: { location: true },
        },
        // TODO: Where is packages... not connected?
        badges: true,
        packages: {
          include: { price: true },
        },
        // reviews: {
        //   include: { details: true, reviewer: true },
        // },
      },
    });
    res.status(200).json({ listing });
  } catch (error) {
    console.log("listingsRouter.get", error);
    return res.status(500).json(error);
  }
});

// TODO: Need to use a DTO things for these cases
type Category = {
  id: number;
  name?: string;
};

listingsRouter.post("/", async (req, res) => {
  try {
    let { body, params, query } = req;
    let { contacts, categories, attributeGroups, ...rest } = body;

    const listing = await prisma.listings.create({
      data: {
        ...rest,
        categories: {
          connect: categories?.map((el: Category) => ({ id: el.id })) ?? [],
        },
        attributeGroups: {
          connect:
            attributeGroups?.map((el: Category) => ({ id: el.id })) ?? [],
        },
        contacts: {
          create: {
            ...contacts,
          },
        },
      },
    });
    return res.status(200).json({ listing });
  } catch (error) {
    console.log("listingsRouter.post", error);
    res.status(500).json(error);
  }
});

listingsRouter.delete("/:id", async (req, res) => {
  try {
    const { body, params, query } = req;
    const { id } = params;
    const listing = await prisma.listings.delete({
      where: { id: id },
    });
    return res.status(200).json({ listing });
  } catch (error) {
    console.log("listingsRouter.delete", error);
    return res.status(500).json(error);
  }
});

listingsRouter.patch("/:id", async (req, res) => {
  try {
    const { body, params, query } = req;
    const {
      id,
      types,
      categoriesId,
      categories,
      attributeGroupsId,
      attributeGroups,
      badges,
      uniques,
      locationsId,
      location,
      places,
      packages,
      reviews,
      contactsId,
      contacts,
      ...rest
    } = body;
    const { id: contacts_Id, ...contactsRest } = contacts;
    // const { id: locations_Id, ...locationRest } = location;
    delete location?.id;
    delete rest.photos;

    const listing = await prisma.listings.update({
      where: { id: id },
      data: {
        ...rest,
        location: {
          update: {
            data: { ...location },
          },
        },
        contacts: {
          update: {
            data: { ...contactsRest },
          },
        },
        categories: {
          set: categories?.map((el: Category) => ({ id: el.id })) ?? [],
        },
        attributeGroups: {
          set: attributeGroups?.map((el: Category) => ({ id: el.id })) ?? [],
        },
      },
    });

    return res.status(200).json({ listing });
    // return res.status(200).json({});
  } catch (error) {
    console.log("listingsRouter.patch", error);
    return res.status(500).json(error);
  }
});

listingsRouter.get("/", async (req, res) => {
  try {
    const search = req.query.search;
    let filter = {};
    if (search) {
      // if the search parameter is present, construct a filter object with a Prisma query
      filter = {
        name: { contains: search, mode: "insensitive" },
      };
    }
    const listings = await prisma.listings.findMany({
      where: filter,
    });
    res.status(200).json(listings);
  } catch (error) {
    res.status(500).json({ error });
  }
});

// listingsRouter.get("/", async (req, res) => {
//   try {
//     // const acl = new ACL(req.xauth.acl_roles);
//     //   .perform("res_listings", 1)
//     //   .validate();
//     // if (!acl["res_listings"].can) return res.sendStatus(403);

//     let listings = await prisma.listings.findMany({
//       include: {
//         types: {
//           select: {
//             id: true,
//             name: true,
//           },
//         },
//         categories: {
//           select: { name: true },
//         },
//       },
//     });

//     res.status(200).json({ listings });
//   } catch (error) {
//     console.log(error);
//     res.status(500).json(error);
//   }
// });

// TODO: Later Implement on While frontend, for now disabled
// listingsRouter.get("/listing_name/:listing_name", async (req, res) => {
//   try {
//     const { body, params, query } = req;

//     let listing = await prisma.listings.findFirst({
//       where: { listing_name: params.listing_name },
//       include: {
//         types: {
//           select: {
//             id: true,
//             name: true,
//           },
//         },
//       },
//     });
//     res.status(200).json({ listing });
//   } catch (error) {
//     console.log(error);
//     return res.status(500).json(error);
//   }
// });

listingsRouter.patch("/:id", async (req, res) => {
  try {
    const { body, params, query } = req;

    const acl = new ACL(req.xauth.acl_roles)
      .perform("res_listings", 3)
      .validate();
    if (!acl["res_listings"].can) return res.sendStatus(403);

    let listing = await prisma.listings.findFirst({
      where: { id: params.id },
    });

    let _users = await prisma.users.findMany();
    const users = _users.map((u) => ({
      ...u,
      // acl_roles: acl_roles.find((el) => el.id === u.acl_roleId),
    }));

    res.status(200).json({ listing, users: _users });
  } catch (error) {
    console.log(error);
    return res.status(500).json(error);
  }
});

// ACL = Access Control Layer (actually List)
/**
{ resource: score }[] Array of Mapping. Where each Item is resource to scores
Let's see
Scores are Defined for each performace/action
read = 1
create = 2
update = 3
delete = 4
{ user: 2 } can not perform update, delete
 */

/**
Similarly each action must need some minimum(or, sufficient) score to perform
const can = ACL(roles)
              .perform(users, 3)
              .perform(listings, 3)
              .perform(addresses, 3) 
              ... so forth you can chain
can = { can: true, users: {can: false, message: "Forbidden"}, listings: {can: true}, addresses: {can: true} }

but with this approach comes a problem of 
Defining Scores of Actions might get harder over time than we think.
 */
