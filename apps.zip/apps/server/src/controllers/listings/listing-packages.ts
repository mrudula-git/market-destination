import { prisma } from "database";
import { Router } from "express";

export const listingPackagesRouter = Router();

listingPackagesRouter.post("/", async (req, res) => {
  try {
    const { body, allParams } = req;
    const { price, ...rest } = body;
    const { id: listingId } = allParams;

    // console.log(body);

    const _package = await prisma.packages.create({
      data: {
        ...rest,
        price: {
          create: {
            ...price,
          },
        },
        listings: {
          connect: { id: listingId },
        },
      },
    });

    res.status(201).json({ package: _package });
    // res.status(201).json({ package: null });
  } catch (error) {
    console.log("listingPackagesRouter.post", error);
    return res.status(500).json(error);
  }
});

listingPackagesRouter.patch("/:id", async (req, res) => {
  try {
    const { body, allParams, params } = req;
    const { id, price, ...rest } = body;
    const { id: priceId, ...priceRest } = price;

    delete rest.listingsId;
    delete rest.priceId;

    const _package = await prisma.packages.update({
      where: {
        id,
      },
      data: {
        ...rest,
        price: {
          update: {
            data: {
              ...priceRest,
            },
          },
        },
      },
    });

    res.status(200).json({ package: _package });
    // res.status(200).json({ package: null });
  } catch (error) {
    console.log("listingPackagesRouter.patch", error);
    return res.status(500).json(error);
  }
});
