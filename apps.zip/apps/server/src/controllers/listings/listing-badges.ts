import { prisma } from "database";
import { Router } from "express";

export const listingBadgesRouter = Router();

listingBadgesRouter.post("/", async (req, res) => {
  try {
    console.log(req.body);

    const { body, params, allParams } = req;
    const { name } = body;

    const createdBadge = await prisma.badges.create({
      data: {
        name: name, // Assuming 'badges' directly represents the name of the badge
        listings: {
          connect: {
            id: allParams.id,
          },
        },
      },
    });
    console.log(createdBadge);

    return res.status(200).json({ badges: createdBadge });
  } catch (error) {
    console.log("Error creating badges:", error);
    return res.status(500).json({ error: "Internal server error" });
  }
});

listingBadgesRouter.put("/:badgeId", async (req, res) => {
  try {
    const { body, params, allParams } = req;
    const { badges } = body;

    const updatedListing = await prisma.listings.update({
      where: {
        id: allParams.id,
        badges: {
          some: {
            id: params.badgeId,
          },
        },
      },
      data: {
        badges: {
          update: {
            where: { id: params.badgeId },
            data: {
              name: badges,
            },
          },
        },
      },
      include: {
        badges: true,
      },
    });

    return res.status(200).json({ updatedListing });
  } catch (error) {
    console.log("Error updating badge from listing:", error);
    return res.status(500).json({ error: "Internal server error" });
  }
});
