import { prisma } from "database";
import { Router } from "express";

export const filterAttributesRouter = Router();

filterAttributesRouter.post("/", async (req, res) => {
  console.log("filter");
  const { body } = req;
  console.log(body);
  const result = await prisma.listings.findMany({
    where: {
      attributes: {},
    },
  });

  return res.status(200).json({ body, result });
});
