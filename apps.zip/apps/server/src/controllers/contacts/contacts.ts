import { error } from "console";
import { prisma } from "database";
import { Router } from "express";
import { searchParams } from "../../middlewares";

export const contactsRoutes = Router();

contactsRoutes.get("/",searchParams, async (req, res) => {
  try {
    const { query } = req;
    const { search } = query;
    let filter = { ...req.prismaFilters };
    if (search) {
      filter = {
        where: [
          { companyName: { contains: search, mode: "insensitive" } },
          { primaryEmail: { contains: search, mode: "insensitive" } },
          { primaryPhoneNumber: { contains: search, mode: "insensitive" } },
          { secondaryEmail: { contains: search, mode: "insensitive" } },
          { secondaryPhoneNumber: { contains: search, mode: "insensitive" } },
          { country: { contains: search, mode: "insensitive" } },
          { city: { contains: search, mode: "insensitive" } },
          { district: { contains: search, mode: "insensitive" } },
          { state: { contains: search, mode: "insensitive" } },
          { pinCode: { contains: search, mode: "insensitive" } },
          { createdAt: { contains: search, mode: "insensitive" } },
          { updatedAt: { contains: search, mode: "insensitive" } },
        ],
      };
    }
    const { pagination,currentPage } = req.allQuery;  
    const total = await prisma.admin_users.count({  where: filter?.where, });
    const totalPages = Math.ceil(total / pagination.take);
    const contacts = await prisma.contacts.findMany({
      where:
      filter,
      ...pagination,
    });
    res.status(200).json({ contacts,totalPages,currentPage, count:total});
  } catch (error) {
    res.status(500).json(error);
  }
});

contactsRoutes.get("/:id", async (req, res) => {
  try {
    const { id } = req.params;
    const contact = await prisma.contacts.findUnique({
      where: {
        id: id,
      },
    });
    res.status(200).json(contact);
  } catch (error) {
    res.status(500).json(error);
  }
});

contactsRoutes.post("/", async (req, res) => {
  try {
    console.log(req.body);
    const contact = await prisma.contacts.create({
      data: req.body,
    });
    res.status(200).json(contact);
  } catch (error) {
    res.status(500).json(error);
  }
});

contactsRoutes.patch("/:id", async (req, res) => {
  try {
    const { id } = req.params;
    const contact = await prisma.contacts.update({
      where: {
        id: id,
      },
      data: req.body,
    });
    res.status(200).json(contact);
  } catch (error) {
    res.status(500).json(error);
  }
});

contactsRoutes.delete("/:id", async (req, res) => {
  try {
    const { id } = req.params;
    const contact = await prisma.contacts.delete({
      where: {
        id: id,
      },
    });

    res
      .status(200)
      .send({ message: "contact deleted sucessfully " + contact.id });
  } catch (error) {
    res.status(500).json(error);
  }
});
