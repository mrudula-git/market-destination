import { Router } from "express";

export const ingestRouter = Router();

const s3_endpoint = process.env.R2_ENDPOINT;
const public_endpoint = process.env.R2_PUBLIC_ENDPOINT;

const origin_endpoint = process.env.SPACES_ORIGIN_ENDPOINT;
const cdn_endpoint = process.env.SPACES_CDN_ENDPOINT;

ingestRouter.put("/", async (req, res) => {
  try {
    const file: Express.MulterS3.File = {
      ...req.file,
    } as Express.MulterS3.File;

    // Cloudflare R2 fix
    // let publicUrl = "";
    // if (file?.location) {
    //   publicUrl += file.location;
    //   publicUrl = publicUrl.replace(
    //     s3_endpoint as string,
    //     public_endpoint as string
    //   );
    // }

    // DigitalOcean Spaces fix
    let publicUrl = "";
    if (file?.location) {
      publicUrl += file.location;
      publicUrl = publicUrl.replace(
        origin_endpoint as string,
        cdn_endpoint as string
      );
    }

    res.status(200).json({ file, location: publicUrl });
  } catch (error) {
    console.log("ingestRouter.put", error);
    return res.status(500).json(error);
  }
});
