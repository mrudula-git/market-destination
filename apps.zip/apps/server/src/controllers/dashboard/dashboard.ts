import { prisma } from "database";
import { Router } from "express";
import { searchParams } from "../../middlewares";
export const dashboardRoutes = Router();

dashboardRoutes.get("/", searchParams, async (req, res) => {
    try {
      const { allQuery, prismaFilters } = req;
  
      const listingsCount = await prisma.listings.count({
        where: prismaFilters?.where,
      });

      const reviewsCount = await prisma.reviews.count({
        where: prismaFilters?.where,
      });
      res.status(200).json({ listingsCount,reviewsCount });
    } catch (error) {
      console.error("Error fetching listings and reviews count", error);
      res.status(500).json({ error: "Internal Server Error" });
    }
  });