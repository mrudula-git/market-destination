import { Router } from "express";
import { mediaRouter } from "./media/media";
import { meRouter } from "./me";
import { decodeXAuthHeaders } from "../middlewares";
import { listingsRouter } from "./listings/listings";
import { categoriesRouter } from "./categories/categories";
import { adminUsersRoutes } from "./admin/admin";
import { contactsRoutes } from "./contacts/contacts";
import { reviewsRouter } from "./reviews/reviews";
import { webRouter } from "./web";
import { imagekitRouter } from "./imagekit/imagekit";
import { dashboardRoutes } from "./dashboard/dashboard";
import { feedbackRouter } from "./feedback/feedback";
export const apiRouter = Router();

apiRouter.get("", (req, res) => {
  return res.sendStatus(200);
});

apiRouter.use("/dashboard", dashboardRoutes);
apiRouter.use("/me", meRouter);

apiRouter.use("/imagekit", imagekitRouter);
apiRouter.use("/media", mediaRouter);

apiRouter.use("/adminusers", adminUsersRoutes);
apiRouter.use("/contacts", contactsRoutes);

apiRouter.use("/listings", listingsRouter);

apiRouter.use("/reviews", reviewsRouter);

apiRouter.use("/categories", categoriesRouter);
// apiRouter.use("/categories/attributes", attributesRouter);

// apiRouter.use("/listings", decodeXAuthHeaders, listingsRouter);
// apiRouter.use("/categories/attributes/groups", attributeGroupsRouter);

apiRouter.use("/web", webRouter);

apiRouter.use("/feedback", feedbackRouter);

// apiRouter.use("/user", authRoutes);
