import { Router } from "express";
import { prisma } from "database";
import { searchParams } from "../../middlewares";

export const reviewsRouter = Router();

reviewsRouter.get("/", searchParams, async (req, res) => {
  try {
    const { allQuery, prismaFilters } = req;

    const count = await prisma.reviews.count({ where: prismaFilters?.where });

    const reviews = await prisma.reviews.findMany({
      ...prismaFilters,
      include: {
        details: true,
        reviewer: true,
      },
    });
    return res.status(200).json({ reviews, count });
  } catch (error) {
    console.error("reviewsRouter.get", error);
    return res.status(500).json({ error: "Internal Server Error" });
  }
});

reviewsRouter.get("/:id", async (req, res) => {
  try {
    const { params } = req;
    const review = await prisma.reviews.findUnique({
      where: {
        id: params.id,
      },
      include: {
        details: true,
        reviewer: true,
      },
    });
    return res.json({ review });
  } catch (error) {
    return res.status(500).json(error);
  }
});

reviewsRouter.post("/", async (req, res) => {
  const { body, params } = req;

  const { reviewerId, listingsId, details, photos, ...rest } = body;

  try {
    const review = await prisma.reviews.create({
      data: {
        ...rest,
        details: {
          create: {
            ...details,
          },
        },
        reviewer: {
          connect: { id: reviewerId },
        },
        listings: {
          connect: { id: listingsId },
        },
        photos: {
          connect: photos.map((id: string) => ({ id })),
        },
      },
    });

    return res.status(200).json({ review });
  } catch (error) {
    console.log("reviewsRouter.post", error);
    return res.status(500).json(error);
  }
});

reviewsRouter.patch("/:id", async (req, res) => {
  try {
    const { body, allParams, params } = req;
    const { details, ...rest } = body;

    const { id } = params;

    const review = await prisma.reviews.update({
      where: { id: id },
      data: {
        ...rest,
        details: {
          update: {
            ...details,
          },
        },
      },
    });
    return res.json(review);
  } catch (error) {
    return res.status(500).json(error);
  }
});

reviewsRouter.delete("/:id", async (req, res) => {
  try {
    const { params } = req;
    const review = await prisma.reviews.delete({
      where: {
        id: params.id,
      },
      include: {
        details: true,
      },
    });

    await prisma.review_details.delete({
      where: {
        id: review.details.id,
      },
    });

    res.status(200).json(review);
  } catch (error) {
    return res.status(500).json(error);
  }
});
