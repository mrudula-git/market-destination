import nodemailer from 'nodemailer';

// Create a nodemailer transporter using your email service credentials
const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: 'campaign302@gmail.com',
    pass: 'qlbaexnyagogyabt',
  },
});

// Function to send OTP via email
const sendOtpViaEmail = async (email: string, otp: string): Promise<void> => {
  // Email content
  const mailOptions = {
    from: 'pooja.shivarkar@neurosparkworks.com',
    to: email,
    subject: 'OTP Verification',
    text: `Your OTP for verification is: ${otp}`,
  };

  try {
    // Send email
    const info = await transporter.sendMail(mailOptions);
    console.log(`Email sent: ${info.response}`);
  } catch (error) {
    console.error(`Error sending email: ${error}`);
    throw new Error('Failed to send OTP via email');
  }
};

// Example usage
const email = '';
const otp = '123456'; // Replace with the actual OTPpooja.shivarkar@neurosparkworks.com

sendOtpViaEmail(email, otp)
  .then(() => {
    console.log(`OTP sent to ${email}`);
  })
  .catch((error) => {
    console.error(`Failed to send OTP via email: ${error.message}`);
  });

  export default sendOtpViaEmail;