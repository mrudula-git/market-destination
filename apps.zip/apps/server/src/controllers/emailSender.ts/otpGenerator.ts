// otp-generator.ts

interface OtpOptions {
    digits: boolean;
    alphabets: boolean;
    upperCase: boolean;
    specialChars: boolean;
    // Add other options as needed
  }
  
  const otpGenerator = {
    generate: (length: number, options: OtpOptions): string => {
      const chars = options.digits ? '0123456789' : '';
      // Add other character sets based on options (alphabets, upperCase, specialChars, etc.)
  
      let otp = '';
      for (let i = 0; i < length; i++) {
        otp += chars.charAt(Math.floor(Math.random() * chars.length));
      }
  
      return otp;
    },
  };
  
  export default otpGenerator;
  