import { prisma } from "database";
import { Router } from "express";
import { attributesRouter } from "./attributes";
import { attributeGroupsRouter } from "./attribute-groups";
import { searchParams } from "../../middlewares";
import { globalSearchService } from "../../services/search.services";

export const categoriesRouter = Router();

categoriesRouter.use("/attributes", attributesRouter);
categoriesRouter.use("/attribute-groups", attributeGroupsRouter);

categoriesRouter.get("/", searchParams, async (req, res) => {
  try {
    const { allQuery, prismaFilters } = req;

    const count = await prisma.listing_categories.count({
      where: prismaFilters?.where,
    });

    const categories = await prisma.listing_categories.findMany({
      ...prismaFilters,
      include: {
        attributes: {
          include: {
            // attributeGroup: { select: { id: true } },
          },
        },
      },
    });

    // external service
    await globalSearchService.loadCategories();

    return res.status(200).json({ categories, count });
  } catch (error) {
    console.error("categoriesRouter.get", error);
    return res.status(500).json({ error: "Internal Server Error" });
  }
});

categoriesRouter.post("/", async (req, res) => {
  try {
    let { body, params, query } = req;

    // console.log(body);

    const { attributes, ...data } = body;

    const category = await prisma.listing_categories.create({
      data: {
        ...data,
        attributes: {
          connect: attributes?.map((el: Attribute) => ({ id: el.id })) ?? [],
        },
      },
      include: {
        attributes: {
          select: { id: true, name: true },
        },
      },
    });

    return res.status(200).json({ category });
    // return res.status(200).json({});
  } catch (error) {
    console.log("categoriesRouter.get", error);
    res.status(500).json(error);
  }
});

categoriesRouter.get("/:id", async (req, res) => {
  try {
    const { params, query } = req;
    const category = await prisma.listing_categories.findFirst({
      where: {
        id: params.id,
      },
      include: {
        attributes: {
          select: { id: true, name: true },
        },
      },
    });
    res.status(200).json({ category });
  } catch (error) {
    console.log("categoriesRouter.get", error);
    res.status(500).json(error);
  }
});

type Attribute = {
  id: number;
  name?: string;
};

categoriesRouter.patch("/:id", async (req, res) => {
  try {
    let { body, params, query } = req;
    // const { id } = params;
    const { attributes, id, ...data } = body;

    const category = await prisma.listing_categories.update({
      where: { id: id },
      data: {
        ...data,
        attributes: {
          set: attributes.map((el: Attribute) => ({ id: el.id })),
        },
      },
      include: {
        attributes: {
          select: { id: true, name: true },
        },
      },
    });

    // console.log(category);
    return res.status(200).json({ category });
  } catch (error) {
    console.log("categoriesRouter.get", error);
    res.status(500).json(error);
  }
});
