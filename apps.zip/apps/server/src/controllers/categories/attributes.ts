import { prisma } from "database";
import { Router } from "express";
import { searchParams } from "../../middlewares";

export const attributesRouter = Router();

attributesRouter.get("/", searchParams, async (req, res) => {
  try {
    const { prismaFilters } = req;

    const count = await prisma.listing_attributes.count({
      where: prismaFilters?.where,
    });

    const attributes = await prisma.listing_attributes.findMany({
      ...prismaFilters,
      include: {
        // attributeGroup: {
        //   select: {
        //     id: true,
        //     name: true,
        //   },
        // },
        // categories: {
        //   select: { id: true },
        // },
      },
    });
    res.status(200).json({ attributes, count });
  } catch (error) {
    console.log("attributesRouter.get", error);
    res.status(500).json(error);
  }
});

attributesRouter.post("/", async (req, res) => {
  try {
    const { body } = req;
    const attributes = await prisma.listing_attributes.create({
      data: {
        ...body,
      },
    });
    return res.status(200).json({ attributes });
    // return res.status(200).json({});
  } catch (error) {
    console.log("attributesRouter.get", error);
    res.status(500).json(error);
  }
});

// Assume 'attributesRouter' is an instance of Express Router

attributesRouter.patch("/:id", async (req, res) => {
  try {
    const { id } = req.params;
    const { body } = req;

    const updatedAttribute = await prisma.listing_attributes.update({
      where: {
        id: id,
      },
      data: {
        ...body,
      },
    });

    return res.status(200).json({ updatedAttribute });
  } catch (error) {
    return res.status(500).json({ error: "Failed to update attribute." });
  }
});
