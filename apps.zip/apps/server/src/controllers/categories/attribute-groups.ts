import { prisma } from "database";
import { Router } from "express";

export const attributeGroupsRouter = Router();

attributeGroupsRouter.get("/", async (req, res) => {
  try {
    const attributeGroups = await prisma.listing_attribute_groups.findMany({
      include: {
        attributes: {
          include: {
            //
          },
        },
      },
    });
    res.status(200).json({ attributeGroups });
  } catch (error) {
    console.log("attributeGroupsRouter.get", error);
    res.status(500).json(error);
  }
});

type Attribute = {
  id: number;
  name?: string;
};

attributeGroupsRouter.post("/", async (req, res) => {
  try {
    const { body } = req;
    console.log(body);

    const { attributes, ...data } = body;

    const attributeGroup = await prisma.listing_attribute_groups.create({
      data: {
        ...data,
        attributes: {
          connect: attributes?.map((el: Attribute) => ({ id: el.id })) ?? [],
        },
      },
    });

    // const attributeGroups = await prisma.listing_attribute_groups.findMany({});
    // res.status(200).json({ attributeGroups });
    return res.status(200).json({ attributeGroup });
  } catch (error) {
    console.log("attributeGroupsRouter.post", error);
    res.status(500).json(error);
  }
});

attributeGroupsRouter.patch("/:id", async (req, res) => {
  try {
    const { body, params } = req;
    console.log(body);
    const { id, attributes, ...data } = body;

    const attributeGroup = await prisma.listing_attribute_groups.update({
      where: { id },
      data: {
        ...data,
        attributes: {
          set: attributes?.map((el: Attribute) => ({ id: el.id })) ?? [],
        },
      },
    });

    return res.status(200).json({ attributeGroup });
  } catch (error) {
    console.log("attributeGroupsRouter.post", error);
    res.status(500).json(error);
  }
});
