import { ObjectId } from "mongodb";
import { globalSearchService } from "../../services/search.services";

const REVIEW_AVERAGE_VIEW = "REVIEW_AVERAGE_VIEW";

export function queryStage(query?: string) {
  const pipeline: any = [];
  if (!query) return pipeline;
  // pipeline.push({
  //   $match: {
  //     $text: { $search: query },
  //   },
  // });
  pipeline.push({
    $match: {
      name: {
        $regex: query,
        $options: "i",
      },
    },
  });
  return pipeline;
}

export function contacsStages(filters?: string[]) {
  const pipeline: any = [
    {
      $lookup: {
        from: "contacts",
        localField: "contactsId",
        foreignField: "_id",
        as: "contacts",
      },
    },
    {
      $unwind: {
        path: "$contacts",
      },
    },
  ];

  if (filters) {
    pipeline.push({
      $match: {
        $or: [
          {
            "contacts.city": {
              $regex: filters.join("|"),
              $options: "i",
            },
          },
          {
            "contacts.state": {
              $regex: filters.join("|"),
              $options: "i",
            },
          },
        ],
      },
    });
  }

  return pipeline;
}

export function categoryStages(category?: string) {
  const pipeline: any = [];
  if (category) {
    const result: any = globalSearchService.fuzzySearchCategories(category);
    if (!result) return pipeline;
    pipeline.push({
      $match: {
        categoriesId: { $in: [new ObjectId(result?.id)] },
      },
    });
  }

  return pipeline;
}

export function reviewsStages(review?: string | number) {
  let pipeline: any = [
    {
      $lookup: {
        from: REVIEW_AVERAGE_VIEW,
        localField: "_id",
        foreignField: "_id",
        as: "reviews",
      },
    },
    {
      $unwind: {
        path: "$reviews",
        preserveNullAndEmptyArrays: true,
      },
    },
  ];

  if (review) {
    pipeline.push({
      $match: {
        "reviews.avgRatingValue": { $gte: +review },
      },
    });
  }

  return pipeline;
}

export function attributesStages(
  categoryAttributes?: any,
  attributeGroupAttributes?: any
) {
  const attributesFilter = [...categoryAttributes, ...attributeGroupAttributes];

  const pipeline: any = [];
  if (!attributesFilter?.length) return pipeline;

  pipeline.push({
    $match: {
      $and: attributesFilter.reduce((map, obj) => {
        const key = Object.keys(obj)[0];
        const value = obj[key];
        map.push({
          "attributes.id": key,
          "attributes.value": { $eq: value },
        });
        return map;
      }, []),
    },
  });

  return pipeline;
}

export function photosStages() {
  const pipeline: any = [
    {
      $lookup: {
        from: "media",
        localField: "_id",
        foreignField: "listingsId",
        as: "photos",
      },
    },
  ];

  return pipeline;
}

export function facetStage({
  skip = 0,
  limit = 12,
}: {
  skip: number;
  limit: number;
}) {
  return [
    {
      $facet: {
        count: [{ $count: "total" }],
        listings: [{ $skip: skip }, { $limit: limit }],
      },
    },
  ];
}
