import { Prisma, prisma } from "database";
import { Router } from "express";
import { MongoClient, ObjectId } from "mongodb";
import {
  initGlobalSearchService,
  globalSearchService,
} from "../../services/search.services";
import {
  attributesStages,
  categoryStages,
  contacsStages,
  photosStages,
  queryStage,
} from "./search-utils";

initGlobalSearchService();
export const searchRouter = Router();

const MONGODB_URI = process.env.MONGODB_URI;
const DATABASE_NAME = process.env.MONGODB_DATABASE_NAME;
const MAX_LISTING_COUNT = 12;

searchRouter.post("/", async (req, res) => {
  try {
    const mongoClient = new MongoClient(MONGODB_URI!);
    await mongoClient.connect();
    const db = mongoClient.db(DATABASE_NAME);

    const { body } = req;
    const { query, category, filter } = body;
    let page = body.page || 1;

    console.log(filter, "filter");

    // dynamic pipeline creation
    // 1. query - this will picks very few entries
    // 2. category - this will cancells many entries essentially a whole range
    // 3. attributes - this will cancells many entries
    // 4. contacts/locations - this will cancells many entries
    // 4. photos - this will not cancells any entries
    // entries towards top will cancells many thus causing smaller lookup

    console.log("Query Stage", queryStage(query));
    console.log("Category Stage", categoryStages(category));
    console.log(
      "Attributes Stage",
      attributesStages(filter?.categories ?? [], filter?.attributegroup ?? [])
    );
    console.log("Contacts Stage", contacsStages(filter?.locations));
    console.log("Photos Stage", photosStages());
    //

    let categoriesResults: any = null;
    let categoryMatchStage: any = [];
    if (category) {
      categoriesResults = globalSearchService.fuzzySearchCategories(category);
      // console.log(
      //   category,
      //   categoriesResults.id,
      //   categoriesResults.name,
      //   "categoryId"
      // );
      categoryMatchStage = [
        {
          $match: {
            categoriesId: { $in: [new ObjectId(categoriesResults.id)] },
          },
        },
      ];
    }

    // console.log("Filter Body", JSON.stringify(filter, null, 2));
    let { locations: locationsFilter, ...attributesFilter } = filter;

    if (attributesFilter) {
      attributesFilter = Object.values(attributesFilter).flat();
    }
    // console.log({ attributesFilter });

    const listingsAttributesFilter = [];
    for (const item of attributesFilter) {
      const id = Object.keys(item)[0];
      listingsAttributesFilter.push({
        "attributes.id": id,
        "attributes.value": { $eq: true },
      });
    }

    // const _attributesFilterStage =
    //   Object.keys(attributesFilter) > 0
    //     ? Object.keys(attributesFilter).map((key) => ({
    //         "attributes.id": key,
    //         "attributes.value": { $eq: true },
    //       }))
    //     : [];

    const _attributesFilterStages =
      listingsAttributesFilter.length > 0
        ? [{ $match: { $and: listingsAttributesFilter } }]
        : [];

    // console.log(
    //   "Stage Attributes Filter",
    //   JSON.stringify(_attributesFilterStages, null, 2)
    // );

    const _locationsFilterStages =
      locationsFilter?.length > 0
        ? [
            {
              $lookup: {
                from: "contacts",
                localField: "contactsId",
                foreignField: "_id",
                as: "contacts",
              },
            },
            {
              $match: {
                $or: [
                  {
                    "contacts.city": {
                      $regex: locationsFilter.join("|"),
                      $options: "i",
                    },
                  },
                  {
                    "contacts.state": {
                      $regex: locationsFilter.join("|"),
                      $options: "i",
                    },
                  },
                ],
              },
            },
          ]
        : [];

    // console.log(
    //   "Stage Location Filter",
    //   JSON.stringify(_locationsFilterStages, null, 2)
    // );

    const _listingIds = await db
      .collection("listings")
      .aggregate([
        ...categoryMatchStage,
        ..._attributesFilterStages,
        ..._locationsFilterStages,
      ])
      .project({ _id: 0, id: "$_id" })
      .toArray();

    console.log(_listingIds.length, "_listingIds");

    let prismaWhereFilters: Prisma.listingsWhereInput = {
      name: { contains: query, mode: "insensitive" },
    };

    if (_listingIds.length > 0) {
      prismaWhereFilters = {
        ...prismaWhereFilters,
        id: {
          in: _listingIds.map((item) => new ObjectId(item.id).toString()),
        },
      };
    }

    // console.log(JSON.stringify(prismaWhereFilters, null, 2));

    let count = await prisma.listings.count({
      where: prismaWhereFilters,
    });
    if (count <= MAX_LISTING_COUNT) page = 1;

    const listings = await prisma.listings.findMany({
      take: MAX_LISTING_COUNT,
      skip: MAX_LISTING_COUNT * (page - 1),
      where: prismaWhereFilters,
      include: {
        // location: true,
        contacts: true,
        photos: {
          select: {
            thumbUrl: true,
            url: true,
          },
        },
      },
    });

    let listingIds = listings.map((item: any) => item.id);
    const listingObjectIds = listingIds.map((id) => new ObjectId(id));

    const reviewSummary = await db
      .collection("reviews")
      .aggregate([
        {
          $match: {
            listingsId: { $in: listingObjectIds },
          },
        },
        {
          $group: {
            _id: "$listingsId",
            averageRating: { $avg: { $toDouble: "$ratingValue" } },
            totalReviews: { $sum: 1 },
          },
        },
      ])
      .toArray();

    await mongoClient.close();

    return res.status(200).json({
      count,
      listings,
      // reviewSummary,
    });
  } catch (error) {
    console.log("searchRouter", error);
    return res.status(400).json({ error });
  }
});
