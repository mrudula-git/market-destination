import { Router } from "express";
import { prisma } from "database";
import sendEmail from "email";

export const contactUsRouter = Router();

contactUsRouter.post("/", async (req, res) => {
  try {
    const { body } = req;
    const { name, email, message, phone, source } = body;
    console.log(body);

    const feedback = await prisma.feedback.create({
      data: {
        name,
        email,
        message,
        phone,
        source,
      },
    });
    let otp = name;

    console.log(feedback);

    // Admin email details
    let to = "support@findigoo.com";
    let subject = "New Contact Form Submission";
    let template = "admin-user-inquiry.ejs";
    let heading = "New Contact Information";
    let content = message;
    await sendEmail(to, subject, heading, content, template, name, otp, email,phone);

    // Send email to user
    if (email) {
      let subject = "We've Received Your Message";
      let heading = "Thank you for reaching out to us";
      let template = "user-contact-template.ejs";
      let content = message;
      await sendEmail(
        email,
        subject,
        heading,
        content,
        template,
        name,
        otp,
        email,
        phone
      );
    }

    res.status(201).json({ message: "Form submitted successfully!", feedback });
  } catch (error) {
    console.error("Error handling form submission:", error);
    res.status(500).json({ error: "Internal Server Error" });
  }
});
