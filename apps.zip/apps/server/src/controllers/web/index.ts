import { prisma } from "database";
import { Router } from "express";
// import { searchRouter } from "./search";
import { searchRouter } from "./search-copy2";
import { listingsRouter } from "./listings";
import { reviewersRouter } from "./reviewer";
import { reviewsRouter } from "./reviews";
import { listingsCategoriesRouter } from "./listings-categories";
import { listingsCompareRouter } from "./listings-compare";
import { listingsAttributesRouter } from "./listings-attributes";
import { contactUsRouter } from "./contact-us";

export const webRouter = Router();

// webRouter.use("/search", searchRouter);
webRouter.use("/search", searchRouter);
webRouter.use("/listings", listingsRouter);
webRouter.use("/reviewers", reviewersRouter);
webRouter.use("/reviewers/verify", reviewersRouter);
webRouter.use("/reviews", reviewsRouter);
webRouter.use("/listings-categories", listingsCategoriesRouter);
webRouter.use("/listings-compare", listingsCompareRouter);
webRouter.use("/listings-attributes", listingsAttributesRouter);
webRouter.use("/contact-us", contactUsRouter );

interface CustomMediaCreateInput {
  url: string;
  thumbUrl: string;
  cdnType?: string;
  cdnAuthKey?: string;
  listingsId?: string;
  reviewsId?: string;
}

webRouter.post("/media", async (req, res) => {
  try {
    const {
      url,
      thumbUrl,
      cdnType,
      cdnAuthKey,
      listingsId,
      reviewsId,
    }: CustomMediaCreateInput = req.body;

    if (!url || !thumbUrl) {
      return res.status(400).json({ error: "URL and thumbUrl are required" });
    }

    const media = await prisma.media.create({
      data: {
        url,
        thumbUrl,
        cdnType,
        cdnAuthKey,
        // listings: { connect: { id: listingsId } },
        // reviews: { connect: { id: reviewsId || undefined } },
      },
    });

    return res.status(201).json({ media });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ error: "Internal Server Error" });
  }
});
