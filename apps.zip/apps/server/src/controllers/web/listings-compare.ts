import { prisma } from "database";
import { Router } from "express";
import { ObjectId } from "mongodb";

export const listingsCompareRouter = Router();

listingsCompareRouter.post("/", async (req, res) => {
  try {
    const { body } = req;
    const { left: leftId, right: rightId } = body;
    // console.log({ leftId, rightId });

    const _ids = [leftId];
    if (rightId && ObjectId.isValid(rightId)) _ids.push(rightId);
    // console.log(_ids);

    const requests = _ids.map((id) =>
      prisma.listings.findFirst({
        where: { id },
        include: {
          contacts: true,
          location: true,
          photos: {
            select: {
              thumbUrl: true,
              url: true,
            },
          },
          packages: {
            include: { price: true },
          },
        },
      })
    );

    // const [left, right] = await prisma.listings.findMany({
    //   where: {
    //     id: {
    //       in: _ids,
    //     },
    //   },
    //   include: {
    //     contacts: true,
    //     location: true,
    //     photos: {
    //       select: {
    //         thumbUrl: true,
    //         url: true,
    //       },
    //     },
    //     packages: {
    //       include: { price: true },
    //     },
    //   },
    // });
    // console.log(left, right);

    const [left, right] = await Promise.all(requests);

    return res.status(200).json({ left, right });
  } catch (error) {
    console.log("listingCompare.post", error);
    return res.status(400).json(error);
  }
});

listingsCompareRouter.post("/search", async (req, res) => {
  try {
    const { body } = req;
    const { query, exclude } = body;

    // console.log(query, exclude);

    // if (
    //   !searchKeys ||
    //   typeof searchKeys !== "string" ||
    //   searchKeys.trim() === ""
    // ) {
    //   return res.status(400).json({ error: "Invalid search keys" });
    // }

    const listings = await prisma.listings.findMany({
      where: {
        name: { contains: query, mode: "insensitive" },
        id: { notIn: exclude },
      },
      include: {
        contacts: true,
      },
    });


    return res.status(200).json({ listings });
  } catch (error) {
    console.log("listingsCompare.post /search", error);
    return res.status(400).json(error);
  }
});
