import { Router } from "express";
import { searchParams } from "../../middlewares";
import { prisma } from "database";
import otpGenerator from "../emailSender.ts/otpGenerator";
import sendEmail from "email";

export const reviewersRouter = Router();

reviewersRouter.post("/", async (req, res) => {
  const { body } = req;
  const { email, id, name, otp } = body;

  try {
    // Check if the reviewer already exists
    const existingReviewer = await prisma.reviewers.findFirst({
      where: { email },
    });

    if (existingReviewer && existingReviewer.verified === true) {
      // Reviewer exists and is verified, no need to send OTP
      const { otp: _, ...reviewer } = existingReviewer;

      return res.status(200).json({
        message: "Reviewer created/updated successfully.",
        reviewer: reviewer,
      });
    }

    let reviewer;

    if (!existingReviewer) {
      // Reviewer does not exist, create a new reviewer and send OTP
      const newOtp = otpGenerator.generate(6, {
        digits: true,
        alphabets: false,
        upperCase: false,
        specialChars: false,
      });

      reviewer = await prisma.reviewers.create({
        data: { ...body, otp: newOtp },
      });

      let subject = "OTP Verification";
      let heading="Findigoo Verification Code";
      let content = `
        Thank you for choosing Findigoo. Use the following OTP
        to complete the procedure to confirm your email address. OTP is
        valid for 5 minutes.
        Do not share this code with others, including Findigoo employees.
        Your OTP for verification is:`;
      let template="email-template.ejs";
      let phone=otp;//this value is never use in template creation

      // Send the OTP to the new reviewer (email or SMS)
      if (email) {
        console.log("email, subject, content", email, subject, content,template);
        await sendEmail(email, subject,heading, content,template,name,newOtp,email,phone);
      }
    } else {
      // Reviewer exists but is not verified, resend OTP
      const newOtp = otpGenerator.generate(6, {
        digits: true,
        alphabets: false,
        upperCase: false,
        specialChars: false,
      });

      reviewer = await prisma.reviewers.update({
        where: { id: existingReviewer.id },
        data: { otp: newOtp },
      });

      let subject = "Resend OTP Verification";
      let content = `
        Your OTP for verification is:`;
      let template="email-template.ejs";
      let heading="Findigoo Resend Verification Code";
      let phone=otp;//this value is never use in template creation

      // Send the resent OTP to the existing reviewer (email or SMS)
      if (email) {
        console.log("email, subject, content", email, subject, content,template);
        await sendEmail(email,subject, heading, content,template,name,newOtp,email,phone);
      }
    }

    const { otp: _, ...reviewerWithoutOtp } = reviewer;

    return res.status(200).json({
      message: "Reviewer created/updated successfully.",
      reviewer: reviewerWithoutOtp,
    });
  } catch (error) {
    console.error("Error handling request:", error);
    return res.status(500).json({ message: "Internal Server Error." });
  }
});


reviewersRouter.post("/verify", async (req, res) => {
  try {
    const { email, name, otp } = req.body;

    // Fetch the stored OTP from your database
    const storedOtp = await prisma.reviewers
      .findFirst({
        where: { email: email || undefined, name: name || undefined },
      })
      .then((reviewer) => reviewer?.otp || "");
    // Compare the entered OTP with the stored OTP
    if (otp === storedOtp) {
      // OTP is valid, you can proceed with your desired logic
      const existingReviewer = await prisma.reviewers.findFirst({
        where: {
          OR: [{ email: email || undefined }],
        },
      });
      let reviewer;
      if (existingReviewer) {
        // Use the existing OTP for the existing reviewer
        reviewer = await prisma.reviewers.update({
          where: { id: existingReviewer.id },
          data: { email: email, verified: true },
        });
      } else {
      }
      return res.status(200).json({ message: "OTP verification successful." });
    } else {
      return res.status(200).json({ message: "Invalid OTP." });
    }
  } catch (error) {
    console.error("Error verifying OTP:", error);
    return res.status(500).json({ message: "Internal Server Error." });
  }
});

reviewersRouter.get("/", async (req, res) => {
  const { email, name } = req.query;
  try {
    const reviewers = await prisma.reviewers.findFirst({
      where: {
        OR: [{ email: email as string }, { name: name as string }],
      },
    });

    if (!reviewers) {
      return res.status(200).json({ reviewer: null });
    }

    const { otp, ...reviewer } = reviewers as Partial<typeof reviewers> & {
      otp?: never;
    };

    return res.status(200).json({ reviewer });
  } catch (error) {
    console.error("Error fetching reviewer details:", error);
    return res.status(500).json({ message: "Internal Server Error" });
  }
});

reviewersRouter.get("/", async (req, res) => {
  const { email, name } = req.query;
  try {
    const reviewers = await prisma.reviewers.findFirst({
      where: {
        OR: [{ email: email as string }, { name: name as string }],
      },
    });

    if (!reviewers) {
      return res.status(200).json({ reviewer: null });
    }

    const { otp, ...reviewer } = reviewers as Partial<typeof reviewers> & {
      otp?: never;
    };

    return res.status(200).json({ reviewer });
  } catch (error) {
    console.error("Error fetching reviewer details:", error);
    return res.status(500).json({ message: "Internal Server Error" });
  }
});
