import { prisma } from "database";
import { Router } from "express";
import { MongoClient, ObjectId } from "mongodb";

const mongoURI = process.env.DATABASE_URL;
const mongodb = new MongoClient(mongoURI!);
const db = mongodb.db(process.env.MONGODB_DATABASE_NAME);

export const listingsAttributesRouter = Router();

listingsAttributesRouter.post("", async (req, res) => {
  try {
    const { body } = req;
    const { categoriesId, attributeGroupsId } = body;

    const attributesRequest = prisma.listing_attributes.findMany({
      where: {
        OR: [
          {
            categoriesId: {
              hasSome: categoriesId,
            },
          },
          {
            listingAttributeGroupsId: {
              hasSome: attributeGroupsId,
            },
          },
        ],
        canFilter: true,
      },
    });

    const categoriesRequest = prisma.listing_categories.findMany({
      select: {
        id: true,
        name: true,
      },
    });
    const attributeGroupsRequest = prisma.listing_attribute_groups.findMany({
      select: {
        id: true,
        name: true,
      },
    });
    const [attributes, categories, attributeGroups] = await Promise.all([
      attributesRequest,
      categoriesRequest,
      attributeGroupsRequest,
    ]);

    return res.status(200).json({ attributes, categories, attributeGroups });
  } catch (error) {
    // console.log("listingsAttributesRouter.post", error);
    return res.status(400).json(error);
  }
});

listingsAttributesRouter.post("/attributes", async (req, res) => {
  try {
    const { body } = req;
    const { attribiteIds } = body;
    // console.log(attribiteIds);
    const attributesRequest = prisma.listing_attributes.findMany({
      where: {
        id: { in: attribiteIds },
      },
      include: {
        listingAttributeGroups: {
          select: {
            id: true,
            name: true,
          },
        },
      },
    });
    const attributeGroupsRequest = prisma.listing_attribute_groups.findMany({
      select: {
        id: true,
        name: true,
        attributesId: true,
      },
    });
    const [attributes, attributeGroups] = await Promise.all([
      attributesRequest,
      attributeGroupsRequest,
    ]);
    return res.status(200).json({ attributes, attributeGroups });
  } catch (error) {
    return res.status(400).json(error);
  }
});

listingsAttributesRouter.post("/compare", async (req, res) => {
  try {
    const { body } = req;
    // console.log(body);

    const { attributeIds, ids } = body;
    const categoriesRequest = prisma.listing_categories.findMany({
      // where: {
      //   attributes: {
      //     some: {
      //       id: {
      //         in: attributeIds,
      //       },
      //     },
      //   },
      // },
      select: {
        id: true,
        name: true,
        attributesId: true,
        // attributes: {
        //   where: {
        //     id: {
        //       in: attributeIds,
        //     },
        //   },
        // select: {
        //   id: true,
        //   name: true,
        // },
        // },
      },
    });
    const attributeGroupsRequest = prisma.listing_attribute_groups.findMany({
      // where: {
      //   attributes: {
      //     some: {
      //       id: {
      //         in: attributeIds,
      //       },
      //     },
      //   },
      // },
      select: {
        id: true,
        name: true,
        attributesId: true,
        // attributes: {
        //   where: {
        //     id: {
        //       in: attributeIds,
        //     },
        //   },
        // },
      },
    });
    // async function calculateAverageRatings(listingsId: string) {
    //   const reviews = await prisma.reviews.findMany({
    //     where: {
    //       listingsId: listingsId,
    //     },
    //     include: {
    //       details: true,
    //     },
    //   });
    //   console.log(reviews.length);

    //   if (reviews.length > 0) {
    //     const ratingFields = [
    //       "cleanlinessRating",
    //       "comfortRating",
    //       "valueRating",
    //       "servicesRating",
    //     ];

    //     const averageRatings = ratingFields.reduce((averages: any, field) => {
    //       // console.log(averages,field);

    //       const totalRating = reviews.reduce(
    //         (total: any, review: any) => total + (review.details?.[field] || 0),
    //         0
    //       );
    //       // console.log(totalRating);

    //       averages[field] = totalRating / reviews.length;

    //       return averages;
    //     }, {});

    //     // console.log(
    //     //   "Average Ratings for listingsId",
    //     //   listingsId,
    //     //   ":",
    //     //   averageRatings
    //     // );
    //     return averageRatings;
    //   } else {
    //     // console.log(
    //     //   "No reviews found for the specified listingsId:",
    //     //   listingsId
    //     // );
    //     return 0;
    //   }
    // }
    // let rev1 = calculateAverageRatings(ids[0]);
    // let rev2 = calculateAverageRatings(ids[1]);

    const objectIds = ids.map((id: any) => new ObjectId(id));

    const reviewSummarydata = db
      .collection("reviews")
      .aggregate([
        {
          $match: {
            listingsId: {
              $in: objectIds,
            },
          },
        },
        {
          $lookup: {
            from: "review_details",
            localField: "reviewDetailsId",
            foreignField: "_id",
            as: "details",
          },
        },
        {
          $unwind: {
            path: "$details",
            preserveNullAndEmptyArrays: false,
          },
        },
        {
          $group: {
            _id: "$listingsId",
            countRatingValue: { $sum: 1 },
            avgRatingValue: { $avg: "$ratingValue" },
            avgCleanlinessRatingValue: { $avg: "$details.cleanlinessRating" },
            avgComfortRatingValue: { $avg: "$details.comfortRating" },
            avgValueRatingValue: { $avg: "$details.valueRating" },
            avgServicesRatingValue: { $avg: "$details.servicesRating" },
          },
        },

        {
          $project: {
            _id: 0,
            listingsId: "$_id",
            totalReviews: "$countRatingValue",
            averageRating: "$avgRatingValue",
            cleanliness: {
              count: "$countRatingValue",
              average: "$avgCleanlinessRatingValue",
            },
            comfort: {
              count: "$countRatingValue",
              average: "$avgComfortRatingValue",
            },
            value: {
              count: "$countRatingValue",
              average: "$avgValueRatingValue",
            },
            services: {
              count: "$countRatingValue",
              average: "$avgServicesRatingValue",
            },
          },
        },
      ])
      .toArray();

    const [categories, attributeGroups, reviewSummary] = await Promise.all([
      categoriesRequest,
      attributeGroupsRequest,
      reviewSummarydata,
    ]);

    // console.log(reviewSummarydata);
    // console.log(
    //   categories,
    //   attributeGroups,
    //   reviewSummary
    // );

    return res.status(200).json({
      categories,
      attributeGroups,
      reviewSummary,
    });
  } catch (error) {
    console.log("...", error);
    return res.status(400).json(error);
  }
});
