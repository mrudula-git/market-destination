import { prisma } from "database";
import { Router } from "express";
import { MongoClient, ObjectId } from "mongodb";

const mongoURI = process.env.DATABASE_URL;
const mongodb = new MongoClient(mongoURI!);
const db = mongodb.db(process.env.MONGODB_DATABASE_NAME);

export const listingsCategoriesRouter = Router();

listingsCategoriesRouter.get("", async (req, res) => {
  try {
    const categories = await prisma.listing_categories.findMany({
      where: {
        OR: [
          { name: { contains: "waterparks", mode: "insensitive" } },
          { name: { contains: "resorts", mode: "insensitive" } },
          { name: { contains: "agro tourism", mode: "insensitive" } },
          { name: { contains: "farmhouse", mode: "insensitive" } },
        ],
      },
      include: {
        listings: {
          orderBy: {
            reviews: {
              _count: "desc",
            },
          },
          take: 3,
          include: {
            photos: {
              select: {
                thumbUrl: true,
                url: true,
              },
            },
          },
        },
      },
    });

    //   const listingIds = categories.flatMap((category) =>
    //   category.listings.map((listing) => listing.id)
    // );
    const listingIds = [];
    for (const category of categories) {
      for (const listing of category.listings) {
        listingIds.push(listing.id);
      }
    }

    const objectIds = listingIds.map((id) => new ObjectId(id));

    // const reviewSummary = await db
    //   .collection("reviews")
    //   .aggregate([
    //     {
    //       $match: {
    //         listingsId: {
    //           $in: objectIds,
    //         },
    //       },
    //     },
    //     {
    //       $group: {
    //         _id: "$listingsId",
    //         averageRating: {
    //           $avg: {
    //             $toDouble: "$ratingValue",
    //           },
    //         },
    //         totalReviews: {
    //           $sum: 1,
    //         },
    //       },
    //     },
    //   ])
    //   .toArray();

    const reviewSummary = await db
      .collection("REVIEW_AVERAGE_VIEW")
      .aggregate([
        {
          $match: {
            _id: {
              $in: objectIds,
            },
          },
        },
      ])
      .toArray();

    return res.status(200).json({ categories, reviewSummary });
  } catch (error) {
    console.error(error);
    return res.status(400).json(error);
  }
});
