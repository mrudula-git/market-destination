import { Prisma, prisma } from "database";
import { Router } from "express";
import { MongoClient, ObjectId } from "mongodb";
import {
  initGlobalSearchService,
  globalSearchService,
} from "../../services/search.services";
import {
  attributesStages,
  categoryStages,
  contacsStages,
  facetStage,
  photosStages,
  queryStage,
  reviewsStages,
} from "./search-utils";

initGlobalSearchService();
export const searchRouter = Router();

const MONGODB_URI = process.env.MONGODB_URI;
const DATABASE_NAME = process.env.MONGODB_DATABASE_NAME;

const LISTINGS_PER_PAGE = 12;

searchRouter.post("/", async (req, res) => {
  try {
    const mongoClient = new MongoClient(MONGODB_URI!);
    await mongoClient.connect();
    const db = mongoClient.db(DATABASE_NAME);

    const { body } = req;
    const { query, category, filter } = body;
    let page = body.page || 1;

    // dynamic pipeline creation
    // 1. query - this will picks very few entries
    // 2. category - this will cancells many entries essentially a whole range
    // 3. contacts/locations - this will cancells many entries
    // 4. reviews - this will cancells many entries
    // 5. attributes - this will cancells many entries
    // 6. photos - this will not cancells any entries
    // entries towards top will cancells many thus causing smaller lookup

    let pipeline: any = [];

    // console.log("Query Stage", queryStage(query));
    pipeline = [...pipeline, ...queryStage(query)];
    // console.log("After Query Stage", query, pipeline);

    // console.log("Category Stage", categoryStages(category));
    pipeline = [...pipeline, ...categoryStages(category)];
    // console.log("After Category Stage", category, pipeline);

    // console.log("Contacts Stage", contacsStages(filter?.locations));
    pipeline = [...pipeline, ...contacsStages(filter?.locations)];
    // console.log("After Locations/Contacts Stage", filter?.locations, pipeline);

    // console.log("Reviews Stage", reviewsStages(filter?.reviews));
    pipeline = [...pipeline, ...reviewsStages(filter?.reviews)];
    // console.log("After Reviews Stage", filter?.reviews, pipeline);

    // console.log(
    //   "Attributes Stage",
    //   attributesStages(filter?.categories ?? [], filter?.attributegroup ?? [])
    // );
    pipeline = [
      ...pipeline,
      ...attributesStages(
        filter?.categories ?? [],
        filter?.attributegroup ?? []
      ),
    ];
    // console.log("After Attributes Stage", pipeline);

    // console.log("Photos Stage", photosStages());
    pipeline = [...pipeline, ...photosStages()];
    // console.log("After Photos Stage", pipeline);
    //

    pipeline = [
      ...pipeline,
      ...facetStage({
        skip: (page - 1) * LISTINGS_PER_PAGE,
        limit: LISTINGS_PER_PAGE,
      }),
    ];

    let results = await db.collection("listings").aggregate(pipeline).toArray();

    const { count, listings } = results[0];
    const total = count[0]?.total || 0;
    console.log(count);
    // console.log("Listings", listings);

    await mongoClient.close();

    return res.status(200).json({
      count: total,
      listings,
      pipeline,
    });
  } catch (error) {
    console.log("searchRouter", error);
    return res.status(400).json({ error });
  }
});
