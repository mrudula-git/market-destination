import { Router } from "express";
import { prisma } from "database";
import { MongoClient } from "mongodb";

const mongoURI = process.env.MONGODB_URI;
const mongodb = new MongoClient(mongoURI!);
const db = mongodb.db(process.env.MONGODB_DATABASE_NAME);

export const listingsRouter = Router();

listingsRouter.get("/:slug", async (req, res) => {
  try {
    const { slug } = req.params;
    const listing = await prisma.listings.findFirst({
      where: { slug },
      include: {
        contacts: true,
        photos: true,
        badges: true,
        categories: {
          select: { id: true, name: true, attributesId: true },
          // include: { attributes: true },
        },
        attributeGroups: {
          select: { id: true, name: true, attributesId: true },
          // include: { attributes: true },
        },
        location: true,
        // places: {
        //   include: { location: true },
        // },
        packages: {
          include: { price: true },
        },
        // reviews: {
        //   orderBy: { createdAt: "desc" },
        //   include: {
        //     details: true,
        //     reviewer: { select: { name: true } },
        //     photos: { select: { url: true, thumbUrl: true } },
        //   },
        // },
      },
    });
    return res.status(200).json({ listing });
  } catch (error) {
    console.log("listingsRouter.get '/:slug'", error);
    return res.status(400).json(error);
  }
});

listingsRouter.get("", async (req, res) => {
  try {
    // await mongodb.connect();
    // const filter = {
    //   $and: [
    //     {
    //       "attributes.id": "659fb692ade6925678f018a5",
    //       "attributes.value": { $eq: true },
    //     },
    //     // {
    //     //   "attributes.id": "659fb776ade6925678f018aa",
    //     //   "attributes.value": { $eq: true },
    //     // },
    //   ],
    // };
    // const l = await db
    //   .collection("listings")
    //   .find(filter)
    //   .toArray();
    // // .project({ _id: 1 });
    // console.log(l);

    // const l = await prisma.listing_categories.findMany({
    //   include: {
    //     listings: {
    //       take: 4,
    //     },
    //   },
    // });
    // console.log(l);

    const listings = await prisma.listings.findMany({
      // where: {
      //   id: {
      //     in: l.map(({ _id }) => _id.toString()!),
      //   },
      // },
      take: 6,
      include: {
        photos: {
          select: {
            thumbUrl: true,
            url: true,
          },
        },
        // contacts: true,
        // badges: true,
        // categories: {
        //   select: {
        //     name: true,
        //     attributes: {
        //       select: {
        //         canFilter: true,
        //         id: true,
        //         name: true,
        //       },
        //     },
        //   },
        //   // include: { attributes: true },
        // },
        // attributeGroups: {
        //   select: {
        //     name: true,
        //     attributes: {
        //       select: {
        //         canFilter: true,
        //         id: true,
        //         name: true,
        //       },
        //     },
        //   },
        //   // include: { attributes: true },
        // },
        // location: true,
        // places: {
        //   include: { location: true },
        // },
        // packages: {
        //   include: { price: true },
        // },
        // reviews: {
        //   select: {
        //     ratingValue: true,
        //   },
        //   // include: { details: true, reviewer: true },
        // },
      },
    });
    return res.status(200).json({ listings });
  } catch (error) {
    return res.status(400).json({ error });
  }
});
