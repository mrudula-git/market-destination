import { Router } from "express";
import { prisma } from "database";
import { searchParams } from "../../middlewares";
import sendEmail from "email";

export const reviewsRouter = Router();

reviewsRouter.get("/", searchParams, async (req, res) => {
  try {
    const { allQuery, prismaFilters } = req;

    const count = await prisma.listings.count({ where: prismaFilters?.where });

    const reviews = await prisma.reviews.findMany({
      ...prismaFilters,

      include: {
        details: true,
        reviewer: true,
        photos: true,
      },
    });
    return res.status(200).json({ reviews, count });
  } catch (error) {
    console.error("reviewsRouter.get", error);
    return res.status(500).json({ error: "Internal Server Error" });
  }
});

reviewsRouter.get("/listings/:listingsId", async (req, res) => {
  try {
    const { params } = req;
    const reviews = await prisma.reviews.findMany({
      where: {
        listingsId: params.listingsId,
      },
      orderBy: {
        createdAt: "desc",
      },
      include: {
        details: true,
        reviewer: true,
        photos: true,
      },
    });
    return res.status(200).json({ reviews });
  } catch (error) {
    return res.status(500).json(error);
  }
});

reviewsRouter.get("/:id", async (req, res) => {
  try {
    const { params } = req;
    const review = await prisma.reviews.findUnique({
      where: {
        id: params.id,
      },
      include: {
        details: true,
        reviewer: true,
      },
    });
    return res.json({ review });
  } catch (error) {
    return res.status(500).json(error);
  }
});

reviewsRouter.post("/", async (req, res) => {
  const { body, allParams, params } = req;
  const { details, listingsId, reviewersId, photos, ...rest } = body;

  try {
    const review = await prisma.reviews.create({
      data: {
        ...rest,
        details: {
          create: {
            ...details,
          },
        },
        reviewer: {
          connect: { id: reviewersId },
        },
        listings: {
          connect: { id: listingsId },
        },
        photos: {
          connect: photos.map(({ id }: { id: string }) => ({ id })),
        },
      },
    });
    if (reviewersId) {
      const reviewer = await prisma.reviewers.findFirst({
        where: {
          id: reviewersId,
        },
      });
      if (reviewer) {
        const email = reviewer.email;
        const name = reviewer.name;
        const otp=name;
        let phone=otp;//this value is never use in template creation
        let heading="Review submited successfully!";
        let subject = "Review submited";
        let content =`Thank you for your feedback.`;
        let template="review-submit.ejs";

        if (email) {
          console.log("email, subject, content", email, subject, content,template,name,otp,email);
          await sendEmail(email,subject,heading, content,template,name,otp,email,phone);
        }
      }
    }
    return res.status(200).json({ review });
  } catch (error) {
    console.log("reviewsRouter.post", error);
    return res.status(500).json(error);
  }
});

reviewsRouter.patch("/:id", async (req, res) => {
  try {
    const { body, allParams, params } = req;
    const { details, ...rest } = body;

    const { id } = params;

    const review = await prisma.reviews.update({
      where: { id: id },
      data: {
        ...rest,
        details: {
          update: {
            ...details,
          },
        },
      },
    });
    return res.json(review);
  } catch (error) {
    return res.status(500).json(error);
  }
});

reviewsRouter.delete("/:id", async (req, res) => {
  try {
    const { params } = req;
    const review = await prisma.reviews.delete({
      where: {
        id: params.id,
      },
      include: {
        details: true,
      },
    });

    await prisma.review_details.delete({
      where: {
        id: review.details.id,
      },
    });

    res.status(200).json(review);
  } catch (error) {
    return res.status(500).json(error);
  }
});
