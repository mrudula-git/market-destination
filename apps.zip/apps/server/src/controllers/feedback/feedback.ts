import { Router } from "express";
import {Prisma, prisma} from "database";

export const feedbackRouter = Router();

feedbackRouter.get("/", async (req, res) => {
    try{
        const { allQuery, prismaFilters } = req;

        const count = await prisma.feedback.count({
            where: prismaFilters?.where,
        })

        const feedback = await prisma.feedback.findMany({...prismaFilters});
        return res.status(200).json({feedback, count});
    }
    catch(error) {
        console.error("feedbackRouter.get", error);
        return res.status(500).json({error:"Internal Server error"});
    }
});

feedbackRouter.get("/:id", async (req, res ) => {
    try{
        const {params} = req;
        const singleFeedback = await prisma.feedback.findUnique({
            where : {
                id: params.id,
             },
        });
        return res.json({ feedback : singleFeedback });
    }
    catch(error) {
        return res.status(500).json(error);
    }
});

// feedbackRouter.post("/", async(req, res) => {
//     const {body} = req;

//     try{
//         const createdFeedback = await prisma.feedback.create({
//             data: {...body},
//         });
//         return res.status(200).json({feedback: createdFeedback});
//     }
//     catch(error) {
//         console.log("feedbackRouter.post",error);
//         return res.status(500).json(error);
//     }
// })

// feedbackRouter.patch("/:id", async (req, res )=>{
//     try{
//         console.log("inside patch feedback");
//         const {body, params } = req;
//         const {id} = params;

//         const updatedFeedback = await prisma.feedback.update({
//             where: {id: id},
//             data: {...body},
//         });
//         return res.json({feedback: updatedFeedback})
//     }
//     catch(error){
//         return res.status(500).json(error);
//     }
// })

feedbackRouter.delete("/:id", async (req, res) => {
    try{
        const { params } = req;
        const deleteFeedback = await prisma.feedback.delete({
            where: {
                id: params.id,
            },
        });
        res.status(200).json({feedback: deleteFeedback });
    }
    catch(error) {
        return res.status(500).json(error);
    }
})