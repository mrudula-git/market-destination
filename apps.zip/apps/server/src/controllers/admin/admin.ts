import { error } from "console";
import { prisma } from "database";
import { Router } from "express";
import { searchParams } from "../../middlewares";
export const adminUsersRoutes = Router();

adminUsersRoutes.get("/", searchParams, async (req, res) => {
  try {
    const { allQuery, prismaFilters } = req;

    console.log("get admin", prismaFilters);

    const count = await prisma.admin_users.count({
      where: prismaFilters?.where,
    });

    const adminUsers = await prisma.admin_users.findMany({
      ...prismaFilters,
      include: {
        contacts: true,
      },
    });
    res.status(200).json({ adminUsers, count });
  } catch (error) {
    console.log(error);
    res.status(500).json(error);
  }
});

adminUsersRoutes.get("/:id", async (req, res) => {
  try {
    const { id } = req.params;
    const adminUser = await prisma.admin_users.findFirst({
      where: {
        id: id,
      },
      include: {
        contacts: true,
      },
    });
    res.status(200).json({ adminUser });
  } catch (error) {
    console.log(error);
    res.status(500).json(error);
  }
});

adminUsersRoutes.post("/", async (req, res) => {
  try {
    console.log(req.body);
    const { name, active, position, activityDescription, contacts } = req.body;
    const adminUser = await prisma.admin_users.create({
      data: {
        name: name,
        active: active,
        position: position,
        // activityDescription: activityDescription,
        contacts: {
          // connectOrCreate: {
          //   where: {
          //     primaryPhoneNumber: contacts.primaryPhoneNumber,
          //   },
          //   create: {
          //     primaryEmail: contacts.primaryEmail,
          //     primaryPhoneNumber: contacts.primaryPhoneNumber,
          //   },
          // },
          create: {
            ...contacts,
          },
        },
      },
    });
    res.status(200).json(adminUser);
  } catch (error) {
    console.log(error);
    res.status(500).json(error);
  }
});

adminUsersRoutes.patch("/:id", async (req, res) => {
  try {
    const { id } = req.params;
    const { id: adminId, contactsId, contacts, ...adminDetails } = req.body;
    const {id: _contactsId, ...contactsRest}=contacts

    const updatedAdminUser = await prisma.admin_users.update({
      where: { id: id },
      data: {
        ...adminDetails,
        contacts: {
          update: {
            where: { id: contactsId },
            data:{
              ...contactsRest
            }
          }
        }
      },
    });
    // console.log("Updated adminUser:", updatedAdminUser);
    res.status(200).json(updatedAdminUser);
  } catch (error) {
    // console.log("adminUsersRoutes.patch Error:", error);
    res.status(500).json({ error });
  }
});

adminUsersRoutes.delete("/:id", async (req, res) => {
  try {
    const { id } = req.params;
    const adminUser = await prisma.admin_users.delete({
      where: {
        id: id,
      },
    });

    res
      .status(200)
      .send({ message: "Admin user deleted sucessfully " + adminUser.name });
  } catch (error) {
    res.status(500).json(error);
  }
});
