"use client";

import { Button, Label, TextInput } from "flowbite-react";
import { SignInResponse, signIn } from "next-auth/react";
import Link from "next/link";
import { redirect } from "next/navigation";
import type { FormEvent } from "react";
import { useState } from "react";
import { toast } from "react-toastify";
import { z } from "zod";
import { routes } from "../../../constants/routes";

const loginSchema = z.object({
  email: z.string().min(1, "Email is required").email("Invalid email format"),
  password: z
    .string()
    .min(1, "Password is required")
    .min(4, "Password must have more than 4 characters")
    .max(32, "Password must have less than 32 characters"),
});
const Schema = loginSchema;

const initialState = {
  email: "",
  password: "",
};

export default function LoginForm() {
  const [formData, setFormData] = useState(initialState);

  const [errorMessage, setErrorMessage] = useState("");

  const [isLoading, setIsLoading] = useState(false);

  const [fieldErrors, setFieldErrors] = useState({});

  function handleFieldChange(key: "email" | "password", value: string) {
    let _formData = structuredClone(formData);
    _formData[key] = value;
    setFormData(_formData);

    const result = Schema.safeParse(_formData);
    if (result.success) {
      setFieldErrors({});
      return;
    }

    const _errors = result.error.flatten().fieldErrors;
    console.log(_errors);
    setFieldErrors(_errors);
  }

  async function handleSubmit(event: FormEvent) {
    try {
      event.preventDefault();

      setIsLoading(true);

      const validation = Schema.safeParse(formData);
      if (!validation.success) {
        const _errors = validation.error.flatten().fieldErrors;
        // console.log(_errors);
        setFieldErrors(_errors);
        return;
      }

      const result = (await signIn("credentials", {
        redirect: false,
        ...formData,
      })) as SignInResponse;

      console.log("signIn", result);

      if (!result?.error) redirect(routes.home);

      if (result?.error === "CredentialsSignin") {
        toast("Invalid email or password", { type: toast.TYPE.ERROR });
        return;
      }
    } catch (error) {
      console.log("catech ", error);
      // setFieldErrors({});
    } finally {
      setIsLoading(false);
    }
  }

  return (
    <div className="flex items-center justify-center h-screen bg-gray-100">
      <div className="w-full max-w-sm p-8 bg-white border rounded">
        <form onSubmit={handleSubmit}>
          <h5 className="text-xl font-black ">Login</h5>
          <br />

          <div className="mb-4">
            <Label className="block mb-1" htmlFor="login-eamil" value="Email" />
            <TextInput
              id="login-eamil"
              type="email"
              placeholder="name@flowbite.com"
              color={fieldErrors?.email?.length ? "failure" : "gray"}
              helperText={fieldErrors?.email?.[0]}
              value={formData.email}
              onChange={(e) => {
                handleFieldChange("email", e.target.value);
              }}
            />
          </div>

          <div className="mb-4">
            <div className="mb-1">
              <Label
                className="block mb-1"
                htmlFor="login-password"
                value="Password"
              />
              <TextInput
                id="login-password"
                type="password"
                color={fieldErrors?.password?.length ? "failure" : "gray"}
                helperText={fieldErrors?.password?.[0]}
                value={formData.password}
                onChange={(e) => {
                  handleFieldChange("password", e.target.value);
                }}
              />
            </div>
            {/* <div>
              <Checkbox id="login-show-hide-password" />
              <Label
                className="ml-2"
                htmlFor="login-show-hide-password"
                value="Show Password"
              />
            </div> */}
          </div>

          <br />
          <div className="flex justify-between items-center">
            <Button className="block" type="submit" disabled={isLoading}>
              Login
            </Button>
            <div className="text-right text-sm font-medium">
              <Link href="/forget-password" className="hover:underline">
                Forgot password?
              </Link>
            </div>
          </div>

          <br />

          {/* 
          <br />
          <div className="text-center text-sm font-medium">
            Don't have account?{" "}
            <Link href="/register" className="hover:underline">
              Register here
            </Link>
          </div> */}
        </form>
      </div>
    </div>
  );
}
