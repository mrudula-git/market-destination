"use client";

import { useSession } from "next-auth/react";
import { redirect } from "next/navigation";
import Loading from "../../../components/ui/Loading";
import { routes } from "../../../constants/routes";
import LoginForm from "./login-form";

export default function LoginPage() {
  const { status } = useSession();

  if (status === "authenticated") {
    redirect(routes.home);
  }

  return <div>{status === "loading" ? <Loading /> : <LoginForm />}</div>;
}
