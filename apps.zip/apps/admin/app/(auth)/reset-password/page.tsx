"use client";

import { useMutation } from "@tanstack/react-query";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { apis } from "../../../constants/apis";
import apiKit from "../../../utils/api.helper";

export default function ResetPasswordPage() {
  const initialState = {
    newPassword: "",
    confirmNewPassword: "",
  };

  const [formData, setFormData] = useState(initialState);
  const [errorMessage, setErrorMessage] = useState("");
  const router = useRouter();

  const handleChange = (e: any) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };

  const mutation = useMutation({
    mutationKey: ["resetPassword"],
    mutationFn: async (body) => {
      const response = await apiKit({
        api: apis.resetpassword,
        method: "POST",
        body,
      });
      if (response && response.error) {
        setErrorMessage(response.error);
      } else {
        // Redirect or show success message after resetting password
      }
      return response;
    },
    onError: (error) => {
      console.error("Password reset failed!", error);
    },
    onSuccess: (data) => {
      console.log("Password reset success!", data);
    },
  });

  const handleSubmit = async (e: any) => {
    e.preventDefault();
    try {
      const { newPassword, confirmNewPassword } = formData;

      if (
        !newPassword ||
        !confirmNewPassword ||
        newPassword !== confirmNewPassword
      ) {
        console.error("Passwords do not match or are missing");
        return;
      }

      mutation.mutate(formData);
    } catch (error) {
      console.error("Password reset failed!", error);
    }
  };

  return (
    <div className="flex items-center justify-center h-screen">
      <div className="w-full max-w-sm p-4 bg-white border border-gray-200 rounded-lg shadow sm:p-6 md:p-8 dark:bg-gray-800 dark:border-gray-700">
        <form className="space-y-6" onSubmit={handleSubmit}>
          <h5 className="text-xl font-medium text-gray-900 dark:text-white">
            Reset Password
          </h5>
          <div>
            <label
              htmlFor="newPassword"
              className="block mb-2 text-sm font-medium text-gray-900 dark:text-white"
            >
              New Password
            </label>
            <input
              type="password"
              name="newPassword"
              id="newPassword"
              className="w-full rounded-lg"
              value={formData.newPassword}
              onChange={handleChange}
              placeholder="Enter new password"
              required
            />
          </div>
          <div>
            <label
              htmlFor="confirmNewPassword"
              className="block mb-2 text-sm font-medium text-gray-900 dark:text-white"
            >
              Confirm New Password
            </label>
            <input
              type="password"
              name="confirmNewPassword"
              id="confirmNewPassword"
              className="w-full rounded-lg"
              value={formData.confirmNewPassword}
              onChange={handleChange}
              placeholder="Confirm new password"
              required
            />
          </div>
          <button
            type="submit"
            className="w-full text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800"
          >
            Reset Password
          </button>
          {errorMessage && <div className="text-red-600">{errorMessage}</div>}
          <div className="text-sm font-medium text-gray-500 dark:text-gray-300">
            Back to{" "}
            <a
              href="/login"
              className="text-blue-700 hover:underline dark:text-blue-500"
            >
              Login
            </a>
          </div>
        </form>
      </div>
    </div>
  );
}
