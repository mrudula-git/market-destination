"use client";

import { useMutation } from "@tanstack/react-query";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { apis } from "../../../constants/apis";
import apiKit from "../../../utils/api.helper";
import Link from "next/link";

export default function ForgotPasswordPage() {
  const initialState = {
    email: "",
  };

  const [formData, setFormData] = useState(initialState);
  const [errorMessage, setErrorMessage] = useState("");
  const router = useRouter();

  const handleChange = (e: any) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };

  const mutation = useMutation({
    mutationKey: ["forgotPassword"],
    mutationFn: async (body) => {
      const response = await apiKit({
        api: apis.forgetpassword,
        method: "POST",
        body,
      });
      if (response && response.error) {
        setErrorMessage(response.error);
      } else {
        // Redirect or show success message after submitting email for password reset
      }
      return response;
    },
    onError: (error) => {
      console.error("Password reset request failed!", error);
    },
    onSuccess: (data) => {
      console.log("Password reset request success!", data);
    },
  });

  const handleSubmit = async (e: any) => {
    e.preventDefault();
    try {
      const { email } = formData;

      if (!email) {
        console.error("Email is required");
        return;
      }

      mutation.mutate(formData);
    } catch (error) {
      console.error("Password reset request failed!", error);
    }
  };

  return (
    <div className="flex items-center justify-center h-screen bg-gray-100">
      <div className="w-full max-w-sm p-8 bg-white border rounded">
        <form onSubmit={handleSubmit}>
          <h5 className="text-xl font-black">Forgot Password</h5>
          <br />
          <p>This feature is coming soon.</p>
          <p>For time being please contact your admin.</p>
          {/* <div>
            <label
              htmlFor="email"
              className="block mb-2 text-sm font-medium text-gray-900 dark:text-white"
            >
              Email
            </label>
            <input
              type="email"
              name="email"
              id="email"
              className="w-full rounded-lg"
              value={formData.email}
              placeholder="example@gmail.com"
              onChange={handleChange}
              required
            />
          </div> */}
          {/* <button
            type="submit"
            className="w-full text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800"
          >
            reset
          </button> */}

          <br />
          <br />
          <div className="text-sm font-medium flex justify-between items-center">
            <Link href="/login" className="hover:underline">
              Login here
            </Link>
            <Link href="/register" className="hover:underline">
              Register here
            </Link>
          </div>
        </form>
      </div>
    </div>
  );
}
