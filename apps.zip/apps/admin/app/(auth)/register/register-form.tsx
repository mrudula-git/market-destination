export default function RegisterForm() {
  return <div></div>;
}
