"use client";

import { useState } from "react";
import type { FormEvent } from "react";
import { SignInResponse, signIn } from "next-auth/react";
import { z } from "zod";
import { toast } from "react-toastify";
import apiKit from "../../../utils/api.helper";
import { apis } from "../../../constants/apis";
import { routes } from "../../../constants/routes";
import { redirect, useRouter } from "next/navigation";
import { Button, Label, TextInput } from "flowbite-react";
import Link from "next/link";

const registrationSchema = z.object({
  email: z.string().min(1, "Email is required").email("Invalid email format"),
  password: z
    .string()
    .min(1, "Password is required")
    .min(4, "Password must be at least 4 characters")
    .max(32, "Password must have less than 32 characters"),
  name: z
    .string()
    .min(1, "Name is required")
    .max(64, "Password must have less than 64 characters"),
});
const Schema = registrationSchema;

const initialState = {
  name: "",
  email: "",
  password: "",
};

export default function RegistrationPage() {
  const router = useRouter();

  const [formData, setFormData] = useState(initialState);

  const [errorMessage, setErrorMessage] = useState("");

  const [isLoading, setIsLoading] = useState(false);

  const [fieldErrors, setFieldErrors] = useState({});

  function handleFieldChange(
    key: "name" | "email" | "password",
    value: string
  ) {
    let _formData = structuredClone(formData);
    _formData[key] = value;
    setFormData(_formData);

    const result = Schema.safeParse(_formData);
    if (result.success) {
      setFieldErrors({});
      return;
    }

    const _errors = result.error.flatten().fieldErrors;
    console.log(_errors);
    setFieldErrors(_errors);
  }

  async function handleSubmit(event: FormEvent) {
    try {
      event.preventDefault();

      setIsLoading(true);

      const validation = Schema.safeParse(formData);
      if (!validation.success) {
        const _errors = validation.error.flatten().fieldErrors;
        // console.log(_errors);
        setFieldErrors(_errors);
        return;
      }

      const registration = await apiKit({
        url: apis.register,
        method: "POST",
        body: formData,
      });

      toast(registration?.message, { type: toast.TYPE.SUCCESS });
      if (!registration) return;

      const result = (await signIn("credentials", {
        redirect: false,
        ...formData,
      })) as SignInResponse;

      // console.log("signIn", { result, registration });
      if (!result?.error) {
        const { admin_usersId } = registration.auth;
        router.replace(
          admin_usersId
            ? routes.adminUserUpdateById(admin_usersId)
            : routes.home
        );
      }

      if (result?.error === "CredentialsSignin") {
        toast("Invalid email or password", { type: toast.TYPE.ERROR });
        return;
      }
    } catch (error) {
      console.log("catch", error);
      if (error?.error === "MissingCredentials") {
        toast("Missing credentials", { type: toast.TYPE.ERROR });
      } else if (error?.error === "DuplicateCredentials") {
        toast("Duplicate credentials", { type: toast.TYPE.ERROR });
      } else {
        toast("An unexpected error occurred", { type: toast.TYPE.ERROR });
      }
      // console.log(Object.keys(error));
      // setFieldErrors({});
    } finally {
      setIsLoading(false);
    }
  }

  return (
    <div className="flex items-center justify-center h-screen bg-gray-100">
      <div className="w-full max-w-sm p-8 bg-white border rounded">
        <form onSubmit={handleSubmit}>
          <h5 className="text-xl font-black ">Register</h5>
          <br />

          <div className="mb-4">
            <Label
              className="block mb-1"
              htmlFor="register-name"
              value="Name"
            />
            <TextInput
              id="register-name"
              type="name"
              placeholder="name@flowbite.com"
              // color={fieldErrors?.name?.length ? "failure" : "gray"}
              // helperText={fieldErrors?.name?.[0]}
              value={formData.name}
              onChange={(e) => {
                handleFieldChange("name", e.target.value);
              }}
            />
          </div>

          <div className="mb-4">
            <Label
              className="block mb-1"
              htmlFor="register-eamil"
              value="Email"
            />
            <TextInput
              id="register-eamil"
              type="email"
              placeholder="name@flowbite.com"
              // color={fieldErrors?.email?.length ? "failure" : "gray"}
              // helperText={fieldErrors?.email?.[0]}
              value={formData.email}
              onChange={(e) => {
                handleFieldChange("email", e.target.value);
              }}
            />
          </div>

          <div className="mb-4">
            <div className="mb-1">
              <Label
                className="block mb-1"
                htmlFor="register-password"
                value="Password"
              />
              <TextInput
                id="register-password"
                type="password"
                // color={fieldErrors?.password?.length ? "failure" : "gray"}
                // helperText={fieldErrors?.password?.[0]}
                value={formData.password}
                onChange={(e) => {
                  handleFieldChange("password", e.target.value);
                }}
              />
            </div>
            {/* <div>
              <Checkbox id="register-show-hide-password" />
              <Label
                className="ml-2"
                htmlFor="register-show-hide-password"
                value="Show Password"
              />
            </div> */}
          </div>

          <br />
          <div className="flex justify-between items-center">
            <Button className="block" type="submit" disabled={isLoading}>
              Register
            </Button>
            <div className="text-right text-sm font-medium"></div>
          </div>

          <br />
          <div className="text-center text-sm font-medium">
            Already have account?{" "}
            <Link href="/login" className="hover:underline">
              Login here
            </Link>
          </div>
        </form>
      </div>
    </div>
  );
}
