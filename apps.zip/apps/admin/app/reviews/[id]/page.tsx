"use client";

import { useEffect } from "react";
import apiKit from "../../../utils/api.helper";
import { apis } from "../../../constants/apis";
import { useReviewStore } from "../../../store/zustand/review.store";
import ResourceLayout from "../../../layouts/resource-layout";
import UpdateReviewForm from "./update-review-form";

interface PageProps {
  params: {
    id: string;
  };
}

async function getReview(id: string) {
  return apiKit({
    api: apis.reviewById(id),
    showToast:false
  });
}

export default function ReviewPage({ params }: PageProps): JSX.Element {
  const { id } = params;

  const { review, setReview } = useReviewStore();

  console.log("update id", id);

  useEffect(() => {
    (async () => {
      const { review: _review } = await getReview(id);
      // console.log("review dataaa",_review);
      setReview(_review);
    })();
  }, [id, setReview]);
  //   console.log("end review",review);

  return (
    <main>
      <ResourceLayout label="update review">
        {review ? <UpdateReviewForm review={structuredClone(review)} /> : null}
      </ResourceLayout>
      <pre>{JSON.stringify(review, null, 2)}</pre>
    </main>
  );
}
