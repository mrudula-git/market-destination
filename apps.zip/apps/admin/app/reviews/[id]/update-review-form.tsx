import { useState } from "react";
import { Button } from "flowbite-react";
import { useMutation } from "@tanstack/react-query";
import { useParams } from "next/navigation";
import { apis } from "../../../constants/apis";
import apiKit from "../../../utils/api.helper";
import FormComposer from "../../../components/form-builder/form-composer";
import ResourceFormLayout from "../../../layouts/resource-form-layout";
import { useReviewStore } from "../../../store/zustand/review.store";
import FormComposer2 from "../../../components/form-builder/form-composer-2";

async function patchReview(id: string, body: any) {
  await apiKit({
    api: apis.reviewById(id),
    method: "PATCH",
    body,
    successMessage:"Review updated successfully",
    errorMessage:"Something went wrong. Review is not updated.",
  });
}

export default function UpdateReviewForm({ review }) {
  const { id } = useParams();

  const [state, setState] = useState(review);

  const mutation = useMutation({
    mutationKey: ["patchReview"],
    mutationFn: () => patchReview(id, state), // Pass 'id' and 'state' as arguments
  });

  return (
    <div>
      <ResourceFormLayout label="review details">
        <FormComposer2
          fields={[
            { name: "title", type: "string" },
            { name: "content", type: "string" },
            { name: "ratingValue", type: "number" },
          ]}
          onStateChange={(values) => {
            setState(values);
          }}
          state={state}
        />

        <br />
        <ResourceFormLayout label="more details">
          <FormComposer2
            fields={[
              { name: "comfortRating", type: "number" },
              { name: "cleanlinessRating", type: "number" },
            ]}
            onStateChange={(values) => {
              // console.log("onStateChange review value", values);
              setState({ ...state, details: values });
            }}
            state={state?.details}
          />
        </ResourceFormLayout>

        <br />
        <Button
          color="light"
          onClick={() => {
            mutation.mutate(state);
          }}
        >
          Update Review
        </Button>
      </ResourceFormLayout>
      <pre>{JSON.stringify(state, null, 2)}</pre>
    </div>
  );
}
