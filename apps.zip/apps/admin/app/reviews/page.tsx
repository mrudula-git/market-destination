"use client";

import { useQuery } from "@tanstack/react-query";
import { useEffect, useMemo, useState } from "react";
import { useSearchParams } from "next/navigation";
import DataTable from "../../components/table";
import apiKit from "../../utils/api.helper";
import { apis } from "../../constants/apis";
import { useCountStore } from "../../store/zustand/count.store";
import type { PageProps } from "../../constants/props.types";
import { Spinner } from "flowbite-react";

async function getReviews(query: any): Promise<any> {
  return apiKit({
    api: apis.reviews,
    query,
    showToast: false,
  });
}

export default function ReviewsPage(): JSX.Element {
  const searchParams = Object.fromEntries(useSearchParams());
  console.log("Reviews searchParams", { searchParams });

  const page = searchParams["page"];

  const {
    data: { reviews, count: _count } = {},
    isLoading,
    isError,
  } = useQuery({
    queryKey: ["reviews"],
    queryFn: () => getReviews({ page }),
  });

  const { count, setCount } = useCountStore();
  useEffect(() => {
    if (!_count) return;
    setCount(_count);
  }, [_count, setCount]);

  const searializeToTable = useMemo(() => {
    if (!reviews) return [];
    return reviews?.map((el) => ({
      id: el.id,
      title: el.title,
      reviewer: el.reviewer.name,
      ratings: el.ratingValue,
      content: el.content,
    }));
  }, [reviews]);

  if (isError) {
    return (
      <div>
        <h1>Internal Server Error</h1>
      </div>
    );
  }

  return (
    <div>
      {isLoading && (
        <div className="text-center justify-center mt-20">
          <Spinner aria-label="loader" size="xl" />
        </div>
      )}
      {!isLoading && (
        <DataTable data={searializeToTable} editFunction={undefined} />
      )}
    </div>
  );
}
