"use client";
import React from "react";
import apiKit from "../utils/api.helper";
import { apis } from "../constants/apis";
import { useQuery } from "@tanstack/react-query";
import { Spinner } from "flowbite-react";

export default function Dashboard(): JSX.Element {
  const { data, isLoading, isError } = useQuery({
    queryKey: ["dashboard"],
    queryFn: () => dashboardData(),
  });

  async function dashboardData() {
    try {
      const response = await apiKit({
        api: apis.dashboard,
        showToast: false,
      });
      return response;
    } catch (error) {
      console.error("Error fetching dashboard data", error);
      throw error;
    }
  }

  if (isLoading)
    return (
      <div className="text-center justify-center mt-20">
        <Spinner aria-label="loader" size="xl" />
      </div>
    );

  if (isError)
    return (
      <div>
        <h1>Internal Server Error</h1>
      </div>
    );

  const { listingsCount, reviewsCount } = data || {};

  const Card = ({ title, description }: any) => {
    return (
      <div className="flex-1 mt-5 max-w-md mx-2 scale-100 overflow-hidden bg-white rounded-lg shadow-lg">
        <div className="p-4">
          <h2 className="text-lg font-medium">{title}</h2>
          <p className="mt-2 text-4xl font-black">{description}</p>
        </div>
      </div>
    );
  };

  return (
    <main className="w-100">
      <div className="flex justify-center">
        <Card title="Listings" description={listingsCount} />
        <Card title="Reviews" description={reviewsCount} />
      </div>
    </main>
  );
}
