// import ImageKit from "imagekit";

// const imagekit = new ImageKit({
//     urlEndpoint: process.env.NEXT_PUBLIC_IMAGEKIT_URL as string,
//     privateKey: process.env.IMAGEKIT_PRIVATE_KEY as string,
//     publicKey: process.env.NEXT_PUBLIC_IMAGEKIT_PUBLIC_KEY as string,
// })

// export async function GET() {
//     const result = imagekit.getAuthenticationParameters();
//     const data = { ...result };
//     return Response.json(data);
// }