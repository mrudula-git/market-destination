import Link from "next/link";
import { routes } from "../constants/routes";

export default function Page404() {
  return (
    <>
      <meta name="robots" content="nofollow noindex" />

      <div className="bg-base0 h-[80vh]">
        <div className="max-w-screen-lg w-full h-full mx-auto px-2 flex justify-center items-center">
          <div>
            <p></p>
            <h4 className="text-3xl">Oh no. Page not found.</h4>
            <p className="text-xl">
              Sorry, the listing you are looking for could not be found.
            </p>
            <br />
            <div className="flex gap-2">
              Go to{" "}
              <Link
                className=" text-primary1 font-medium flex hover:underline"
                href={routes.listings}
              >
                <span className="mr-1">Manage</span>{" "}
                <span className="font-bold">Listings</span> <div>&#x2197;</div>
              </Link>{" "}
              or,{" "}
              <Link
                className="text-primary1 hover:underline font-medium flex"
                href={routes.home}
              >
                Home <div>&#x2197;</div>
              </Link>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
