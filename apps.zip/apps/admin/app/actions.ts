"use server";

import ImageKit from "imagekit";

export async function fetchGoogleMapsPlaces(query = "") {
  const baseURL = "https://maps.googleapis.com/maps/api/place/textsearch/json";
  // const fieldsArray = ["formatted_address", "name", "photo", "geometry"];
  // const fields = encodeURIComponent(fieldsArray.join(","));

  const qs = new URLSearchParams();
  qs.append("key", "AIzaSyBX63xfy8tGFKae5BpqANvuOZnPGzxnL8k");
  qs.append("inputtype", "textquery");
  qs.append("query", query);
  // qs.append("fields", fields);

  const url = baseURL + (qs.size ? `?${qs.toString()}` : ``);
  // console.log(url, "Google Maps textquery URL");
  const data = await (await fetch(url, { method: "GET" })).json();
  return data;
}

const IKUrlEndpoint = "https://ik.imagekit.io/va54lhjie";
const IKPublicKey = "public_NFO9yxYc/AKa6c62fqJ68KNOLJ0=";
const IKPrivateKey = "private_7/TC7TrmfZ3JeZuHzcad2cDwCx8=";

export async function deleteImageKitImage(fileId: string) {
  try {
    const ik = new ImageKit({
      urlEndpoint: IKUrlEndpoint,
      privateKey: IKPrivateKey,
      publicKey: IKPublicKey,
    });
    const response = await ik.deleteFile(fileId);
    console.log(response);
  } catch (error) {
    console.log("deleteImageKitImage", error);
  }
}
