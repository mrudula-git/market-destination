"use client";

import ResourceLayout from "../../../layouts/resource-layout";
import CreateAdminUserForm from "./create-admin-user-form";

export default function CreateAdminUserPage() {
  return (
    <div>
      {/* <div className="flex justify-between items-center">
        <h2>Create Admin</h2>
      </div> */}

      <br />
      <ResourceLayout label="create admin">
        <CreateAdminUserForm />
      </ResourceLayout>
    </div>
  );
}
