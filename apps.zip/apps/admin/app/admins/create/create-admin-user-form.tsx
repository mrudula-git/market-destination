import { Button } from "flowbite-react";
import { useState } from "react";
import FormComposer2 from "../../../components/form-builder/form-composer-2";
import { apis } from "../../../constants/apis";
import { routes } from "../../../constants/routes";
import ResourceFormLayout from "../../../layouts/resource-form-layout";
import apiKit from "../../../utils/api.helper";
import router from "next/router";
import { useFormik } from "formik";
import { useRouter } from "next/navigation";
import { validationSchema } from "../adminsUserValidationRules";
import { useMutation } from "@tanstack/react-query";

interface ContactDetails {
  primaryEmail: null | string;
  primaryPhoneNumber: null | string;
  secondaryEmail: null | string;
  secondaryPhoneNumber: null | string;
  country: null | string;
  city: null | string;
  district: null | string;
  state: null | string;
  pinCode: null | string;
  companyName: null | string;
}

interface State {
  name: null | string;
  activityDescription: null | string;
  position: null | string;
  active: boolean;
  contacts: ContactDetails;
}

const initialState: State = {
  name: "",
  activityDescription: "",
  position: "",
  active: false,
  contacts: {
    primaryEmail: "",
    primaryPhoneNumber: "",
    secondaryEmail: "",
    secondaryPhoneNumber: "",
    country: "India",
    city: "",
    district: "",
    state: "",
    pinCode: "",
    companyName: "",
  },
};

async function createAdminUser(body: State) {
  try {
    await apiKit({
      api: apis.adminusers,
      method: "POST",
      body,
      successMessage: "User created successfully",
      errorMessage: "Something went wrong. User is not created.",
    });
  } catch (error) {
    console.error("Error creating admin user:", error);
  }
}

export default function CreateAdminUserForm() {
  const [state, setState] = useState(initialState);
  const router = useRouter();

  const mutation = useMutation({
    mutationKey: ["createAdminUser"],
    mutationFn: (body) => createAdminUser(body),
    onSuccess: () => {
      // console.log("User updated successfully");
      router.replace(routes.adminUsers);
    },
    onError: (error) => {
      // console.error("Error updating user:", error);
    },
  });

  const formik = useFormik({
    initialValues: state,
    validationSchema: validationSchema,
    onSubmit: async (values): Promise<void> => {
      console.log("Submitting form with values:", values);
      try {
        await formik.validateForm();
        await mutation.mutate(values);
      } catch (error) {
        console.error("Validation error:", error);
      }
    },
  });
  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await formik.validateForm();
      await formik.submitForm();
      const errorField = document.querySelector('.error-message');
      if (errorField) {
        errorField.scrollIntoView({ behavior: 'smooth', block: 'center' });
      }
    } catch (error) {
      console.error("Validation error:", error);
    }
  };
  
  return (
    <div>
      <ResourceFormLayout label="user details">
        <FormComposer2
          fields={[
            {
              name: "name",
              type: "string",
              placeholder: "Enter your name",
              error: (formik.touched?.name && formik.errors?.name) || false,
              message: formik.errors?.name || "",
              requiredfield: true,
              onchange: (value: string) => {
                formik.setFieldTouched("name");
                formik.handleChange({ target: { name: "name", value } });
                formik.validateField("name");
              },
            },
            {
              name: "position",
              type: "string",
              placeholder: "Enter your position",
              error:
                (formik.touched?.position && formik.errors?.position) || false,
              message: formik.errors?.position || "",
              requiredfield: true,
              onchange: (value: string) => {
                formik.setFieldTouched("position");
                formik.handleChange({ target: { name: "position", value } });
                formik.validateField("position");
              },
            },
            {
              name: "active",
              type: "boolean",
              placeholder: "Select your status",
              // error: formik.touched?.active && !formik.values.active,
              // message: formik.errors?.active || "",
              onchange: (checked: boolean) => {
                formik.setFieldTouched("active");
                formik.handleChange({
                  target: { name: "active", value: checked },
                });
                formik.validateField("active");
              },
            },
          ]}
          onStateChange={(values) => {
            setState(values);
            formik.setValues({
              ...formik.values,
              name: values.name,
              activityDescription: values.activityDescription,
              position: values.position,
              active: values.active,
              contacts: values.contacts,
            });
          }}
          state={state}
        />

        <ResourceFormLayout label="contact details">
          <FormComposer2
            fields={[
              {
                name: "primaryEmail",
                type: "string",
                placeholder: "Enter your email",
                requiredfield: true,
                error:
                  (formik.touched?.contacts?.primaryEmail &&
                    formik.errors?.contacts?.primaryEmail) ||
                  false,
                message: formik.errors?.contacts?.primaryEmail || "",
                onchange: (value: string) => {
                  formik.setFieldTouched("contacts.primaryEmail");
                  formik.handleChange({
                    target: { name: "contacts.primaryEmail", value },
                  });
                  formik.validateField("contacts.primaryEmail");
                },
              },
              {
                name: "primaryPhoneNumber",
                type: "string",
                placeholder: "Enter your phone number",
                requiredfield: true,
                error:
                  (formik.touched?.contacts?.primaryPhoneNumber &&
                    formik.errors?.contacts?.primaryPhoneNumber) ||
                  false,
                message: formik.errors?.contacts?.primaryPhoneNumber || "",
                onchange: (value: string) => {
                  formik.setFieldTouched("contacts.primaryPhoneNumber");
                  formik.handleChange({
                    target: { name: "contacts.primaryPhoneNumber", value },
                  });
                  formik.validateField("contacts.primaryPhoneNumber");
                },
              },
              {
                name: "secondaryEmail",
                type: "string",
                placeholder: "Enter your email",
                error:
                  (formik.touched?.contacts?.secondaryEmail &&
                    formik.errors?.contacts?.secondaryEmail) ||
                  false,
                message: formik.errors?.contacts?.secondaryEmail || "",
                onchange: (value: string) => {
                  formik.setFieldTouched("contacts.secondaryEmail");
                  formik.handleChange({
                    target: { name: "contacts.secondaryEmail", value },
                  });
                  formik.validateField("contacts.secondaryEmail");
                },
              },
              {
                name: "secondaryPhoneNumber",
                type: "string",
                placeholder: "Enter your phone number",
                error:
                  (formik.touched?.contacts?.secondaryPhoneNumber &&
                    formik.errors?.contacts?.secondaryPhoneNumber) ||
                  false,
                message: formik.errors?.contacts?.secondaryPhoneNumber || "",
                onchange: (value: string) => {
                  formik.setFieldTouched("contacts.secondaryPhoneNumber");
                  formik.handleChange({
                    target: { name: "contacts.secondaryPhoneNumber", value },
                  });
                  formik.validateField("contacts.secondaryPhoneNumber");
                },
              },
              {
                name: "country",
                type: "string",
                placeholder: "Enter your country",
                requiredfield: true,
                error:
                  (formik.touched?.contacts?.country &&
                    formik.errors?.contacts?.country) ||
                  false,
                message: formik.errors?.contacts?.country || "",
                onchange: (value: string) => {
                  formik.setFieldTouched("contacts.country");
                  formik.handleChange({
                    target: { name: "contacts.country", value },
                  });
                  formik.validateField("contacts.country");
                },
              },
              {
                name: "city",
                type: "string",
                placeholder: "Enter your city",
                requiredfield: true,
                error:
                  (formik.touched?.contacts?.city &&
                    formik.errors?.contacts?.city) ||
                  false,
                message: formik.errors?.contacts?.city || "",
                onchange: (value: string) => {
                  formik.setFieldTouched("contacts.city");
                  formik.handleChange({
                    target: { name: "contacts.city", value },
                  });
                  formik.validateField("contacts.city");
                },
              },
              {
                name: "district",
                type: "string",
                requiredfield: true,
                placeholder: "Enter your district",
                error:
                  (formik.touched?.contacts?.district &&
                    formik.errors?.contacts?.district) ||
                  false,
                message: formik.errors?.contacts?.district || "",
                onchange: (value: string) => {
                  formik.setFieldTouched("contacts.district");
                  formik.handleChange({
                    target: { name: "contacts.district", value },
                  });
                  formik.validateField("contacts.district");
                },
              },
              {
                name: "state",
                type: "string",
                requiredfield: true,
                placeholder: "Enter your state",
                error:
                  (formik.touched?.contacts?.state &&
                    formik.errors?.contacts?.state) ||
                  false,
                message: formik.errors?.contacts?.state || "",
                onchange: (value: string) => {
                  formik.setFieldTouched("contacts.state");
                  formik.handleChange({
                    target: { name: "contacts.state", value },
                  });
                  formik.validateField("contacts.state");
                },
              },
              {
                name: "pinCode",
                type: "string",
                requiredfield: true,
                placeholder: "Enter your pincode sx.432109",
                error:
                  (formik.touched?.contacts?.pinCode &&
                    formik.errors?.contacts?.pinCode) ||
                  false,
                message: formik.errors?.contacts?.pinCode || "",
                onchange: (value: string) => {
                  formik.setFieldTouched("contacts.pinCode");
                  formik.handleChange({
                    target: { name: "contacts.pinCode", value },
                  });
                  formik.validateField("contacts.pinCode");
                },
              },
              {
                name: "companyName",
                type: "string",
                placeholder: "Enter your company name",
                requiredfield: true,
                error:
                  (formik.touched?.contacts?.companyName &&
                    formik.errors?.contacts?.companyName) ||
                  false,
                message: formik.errors?.contacts?.companyName || "",
                onchange: (value: string) => {
                  formik.setFieldTouched("contacts.companyName");
                  formik.handleChange({
                    target: { name: "contacts.companyName", value },
                  });
                  formik.validateField("contacts.companyName");
                },
              },
            ]}
            onStateChange={(values) => {
              setState((prevState) => ({ ...prevState, contacts: values }));
              formik.setValues({ ...formik.values, contacts: values });
            }}
            state={state.contacts}
          />
        </ResourceFormLayout>
        <br />
        <Button
          color="light"
          className={`${
            mutation.isPending
              ? "disabled:opacity-50 disabled:cursor-not-allowed bg-slate-400"
              : ""
          }`}
          onClick={handleSubmit}
          disabled={mutation.isPending}
        >
         {mutation.isPending ? 'Submitting...' : 'Submit'}
        </Button>
      </ResourceFormLayout>
    </div>
  );
}
