"use client";

import { useQuery } from "@tanstack/react-query";
import { Button, Spinner } from "flowbite-react";
import { useEffect, useMemo } from "react";
import DataTable from "../../components/table";
import { apis } from "../../constants/apis";
import { routes } from "../../constants/routes";
import { useCountStore } from "../../store/zustand/count.store";
import type { PageProps } from "../../constants/props.types";
import apiKit from "../../utils/api.helper";
import { useSearchParams } from "next/navigation";

async function getAdminUsers(query: {
  search?: string;
  page?: string | number;
}) {
  return apiKit({
    api: apis.adminusers,
    query,
    showToast: false,
  });
}

async function deleteAdminUsers(id: string) {
  return apiKit({
    api: apis.adminUserById(id),
  });
}

export default function AdminUserRootPage() {
  const searchParams = Object.fromEntries(useSearchParams());
  console.log("Admin searchParams", { searchParams });

  const { setCount } = useCountStore();

  const {
    isLoading,
    isError,
    data: { adminUsers, count } = {},
  } = useQuery({
    queryKey: ["adminusers"],
    queryFn: () => getAdminUsers(searchParams),
  });

  useEffect(() => {
    if (!count) return;
    setCount(count);
  }, [count, setCount]);

  const searializeToTable = useMemo(() => {
    return adminUsers?.map((el) => ({
      id: el.id,
      name: el.name,
    }));
  }, [adminUsers]);

  const onClickDelete: () => void = () => {};

  if (isError) {
    return (
      <div>
        <h1>Internal Server Error</h1>
      </div>
    );
  }

  return (
    <main>
      <div className="flex justify-between items-center">
        <h2>Admins</h2>
        <Button color="light" href={routes.adminUserCreate}>
          Create
        </Button>
      </div>
      {isLoading && (
        <div className="text-center justify-center mt-20">
          <Spinner aria-label="loader" size="xl" />
        </div>
      )}
      {!isLoading && (
        <DataTable data={searializeToTable} onClickDelete={onClickDelete} />
      )}
    </main>
  );
}
