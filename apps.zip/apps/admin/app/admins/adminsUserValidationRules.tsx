import * as yup from "yup";

export const validationSchema = yup.object().shape({
  name: yup
    .string()
    .trim()
    .min(2, "Name must be at least 2 characters")
    .max(1000, "Name must not exceed 1000 characters")
    .matches(/^[^\s].*[^\s]$/, "Name should not start or end with a space")
    .matches(/^[a-zA-Z\s]+$/, "Name should only contain letters and spaces")
    .required("Name is required"),
  position: yup.string().required("Position is required"),
  contacts: yup.object().shape({
    primaryEmail: yup
      .string()
      .required("Primary Email is required")
      .email("Enter a valid email address"),
      primaryPhoneNumber: yup
        .string()
        .required("Primary Phone Number is required")
        .matches(/^\d+$/, "Enter a valid phone number without country code")
        .matches(/^\d{7,12}$/, "Enter a valid phone number between 7 and 12 digits"),
    secondaryEmail: yup.string().email("Enter a valid email address").nullable(),
    secondaryPhoneNumber: yup.string()
    .matches(/^\d+$/, "Enter a valid phone number without country code").nullable()
    .matches(/^\d{7,12}$/, "Enter a valid phone number between 7 and 12 digits").nullable(),
    country: yup.string().required("Country is required"),
    city: yup.string().required("City is required"),
    district: yup.string().required("District is required"),
    state: yup.string().required("State is required"),
    pinCode: yup
      .string()
      .required("Pin Code is required")
      .matches(/^[0-9]+$/, "Pin Code should only contain numbers"),
    companyName: yup.string().required("Company Name is required"),
  }),
});
