"use client";

import { useQuery } from "@tanstack/react-query";
import { Button } from "flowbite-react";
import { useParams } from "next/navigation";
import { apis } from "../../../constants/apis";
import apiKit from "../../../utils/api.helper";
import ResourceLayout from "../../../layouts/resource-layout";
import UpdateAdminUserForm from "./update-admin-user-form";

async function getAdminUser(id: string) {
  return apiKit({
    api: apis.adminUserById(id),
    showToast:false
  });
}

export default function EditAdminUserPage() {
  const { id } = useParams();

  const { data: { adminUser } = {} } = useQuery({
    queryKey: ["adminuser"],
    queryFn: () => getAdminUser(id as string),
  });

  return (
    <div>
      {/* <div className="flex justify-between items-center">
        <h2>Admin User</h2>
      </div> */}

      <br />
      <ResourceLayout label="update admin">
        {adminUser ? <UpdateAdminUserForm adminUser={adminUser} /> : null}
      </ResourceLayout>
    </div>
  );
}
