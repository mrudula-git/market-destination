"use client";

import { useQuery } from "@tanstack/react-query";
import { Button } from "flowbite-react";
import { useEffect, useMemo } from "react";
import DataTable from "../../components/table";
import { routes } from "../../constants/routes";
import apiKit from "../../utils/api.helper";
import { apis } from "../../constants/apis";
import { useCountStore } from "../../store/zustand/count.store";
import type { PageProps } from "../../constants/props.types";

async function getcontacts(query: { search?: string; page?: string | number }) {
  return apiKit({
    api: apis.contacts,
    query,
    showToast: false,
  });
}

async function deletecontacts(id: string) {
  return apiKit({
    api: apis.adminUserById(id),
  });
}

export default function AdminUserRootPage({
  searchParams,
}: PageProps): Promise<JSX.Element> {
  const { data: { contacts, count: _count } = {} } = useQuery({
    queryKey: ["contacts"],
    queryFn: () => getcontacts(searchParams),
  });

  const OnClickDelete: () => void = () => {};
  const { count, setCount } = useCountStore();
  useEffect(() => {
    if (!_count) return;
    setCount(_count);
  }, [_count, setCount]);

  const searializeToTable = useMemo(() => {
    const formatter = new Intl.ListFormat("en", {
      style: "long",
      type: "conjunction",
    });
    return contacts?.map(
      (el: {
        UpdatedAt: any;
        createdAt: any;
        activityDescription: string;
        position: string;
        id: string;
        name: string;
      }) => ({
        id: el.id,
        name: el.name,
        position: el.position,
        activityDescription: el.activityDescription,
        createdAt: el.createdAt,
        UpdatedAt: el.UpdatedAt,
      })
    );
  }, [contacts]);

  const user = contacts?.map((el) => ({
    id: el.id,
  }));

  return Promise.resolve(
    <main>
      <h2>Contacts</h2>
      {contacts?.length > 0 && (
        <DataTable data={searializeToTable} onClickDelete={OnClickDelete} />
      )}
    </main>
  );
}
