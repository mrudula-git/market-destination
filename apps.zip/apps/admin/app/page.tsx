import { NextApiRequest } from "next";
import { Suspense } from "react";
import Dashboard from "./dashboard";

export default async function Page(req: NextApiRequest) {
  return (
    <main className="w-100">
      <Suspense>
        <Dashboard />
      </Suspense>
    </main>
  );
}
