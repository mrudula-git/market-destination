"use client";

import React, { useEffect, useMemo } from 'react'
import { useQuery } from "@tanstack/react-query";
import { Button, Spinner } from "flowbite-react";
import DataTable from "../../components/table";
import { apis } from "../../constants/apis";
import { routes } from "../../constants/routes";
import { useCountStore } from "../../store/zustand/count.store";
import type { PageProps } from "../../constants/props.types";
import apiKit from "../../utils/api.helper";
import { useSearchParams } from "next/navigation";

async function getFeedback(query: {
    search?: string;
    page?: string | number;
  }) {
    return apiKit({
      api: apis.feedback,  
      query,
      showToast: false,
    });
  }

  async function deleteFeedback(id: string) {
    return apiKit({
      api: apis.feedbackById(id),  
    });
  }

  export default function FeedbackRootPage() {
    const searchParams = Object.fromEntries(useSearchParams());
    console.log("Feedback searchParams", { searchParams });
  
    const { setCount } = useCountStore();
  
    const {
      isLoading,
      isError,
      data: { feedback, count } = {},
    } = useQuery({
      queryKey: ["feedback"],
      queryFn: () => getFeedback(searchParams),
    });
  
    useEffect(() => {
      if (!count) return;
      setCount(count);
    }, [count, setCount]);
  
    const searializeToTable = useMemo(() => {
      return feedback?.map((el) => ({
        id: el.id,
        name: el.name,
        email: el.email,
        phone: el.phone,
        message: el.message,
        source: el.source,
      }));
    }, [feedback]);
  
    const onClickDelete: (id: string) => void = (id) => {
      deleteFeedback(id);
    };
  
    if (isError) {
      return (
        <div>
          <h1>Internal Server Error</h1>
        </div>
      );
    }
  
    return (
      <main>
        <div className="flex justify-between items-center">
          <h2>Feedback</h2>
          {/* <Button color="light" href={routes.feedbackCreate}>
            Create
          </Button> */}
        </div>
        {isLoading && (
          <div className="text-center justify-center mt-20">
            <Spinner aria-label="loader" size="xl" />
          </div>
        )}
        {!isLoading && (
          <DataTable data={searializeToTable} onClickDelete={onClickDelete} />
        )}
      </main>
    );
  }