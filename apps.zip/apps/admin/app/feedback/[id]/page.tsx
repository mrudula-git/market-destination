"use client"

import { useQuery } from "@tanstack/react-query";
import { useParams } from "next/navigation";
import { apis } from "../../../constants/apis";
import apiKit from "../../../utils/api.helper";
import ResourceLayout from "../../../layouts/resource-layout";
import UpdateFeedbackForm from "./update-feedback-form";

async function getFeedback(id: string) {
    return apiKit({
      api: apis.feedbackById(id),
      showToast: false,
    });
  }
  
  export default function EditFeedbackPage() {
    const { id } = useParams();
  
    const { data: { feedback } = {} } = useQuery({
      queryKey: ["feedback"],
      queryFn: () => getFeedback(id as string),
    });
  
    return (
      <div>
        {/* <div className="flex justify-between items-center">
          <h2>Feedback</h2>
        </div> */}
  
        <br />
        <ResourceLayout label="Update Feedback">
          {feedback ? <UpdateFeedbackForm feedback={feedback} /> : null}
        </ResourceLayout>
      </div>
    );
  }
  