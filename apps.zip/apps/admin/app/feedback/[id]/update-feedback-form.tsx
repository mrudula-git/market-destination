"use client"

import { Button } from "flowbite-react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { useState } from "react";
import FormComposer2 from "../../../components/form-builder/form-composer-2";
// import { apis } from "../../../constants/apis";
import ResourceFormLayout from "../../../layouts/resource-form-layout";
// import apiKit from "../../../utils/api.helper";
import { routes } from "../../../constants/routes";
import { useFormik } from "formik";
import { useRouter } from "next/navigation";
import { validationSchema } from "../../admins/adminsUserValidationRules";

// async function patchFeedback(id: string, body) {
//     console.log("Updating feedback with ID:", id);
//     console.log("Update payload:", body);
  
//     try {
//       const response = await apiKit({
//         api: apis.feedbackById(id),
//         method: "PATCH",
//         body,
//         successMessage: "Feedback updated successfully",
//         errorMessage: "Something went wrong. Feedback is not updated.",
//       });
  
//       console.log("Update successful. Response:", response);
  
//       return response;
//     } catch (error) {
//       console.error("Error updating feedback:", error);
//       throw error; 
//     }
//   }
  
  export default function UpdateFeedbackForm({ feedback }) {
    const [state, setState] = useState(feedback);
    const router = useRouter();
  
    const mutation = useMutation({
      mutationKey: ["patchFeedback"],
      mutationFn: (body) => patchFeedback(state.id, body),
      onSuccess: (data) => {
        console.log("Mutation success:", data);
        router.replace(routes.feedback); 
      },
      onError: (error) => {
        console.error("Error updating feedback:", error);
      },
    });
  
    const formik = useFormik({
      initialValues: state,
      validationSchema: validationSchema,  
      onSubmit: async (values): Promise<void> => {
        try {
          console.log("Submitting form with values:", values);
          await formik.validateForm();
          await mutation.mutate(values);
        } catch (error) {
          console.error("Validation error:", error);
        }
      },
    });
  
    // const handleSubmit = async (e) => {
        
    //   e.preventDefault();
    //   console.log("Submit button clicked");
    //   try {
    //     await formik.validateForm();
    //     await formik.submitForm();
    //     const errorField = document.querySelector('.error-message');
    //     if (errorField) {
    //       errorField.scrollIntoView({ behavior: 'smooth', block: 'center' });
    //     }
    //   } catch (error) {
    //     console.error("Validation error:", error);
    //   }
    // };
  
    return (
      <div>
        <ResourceFormLayout label="Feedback Details">
          <FormComposer2
            fields={[
              {
                name: "name",
                type: "string",
                placeholder: "Enter your name",
                error: (formik.touched?.name && formik.errors?.name) || false,
                message: formik.errors?.name || "",
                requiredfield: true,
                onchange: (value: string) => {
                  formik.setFieldTouched("name");
                  formik.handleChange({ target: { name: "name", value } });
                  formik.validateField("name");
                },
              },
              {
                name: "email",
                type: "string",
                placeholder: "Enter your email",
                error: (formik.touched?.email && formik.errors?.email) || false,
                message: formik.errors?.email || "",
                requiredfield: true,
                onchange: (value: string) => {
                  formik.setFieldTouched("email");
                  formik.handleChange({ target: { name: "email", value } });
                  formik.validateField("email");
                },
              },
              {
                name: "message",
                type: "string",
                placeholder: "Enter your message",
                error: (formik.touched?.message && formik.errors?.message) || false,
                message: formik.errors?.message || "",
                requiredfield: true,
                onchange: (value: string) => {
                  formik.setFieldTouched("message");
                  formik.handleChange({ target: { name: "message", value } });
                  formik.validateField("message");
                },
              },
              {
                name: "source",
                type: "string",
                placeholder: "Enter the source",
                error: (formik.touched?.source && formik.errors?.source) || false,
                message: formik.errors?.source || "",
                requiredfield: true,
                onchange: (value: string) => {
                  formik.setFieldTouched("source");
                  formik.handleChange({ target: { name: "source", value } });
                  formik.validateField("source");
                },
              },
            ]}
            onStateChange={(values) => {
              setState(values);
              formik.setValues({
                ...formik.values,
                name: values.name,
                email: values.email,
                message: values.message,
                source: values.source,
              });
            }}
            state={state}
          />
        </ResourceFormLayout>
        <br />
        {/* <Button
          type="submit"
          color="light"
          onClick={handleSubmit}
        >
          Submit
        </Button> */}
      </div>
    );
  }
  