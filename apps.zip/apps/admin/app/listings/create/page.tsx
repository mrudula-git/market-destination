"use client";

import ResourceLayout from "../../../layouts/resource-layout";
import CreateListingsForm from "./create-listing-form";

export default function CreateListingsPage() {
  return (
    <div>
      <ResourceLayout label="create listing">
        <CreateListingsForm />
      </ResourceLayout>
    </div>
  );
}
