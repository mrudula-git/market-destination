import * as yup from "yup";

export const validationSchema = yup.object().shape({
    name: yup
      .string()
      .required("Name is required")
      .trim()
      .min(2, "Name must be at least 2 characters")
      .max(1000, "Name must not exceed 1000 characters")
      .matches(/^[^\s].*[^\s]$/, "Name should not start or end with a space"),

    googleRating: yup
    .number()
    .min(1, "Google Rating should be at least 1")
    .max(5, "Google Rating should not exceed 5")
        // .oneOf([1, 2, 3, 4, 5], "Google Rating should be 1, 2, 3, 4, or 5").nullable(),
    .nullable(),

    categories: yup.array().required("Categories are required"),
    attributeGroups: yup.array().required("Attribute Groups are required"),
  
    contacts: yup.object().shape({
      primaryEmail: yup
        .string()
        .required("Primary Email is required")
        .email("Enter a valid email address"),
      primaryPhoneNumber: yup
        .string()
        .required("Primary Phone Number is required")
        .matches(/^\d+$/, "Enter a valid phone number without country code")
        .matches(/^\d{7,12}$/, "Enter a valid phone number between 7 and 12 digits"),
      }),
  
    // tags: yup.array().required("Tags are required"),
    // keywords: yup.array().required("Keywords are required"),
    // languages: yup.array().required("Languages are required"),
    // travelInstructions: yup.array().required("Travel Instructions are required"),
    // thingsToDo: yup.array().required("Things to Do are required"),
    // operationalTimings: yup.array().required("Operational Timings are required"),
    // bestTimings: yup.array().required("Best Timings are required"),
  });