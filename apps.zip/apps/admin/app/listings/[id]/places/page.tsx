"use client";

import { useEffect, useState } from "react";
import ListingTabLayout from "../../../../layouts/listing-tab-layout";
import { useListingStore } from "../../../../store/zustand/listings.store";
import ResourceLayout from "../../../../layouts/resource-layout";
import UpdatePlaceForm from "./update-place-form";
import CreatePlaceForm from "./create-place-form";
import LocationForm from "./location-form";

export default function PlacesPage() {
  const { listing } = useListingStore();

  const [places, setPlaces] = useState();
  const [location, setLocation] = useState();

  useEffect(() => {
    setPlaces(listing?.places);
  }, [listing?.places]);

  useEffect(() => {
    setLocation(listing?.location);
  }, [listing?.location]);

  return (
    <div>
      <ListingTabLayout activeKey="listing_places" />

      <br />
      <ResourceLayout label="update listing location">
        <LocationForm location={location} />
      </ResourceLayout>

      <br />
      <hr />
      <br />
      <ResourceLayout label="update nearby places">
        {places?.length > 0 &&
          places?.map((place) => (
            <div className="mb-4" key={place.id}>
              {place ? <UpdatePlaceForm place={place} /> : null}
            </div>
          ))}
      </ResourceLayout>
      {/* <pre>{JSON.stringify(places, null, 2)}</pre> */}

      <br />
      <hr />
      <br />
      <ResourceLayout label="create nearby places">
        <CreatePlaceForm />
      </ResourceLayout>
    </div>
  );
}
