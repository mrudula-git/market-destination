import { useEffect, useState } from "react";
import { Button } from "flowbite-react";
import { useParams } from "next/navigation";
import { useMutation } from "@tanstack/react-query";
import ResourceFormLayout from "../../../../layouts/resource-form-layout";
import FormComposer2 from "../../../../components/form-builder/form-composer-2";
import apiKit from "../../../../utils/api.helper";
import { apis } from "../../../../constants/apis";
import GooglePlacesAutocomplete from "../../../../components/forms/google-places-autocomplete";

const initialState = {
  name: "",
  placeId: "",
  lat: null,
  lng: null,
};

function patchListingLocation(id: string, body) {
  return apiKit({
    api: apis.locationOflistingById(id),
    method: "PATCH",
    body,
    successMessage: "Place updated successfully",
    errorMessage: "Something went wrong. Place is not updated.",
  });
}

export default function LocationForm({ location }) {
  const { id: listingId } = useParams();

  const [state, setState] = useState(initialState);

  const mutation = useMutation({
    mutationKey: "patchListingLocation",
    mutationFn: (body) => patchListingLocation(listingId, body),
  });

  useEffect(() => {
    if (!location) return;
    setState(location);
  }, [location]);

  return (
    <div>
      <ResourceFormLayout label="location details" nested>
        <GooglePlacesAutocomplete
          onSelectionChange={(values) => {
            // console.log(values);

            setState({ ...state, ...values });
          }}
        />
        <br />

        <FormComposer2
          fields={[
            { name: "name", type: "string" ,placeholder: "Fill in this value automatically"},
            { name: "lat", type: "number",placeholder: "Fill in this value automatically" },
            { name: "lng", type: "number",placeholder: "Fill in this value automatically" },
          ]}
          initialState={initialState}
          onStateChange={(values) => {
            // console.log("onStateChange", values);
            setState(values);
          }}
          state={state}
        />
        <Button
          color="light"
          className={`${
            mutation.isPending
              ? "disabled:opacity-50 disabled:cursor-not-allowed bg-slate-400"
              : ""
          }`}
          disabled={mutation.isPending}
          onClick={() => {
            mutation.mutate(state);
          }}
        >
        {mutation.isPending ? 'Updating...' : 'Update Location'}
        </Button>
      </ResourceFormLayout>
    </div>
  );
}
