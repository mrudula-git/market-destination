import { useMutation } from "@tanstack/react-query";
import { Button } from "flowbite-react";
import { useParams } from "next/navigation";
import { useState } from "react";
import FormComposer2 from "../../../../components/form-builder/form-composer-2";
import GooglePlacesAutocomplete from "../../../../components/forms/google-places-autocomplete";
import { apis } from "../../../../constants/apis";
import ResourceFormLayout from "../../../../layouts/resource-form-layout";
import apiKit from "../../../../utils/api.helper";

const initialState = {
  name: "",
  location: {
    name: "",
    placeId: "",
    lat: null,
    lng: null,
  },
};

function postListingPlaces(id: string, body) {
  return apiKit({
    api: apis.placesOflistingById(id),
    method: "POST",
    body,
    successMessage: "Place added successfully",
    errorMessage: "Something went wrong. Place is not added.",
  });
}

export default function CreatePlaceForm() {
  const { id } = useParams();

  const [state, setState] = useState(initialState);

  const mutation = useMutation({
    mutationKey: ["postListingAttributes"],
    mutationFn: (body) => postListingPlaces(id, body),
  });

  return (
    <div>
      <ResourceFormLayout label="place details">
        <FormComposer2
          fields={[
            {
              name: "name",
              type: "string",
              placeholder: "Enter your place name",
            },
          ]}
          onStateChange={(values) => {
            // console.log("onStateChange", values);
            setState(values);
          }}
          state={state}
        />

        <br />
        <ResourceFormLayout label="location details" nested>
          <GooglePlacesAutocomplete
            onSelectionChange={(values) => {
              setState({ ...state, name: values.name, location: values });
            }}
          />
          <br />

          <FormComposer2
            fields={[
              {
                name: "name",
                type: "string",
                placeholder: "Fill in this value automatically",
              },
              {
                name: "lat",
                type: "number",
                placeholder: "Fill in this value automatically",
              },
              {
                name: "lng",
                type: "number",
                placeholder: "Fill in this value automatically",
              },
            ]}
            onStateChange={(values) => {
              // console.log("onStateChange", values);
              setState({ ...state, location: values });
            }}
            state={state.location}
          />
        </ResourceFormLayout>

        <br />
        <Button
          color="light"
          className={`${
            mutation.isPending
              ? "disabled:opacity-50 disabled:cursor-not-allowed bg-slate-400"
              : ""
          }`}
          disabled={mutation.isPending}
          onClick={() => {
            // console.log(state);
            mutation.mutate(state);
            location.reload();
          }}
        >
        {mutation.isPending ? 'Saving...' : 'Save Place'}
        </Button>
      </ResourceFormLayout>
      {/* <pre>{JSON.stringify(state, null, 2)}</pre> */}
    </div>
  );
}
