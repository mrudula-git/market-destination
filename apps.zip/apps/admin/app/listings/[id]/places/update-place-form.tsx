import { useState } from "react";
import { Button } from "flowbite-react";
import { useMutation } from "@tanstack/react-query";
import { useParams } from "next/navigation";
import FormComposer from "../../../../components/form-builder/form-composer";
import apiKit from "../../../../utils/api.helper";
import { apis } from "../../../../constants/apis";
import ResourceFormLayout from "../../../../layouts/resource-form-layout";
import FormComposer2 from "../../../../components/form-builder/form-composer-2";
import GooglePlacesAutocomplete from "../../../../components/forms/google-places-autocomplete";

function postListingPlaces(id: string, listingId: string, body) {
  return apiKit({
    api: apis.placeByIdOflistingById(id, listingId),
    method: "PATCH",
    body,
    successMessage: "Place updated successfully",
    errorMessage: "Something went wrong. Place is not updated.",
  });
}

export default function UpdatePlaceForm({ place }) {
  const { id: listingId } = useParams();

  const [state, setState] = useState(place);

  const mutation = useMutation({
    mutationKey: ["postListingAttributes"],
    mutationFn: (body) => postListingPlaces(body.id, listingId, body),
  });

  return (
    <div>
      <ResourceFormLayout label="place details">
        <FormComposer2
          fields={[{ name: "name", type: "string" ,placeholder: "Enter your place name"}]}
          onStateChange={(values) => {
            // console.log("onStateChange", values);
            setState(values);
          }}
          state={state}
        />

        <br />
        <ResourceFormLayout label="location details" nested>
          <GooglePlacesAutocomplete
            onSelectionChange={(values) => {
              // console.log(values);

              setState({ ...state, ...values });
            }}
          />
          <br />

          <FormComposer2
            fields={[
              { name: "name", type: "string" ,placeholder: "Fill in this value automatically"},
              { name: "lat", type: "number",placeholder: "Fill in this value automatically" },
              { name: "lng", type: "number",placeholder: "Fill in this value automatically"},
            ]}
            onStateChange={(values) => {
              // console.log("onStateChange", values);
              setState({ ...state, location: values });
            }}
            state={state.location}
          />
        </ResourceFormLayout>

        <br />
        <Button
          color="light"
          className={`${
            mutation.isPending
              ? "disabled:opacity-50 disabled:cursor-not-allowed bg-slate-400"
              : ""
          }`}
          onClick={() => {
            // console.log(state);
            mutation.mutate(state);
          }}
          disabled={mutation.isPending}
        >
        {mutation.isPending ? 'Updating...' : 'Update place'}
        </Button>
      </ResourceFormLayout>

      {/* <pre>{JSON.stringify(state, null, 2)}</pre> */}
    </div>
  );
}
