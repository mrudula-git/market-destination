import ListingsFetcher from "../../../components/listings-fetcher";
import TabContentNavigation from "../../../components/tab-content-navigation";
import { routes } from "../../../constants/routes";

export default function ListingRootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <main>
      <ListingsFetcher />
      <div className="mb-4" />
      <div>{children}</div>
    </main>
  );
}
