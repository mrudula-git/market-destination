"use client";

import { apis } from "../../../../constants/apis";
import ListingTabLayout from "../../../../layouts/listing-tab-layout";
import ResourceLayout from "../../../../layouts/resource-layout";
import { useListingStore } from "../../../../store/zustand/listings.store";
import apiKit from "../../../../utils/api.helper";
import CreatePackagesForm from "./create-packages-form";
import UpdatePackageForm from "./update-package-form";

async function getPackages(id: string) {
  return apiKit({
    api: apis.packagesOflistingById(id),
    showToast:false
  });
}
interface PageProps {
  params: {
    id: string;
  };
}
export default function PackagesPage({ params }: PageProps): JSX.Element {
  const { id } = params;
  // const { packages, setPackages } = usePackagesStore();

  const { listing } = useListingStore();

  // useEffect(() => {
  //   (async () => {
  //     const { packages: packagesData } = await getPackages(id);
  //     setPackages(packagesData);
  //   })();
  // }, []);

  return (
    <div>
      <ListingTabLayout activeKey="listing_packages" />

      <br />
      <ResourceLayout label="update packages">
        {listing?.packages?.map((_package) => (
          <div key={_package.id}>
            <UpdatePackageForm _package={_package} />
            {/* <pre>{JSON.stringify(_package, null, 2)}</pre> */}
          </div>
        ))}
      </ResourceLayout>

      <br />
      <hr />
      <br />
      <ResourceLayout label="create package">
        <CreatePackagesForm />
      </ResourceLayout>
    </div>
  );
}
