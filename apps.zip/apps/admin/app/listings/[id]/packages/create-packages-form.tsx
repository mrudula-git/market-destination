import { Button } from "flowbite-react";
import { useParams } from "next/navigation";
import { useState } from "react";
import FormComposer2 from "../../../../components/form-builder/form-composer-2";
import { apis } from "../../../../constants/apis";
import ResourceFormLayout from "../../../../layouts/resource-form-layout";
import { useListingStore } from "../../../../store/zustand/listings.store";
import apiKit from "../../../../utils/api.helper";

const initialState = {
  name: null,
  persons: null,
  duration: null,
  price: {
    amount: null,
    discount: null,
    currency: "INR",
    // available: true,
  },
};

export default function CreatePackagesForm() {
  const { id } = useParams();

  const { listing } = useListingStore();
  const [state, setState] = useState(initialState);
  const [loading, setLoading] = useState(false); 


  async function createPackages(id: string) {
    setLoading(true);
    try {
      const data = await apiKit({
        api: apis.packagesOflistingById(id),
        method: "POST",
        body: state,
        successMessage: "Package added successfully",
        errorMessage: "Something went wrong. Package is not added.",
      });
      console.log(data);
      location.reload();
    } catch (error) {
      console.error("Error creating package:", error);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div>
      <ResourceFormLayout label="package details">
        <FormComposer2
          fields={[
            { name: "name", type: "string", placeholder: "Enter package name" },
            {
              name: "persons",
              type: "number",
              placeholder: "Enter total no of persons",
            },
            {
              name: "duration",
              type: "string",
              placeholder: "Enter duration ex.9 am to 5pm ",
            },
          ]}
          onStateChange={(values) => {
            console.log("onStateChange", values);
            setState(values);
          }}
          state={state}
        />

        <br />
        <ResourceFormLayout label="price details" nested>
          <FormComposer2
            fields={[
              {
                name: "amount",
                type: "number",
                placeholder: "Enter package amount",
              },
              {
                name: "discount",
                type: "number",
                placeholder: "Enter package discount",
              },
              {
                name: "currency",
                type: "string",
                placeholder: "Enter currency ex.INR",
              },
              {
                name: "available",
                type: "boolean",
                placeholder: "is package available",
              },
            ]}
            onStateChange={(values) => {
              // console.log("onStateChange", values);
              setState({ ...state, price: values });
            }}
            state={state.price}
          />
        </ResourceFormLayout>

        <br />
        <div>
          <Button
            color="light"
            onClick={() => {
              createPackages(id);
            }}
            className={`${
              loading
                ? "disabled:opacity-50 disabled:cursor-not-allowed bg-slate-400"
                : ""
            }`}
            disabled={loading} 
          >
          {loading ? 'Creating...' : 'Create Packages'}
          </Button>
        </div>
      </ResourceFormLayout>

      {/* <pre>{JSON.stringify(listing?.packages, null, 2)}</pre> */}
    </div>
  );
}
