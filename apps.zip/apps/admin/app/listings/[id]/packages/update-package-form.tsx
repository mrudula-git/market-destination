import { Button } from "flowbite-react";
import { useParams } from "next/navigation";
import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { useListingStore } from "../../../../store/zustand/listings.store";
import FormComposer2 from "../../../../components/form-builder/form-composer-2";
import ResourceFormLayout from "../../../../layouts/resource-form-layout";
import apiKit from "../../../../utils/api.helper";
import { apis } from "../../../../constants/apis";

async function patchListingPackage(id: string, listingId: string, body) {
  return apiKit({
    api: apis.packageByIdOflistingById(id, listingId),
    method: "PATCH",
    body,
    successMessage:"Package updated successfully",
    errorMessage:"Something went wrong. Package is not updated.",
  });
}

export default function UpdatePackageForm({ _package }) {
  const { id: listingId } = useParams();

  const { listing } = useListingStore();

  const [state, setState] = useState(_package);

  const mutation = useMutation({
    mutationKey: ["patchListingPackage"],
    mutationFn: (body) => patchListingPackage(body.id, listingId, body),
  });

  return (
    <div className="my-4">
      <ResourceFormLayout label="package details">
        <FormComposer2
          fields={[
            { name: "name", type: "string",placeholder:"Enter package name"},
            { name: "persons", type: "number",placeholder:"Enter total no of persons"},
            { name: "duration", type: "string",placeholder: "Enter duration ex.9 am to 5pm "},
          ]}
          onStateChange={(values) => {
            // console.log("onStateChange", values);
            setState(values);
          }}
          state={state}
        />

        <br />
        <ResourceFormLayout label="price details">
          <FormComposer2
            fields={[
              { name: "amount", type: "number",placeholder:"Enter package amount" },
              { name: "discount", type: "number",placeholder:"Enter package discount" },
              { name: "currency", type: "string" ,placeholder:"Enter currency ex.INR"},
              { name: "available", type: "boolean",placeholder:"is package available" },
            ]}
            onStateChange={(values) => {
              // console.log("onStateChange", values);
              setState({ ...state, price: values });
            }}
            state={state?.price}
          />
        </ResourceFormLayout>

        <br />
        <Button
          color="light"
          disabled={mutation.isPending}
          onClick={() => {
            mutation.mutate(state);
          }}
          className={`${
            mutation.isPending
              ? "disabled:opacity-50 disabled:cursor-not-allowed bg-slate-400"
              : ""
          }`}
        >
          {mutation.isPending ? 'Updating...' : 'Update Packages'}
        </Button>
      </ResourceFormLayout>
      {/* <pre>{JSON.stringify(state, null, 2)}</pre> */}
    </div>
  );
}
