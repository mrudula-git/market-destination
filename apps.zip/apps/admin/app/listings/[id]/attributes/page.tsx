"use client";

import { useMutation } from "@tanstack/react-query";
import { useParams } from "next/navigation";
import { Suspense, useState } from "react";
import { Button } from "flowbite-react";
import AttributesForm from "../../../../components/form-builder/attributes-form";
import { apis } from "../../../../constants/apis";
import ListingTabLayout from "../../../../layouts/listing-tab-layout";
import { useListingStore } from "../../../../store/zustand/listings.store";
import apiKit from "../../../../utils/api.helper";
import Loading from "../../../../components/ui/Loading";

async function putListingAttributes(id: string, body) {
  const results = apiKit({
    api: apis.attributesOflistingById(id),
    method: "PUT",
    body,
    successMessage: "Attribute updated successfully",
    errorMessage: "Something went wrong. Attribute is not updated.",
  });
  return results;
}

export default function AttributesPage() {
  const { id } = useParams();

  const [attributes, setAttributes] = useState();

  const mutation = useMutation({
    mutationKey: ["putListingAttributes"],
    mutationFn: (body) => putListingAttributes(id, body),
  });

  return (
    <div>
      <ListingTabLayout activeKey="listing_attributes" />

      <Suspense fallback={<Loading />}>
        <AttributesForm
          onChange={(values) => {
            console.log("attribute change", values);
            setAttributes(values);
          }}
          onCompleteSave={(values) => {
            console.log(values, "all category changes");
            mutation.mutate({ attributes: values });
          }}
          onSectionSave={(values, id) => {
            console.log(values, "for category", id);
            mutation.mutate({ attributes: values });
          }}
          disabled={mutation.isPending}

        />
      </Suspense>
    </div>
  );
}
