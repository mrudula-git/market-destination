"use client";

import ListingTabLayout from "../../../../../layouts/listing-tab-layout";
import UpdateBadgesForm from "../create-badges-form";
import { useBadgesStore } from "../../../../../store/zustand/categories.store";

export default function PackagesPage() {
  // const { badges, setBadges } = useBadgesStore();

  return (
    <div>
      <ListingTabLayout activeKey="listing_badges" />
      <UpdateBadgesForm />
    </div>
  );
}
