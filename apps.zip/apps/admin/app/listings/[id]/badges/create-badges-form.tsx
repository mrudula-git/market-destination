import { Button } from "flowbite-react";
import { useParams } from "next/navigation";
import { useState } from "react";
import FormComposer2 from "../../../../components/form-builder/form-composer-2";
import { apis } from "../../../../constants/apis";
import ResourceFormLayout from "../../../../layouts/resource-form-layout";
import apiKit from "../../../../utils/api.helper";

const initialState = {
  name: null,
};

export default function CreateBadgesForm() {
  const { id } = useParams();
  const [state, setState] = useState(initialState);
  const [loading, setLoading] = useState(false); 

  async function createBadges(id: string) {
    setLoading(true);
    try {
      const data = await apiKit({
        api: apis.badgesOflistingById(id),
        method: "POST",
        body: state,
        successMessage:"Badges created successfully",
        errorMessage:"Something went wrong. Badges were not created.",
      });
      console.log(data);
    } catch (error) {
      console.error("Error creating badges:", error);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div>
      <ResourceFormLayout label="badge details">
        <FormComposer2
          fields={[{ name: "name", type: "string" }]}
          onStateChange={(values) => {
            // console.log("onStateChange", values);
            setState(values);
          }}
          state={state}
        />

        <br />
        <Button
          color="gray"
          className={`${
            loading
              ? "disabled:opacity-50 disabled:cursor-not-allowed bg-slate-400"
              : ""
          }`}
          onClick={() => {
            createBadges(id);
          }}
          disabled={loading}
        >
         {loading ? 'Creating...' : 'Create Badge'}
        </Button>
      </ResourceFormLayout>
    </div>
  );
}
