"use client";

import ListingTabLayout from "../../../../layouts/listing-tab-layout";
import ResourceLayout from "../../../../layouts/resource-layout";
import CreateBadgesForm from "./create-badges-form";

export default function PackagesPage() {
  // const { badges, setBadges } = useBadgesStore();

  return (
    <div>
      <ListingTabLayout activeKey="listing_badges" />

      <br />
      <ResourceLayout label="update badges">
        <></>
      </ResourceLayout>

      <br />
      <hr />
      <br />
      <ResourceLayout label="create badges">
        <CreateBadgesForm />
      </ResourceLayout>
    </div>
  );
}
