"use client";

import { useEffect, useState } from "react";
import ListingTabLayout from "../../../layouts/listing-tab-layout";
import ResourceLayout from "../../../layouts/resource-layout";
import { useListingStore } from "../../../store/zustand/listings.store";
import UpdateListingForm from "./update-listing-form";
import { Spinner } from "flowbite-react";

export default function ListingRootPage(): JSX.Element {
  const { listing } = useListingStore();

  const [, setAttributes] = useState(listing?.attributes);

  useEffect(() => {
    if (!listing?.attributes) return;
    setAttributes(listing.attributes ?? []);
  }, [listing?.attributes, setAttributes]);

  // function handleAttributesChange(attribute, value) {
  //   const { id, name, type } = attribute;
  //   const _attributes = structuredClone(attributes);
  //   const _attributeIx = _attributes.findIndex((el) => el.id === id);
  //   let _attribute = { id, name, type, value };
  //   if (_attributeIx > -1) _attributes[_attributeIx] = { ..._attribute };
  //   else _attributes.push(_attribute);
  //   setAttributes(_attributes);
  // }

  return (
    <main>
      <ListingTabLayout />
      <br />

      {/* <pre>{JSON.stringify(state, null, 2)}</pre> */}
      {/* <pre>{JSON.stringify({ data, isLoading, isError }, null, 2)}</pre> */}

      <ResourceLayout label="update listing">
        {listing ? (
          <UpdateListingForm listing={structuredClone(listing)} />
        ) : (
          <div className="text-center">
            <Spinner size={"lg"} />
          </div>
        )}
      </ResourceLayout>

      {/* <pre>{JSON.stringify(listing, null, 2)}</pre> */}
    </main>
  );
}
