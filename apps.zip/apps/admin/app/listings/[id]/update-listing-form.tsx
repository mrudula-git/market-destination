import { useMutation, useQuery } from "@tanstack/react-query";
import { Button, Spinner } from "flowbite-react";
import { useFormik } from "formik";
import { useParams, useRouter } from "next/navigation";
import { useEffect, useMemo, useState } from "react";
import { slugify } from "underscore.string";
import BestVisitTime from "../../../components/form-builder/best-visit-time";
import FormComposer2 from "../../../components/form-builder/form-composer-2";
import ImageUpload from "../../../components/form-builder/image-upload";
import MultiTextInput from "../../../components/form-builder/multi-text-input";
import MultiSelectComboBox from "../../../components/form-builder/multiselect-combobox";
import OperationalTimePicker from "../../../components/form-builder/operational-timepicker";
import { apis } from "../../../constants/apis";
import ResourceFormLayout from "../../../layouts/resource-form-layout";
import { useCategoryStore } from "../../../store/zustand/categories.store";
import apiKit from "../../../utils/api.helper";
import { validationSchema } from "../ListingsValidationRules";
import { routes } from "../../../constants/routes";
import MultiSelectCheckBox from "../../../components/form-builder/multiSelectCheckbox";
import { ErrorBoundary } from "react-error-boundary";

async function getCategories() {
  return apiKit({
    api: apis.categories,
    showToast: false,
  });
}

async function getAttributeGroups() {
  return apiKit({
    api: apis.attributeGroups,
    showToast: false,
  });
}

async function patchListing(id: string, body) {
  return apiKit({
    api: apis.listingById(id),
    method: "PATCH",
    body,
    successMessage: "Listing updated successfully",
    errorMessage: "Something went wrong. Listing is not updated.",
  });
}

async function putListingCategories(id: string, body: string[]) {
  return apiKit({
    api: apis.listingById(id),
    method: "PUT",
    body,
    successMessage: "Listing category is updated",
    errorMessage: "Something went wrong. Listing category is not updated.",
  });
}

const socialMediaURLsInitialState = {
  instagram: "",
  website: "",
  youtube: "",
  facebook: "",
};

export default function UpdateListingForm({ listing }) {
  const { id } = useParams();
  const router = useRouter();
  // console.log("update listing data",listing);
  const { categories, setCategories, attributeGroups, setAttributeGroups } =
    useCategoryStore();
  const [state, setState] = useState(listing);
  const formik = useFormik({
    initialValues: state,
    validationSchema: validationSchema,
    onSubmit: async (values) => {
      try {
        await validationSchema.validate(values, { abortEarly: false });
        console.log(state);

        await mutation.mutate(state);
        // router.replace(routes.listings);
      } catch (error) {}
    },
  });

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await formik.validateForm();
      await formik.submitForm();
      const errorField = document.querySelector(".error-message");
      if (errorField) {
        errorField.scrollIntoView({ behavior: "smooth", block: "center" });
      }
    } catch (error) {
      console.error("Validation error:", error);
    }
  };

  const {
    data: { categories: _categories } = {},
    isLoading: isCategoryLoading,
    isError: isCategoryError,
  } = useQuery({
    queryKey: ["getCategories"],
    queryFn: () => getCategories(),
  });

  const {
    data: { attributeGroups: _attributeGroups } = {},
    isLoading: isAttributeGroupLoading,
    isError: isAttributeGroupError,
  } = useQuery({
    queryKey: ["getAttributeGroups"],
    queryFn: () => getAttributeGroups(),
  });

  const mutation = useMutation({
    mutationKey: ["patchListing"],
    mutationFn: (body) => patchListing(id, body),
  });

  const categoriesMutation = useMutation({
    mutationKey: ["putListingCategories"],
    mutationFn: (body) => putListingCategories(id, body),
  });

  useEffect(() => {
    if (!_categories) return;
    setCategories(_categories);
  }, [_categories, setCategories]);

  useEffect(() => {
    if (!_attributeGroups) return;
    setAttributeGroups(_attributeGroups);
  }, [_attributeGroups, setAttributeGroups]);

  function handleFieldChanges(key: string, value: any) {
    const _state = structuredClone(state);
    _state[key] = value;

    if (key === "name") {
      _state.slug = slugify(value);
    }

    if (key === "languages") {
      _state.languages = value.map((language: any) => language.name);
    }

    setState(_state);
  }

  const categoriesOptions = useMemo(() => {
    if (!categories) return null;
    const results = categories.map(({ id, name }) => ({ id, name }));
    return results;
  }, [categories]);

  const attributeGroupsOptions = useMemo(() => {
    if (!attributeGroups) return null;
    const results = attributeGroups.map(({ id, name }) => ({ id, name }));
    return results;
  }, [attributeGroups]);

  const socialMediaState = useMemo(() => {
    const mergedState = { ...socialMediaURLsInitialState };

    if (Object.keys(state.socialMediaURLs).length) {
      Object.keys(state.socialMediaURLs).forEach((key) => {
        mergedState[key] = state.socialMediaURLs[key];
      });
    }

    return mergedState;
  }, [state.socialMediaURLs]);

  //  serialize
  //   const attributeOptions = useMemo(() => {
  //     if (!attributes) return null;
  //     const results = attributes.map(({ id, name }) => ({ id, name }));
  //     console.log(results);
  //     return results;
  //   }, [attributes]);

  // if (isAttributeGroupError || isCategoryError) {
  //   return (
  //     <div>
  //       <h3>Internal Server Error</h3>
  //     </div>
  //   );
  // }

  // if (isAttributeGroupLoading || isCategoryLoading) {
  //   return (
  //     <div className="text-center justify-center mt-20">
  //       <Spinner aria-label="loader" size="xl" />
  //     </div>
  //   );
  // }

  return (
    <div>
      {/* <pre>{JSON.stringify(state, null, 2)}</pre> */}
      <ResourceFormLayout label="listing details">
        <FormComposer2
          // state={state}
          fields={[
            {
              name: "name",
              type: "string",
              placeholder: "Enter listing name",
              error: formik.touched?.name && formik.errors?.name,
              message: formik.errors?.name || "",
              requiredfield: true,
              onchange: (value: string) => {
                formik.setFieldTouched("name");
                formik.handleChange({
                  target: { name: "name", value },
                });
                formik.validateField("name");
                handleFieldChanges("name", value);
              },
            },
            {
              name: "description",
              type: "string",
              placeholder: "Enter listing description",
              useTextArea: true,
              error: formik.touched?.description && formik.errors?.description,
              message: formik.errors?.description || "",
              onchange: (value: string) => {
                formik.setFieldTouched("description");
                formik.handleChange({
                  target: { name: "description", value },
                });
                formik.validateField("description");
              },
            },
            { name: "slug", type: "string", disable: true },
            // {
            //   name: "googleMapsURL",
            //   type: "string",
            //   placeholder: "Enter google map url",
            //   error:
            //     formik.touched?.googleMapsURL && formik.errors?.googleMapsURL,
            //   message: formik.errors?.googleMapsURL || "",
            //   onchange: (value: string) => {
            //     formik.setFieldTouched("googleMapsURL");
            //     formik.handleChange({
            //       target: { name: "googleMapsURL", value },
            //     });
            //     formik.validateField("googleMapsURL");
            //   },
            // },
            {
              name: "googleRating",
              type: "string",
              placeholder: "Enter google rating value",
              error:
                formik.touched?.googleRating && formik.errors?.googleRating,
              message: formik.errors?.googleRating || "",
              onchange: (value: string) => {
                formik.setFieldTouched("googleRating");
                formik.handleChange({
                  target: { name: "googleRating", value },
                });
                formik.validateField("googleRating");
              },
            },
          ]}
          onStateChange={(values) => {
            formik.setValues(values);
            setState(values);
          }}
          state={state}
        />
        <br />
        <ResourceFormLayout label="select categories" nested>
          {categoriesOptions ? (
            <MultiSelectCheckBox
              field="categories"
              onSelectionChange={(values) => {
                handleFieldChanges("categories", values);
                // categoriesMutation.mutate({ categories: values });
              }}
              options={categoriesOptions}
              selected={state.categories}
              state={state}
            />
          ) : null}
        </ResourceFormLayout>

        <br />
        <ResourceFormLayout label="select attribute groups" nested>
          {attributeGroupsOptions ? (
            <MultiSelectCheckBox
              field="attributeGroups"
              onSelectionChange={(values) => {
                handleFieldChanges("attributeGroups", values);
                // categoriesMutation.mutate({ categories: values });
              }}
              options={attributeGroupsOptions}
              selected={state.attributeGroups}
              state={state}
            />
          ) : null}
        </ResourceFormLayout>

        <br />
        <ResourceFormLayout label="contact details">
          <FormComposer2
            fields={[
              {
                name: "primaryEmail",
                type: "string",
                placeholder: "Enter listing email",
                error:
                  (formik.touched?.contacts?.primaryEmail &&
                    formik.errors?.contacts?.primaryEmail) ||
                  false,
                message: formik.errors?.contacts?.primaryEmail || "",
                requiredfield: true,
                onchange: (value: string) => {
                  formik.setFieldTouched("contacts.primaryEmail");
                  formik.handleChange({
                    target: { name: "contacts.primaryEmail", value },
                  });
                  formik.validateField("contacts.primaryEmail");
                },
              },
              {
                name: "primaryPhoneNumber",
                type: "string",
                placeholder: "Enter listing phone number",
                error:
                  (formik.touched?.contacts?.primaryPhoneNumber &&
                    formik.errors?.contacts?.primaryPhoneNumber) ||
                  false,
                message: formik.errors?.contacts?.primaryPhoneNumber || "",
                requiredfield: true,
                onchange: (value: string) => {
                  formik.setFieldTouched("contacts.primaryPhoneNumber");
                  formik.handleChange({
                    target: { name: "contacts.primaryPhoneNumber", value },
                  });
                  formik.validateField("contacts.primaryPhoneNumber");
                },
              },
              {
                name: "secondaryEmail",
                type: "string",
                placeholder: "Enter your email",
              },
              {
                name: "secondaryPhoneNumber",
                type: "string",
                placeholder: "Enter your phone number",
              },
              {
                name: "address",
                type: "string",
                useTextArea: true,
              },
              {
                name: "country",
                type: "string",
                placeholder: "Enter your country",
              },
              {
                name: "city",
                type: "string",
                placeholder: "Enter your city",
              },
              {
                name: "district",
                type: "string",
                placeholder: "Enter your district",
              },
              {
                name: "state",
                type: "string",
                placeholder: "Enter your state",
              },
              {
                name: "pinCode",
                type: "string",
                placeholder: "Enter your pincode",
              },
              {
                name: "companyName",
                type: "string",
                placeholder: "Enter your company name",
              },
            ]}
            initialState={state.contacts}
            onStateChange={(values) => {
              formik.setValues((prev) => ({
                ...prev,
                contacts: {
                  ...prev.contacts,
                  ...values,
                },
              }));
              setState({ ...state, contacts: values });
            }}
            state={state.contacts}
          />
        </ResourceFormLayout>

        <br />
        <ResourceFormLayout label="social media" nested>
          <FormComposer2
            fields={[
              { name: "instagram", type: "string" },
              { name: "website", type: "string" },
              { name: "youtube", type: "string" },
              { name: "facebook", type: "straing" },
            ]}
            initialState={socialMediaURLsInitialState}
            onStateChange={(values) => {
              // console.log("onStateChange", values);
              setState({ ...state, socialMediaURLs: values });
            }}
            state={
              // Object.keys(state.socialMediaURLs).length
              //   ? state.socialMediaURLs
              //   :
              socialMediaState
            }
          />
        </ResourceFormLayout>

        <br />
        <MultiTextInput
          field="Uniques Features"
          onListChange={(values) => {
            handleFieldChanges("uniques", values);
          }}
          state={state}
          useTextarea
          description={
            <div>
              <p>
                Uniques Features will help your listing to get searched quickly
                in the platform.
              </p>
              <p>
                Eg. Best waterparks near mumbai, Budget resort near goa etc...
              </p>
            </div>
          }
          placeholder="Budget/Best/Adventurous/etc...  Resort/Tourism/etc...  near City"
        />
        {/* <MultiTextInput
          field="tags"
          onListChange={(values) => {
            handleFieldChanges("tags", values);
          }}
          state={state}
          useTextarea
          description={
            <div>
              <p>
                Tags will help your listing to get searched quickly in the
                platform.
              </p>
              <p>
                Eg. Best waterparks near mumbai, Budget resort near goa etc...
              </p>
            </div>
          }
          placeholder="Budget/Best/Adventurous/etc...  Resort/Tourism/etc...  near City"
        /> */}
        <MultiTextInput
          field="keywords"
          onListChange={(values) => {
            handleFieldChanges("keywords", values);
          }}
          state={state}
          useTextarea
          description={
            <div>
              <p>
                Keywords will be used to improve the visibility of your listing
                on google.
              </p>
              <p>
                Eg. Beachfront resorts, Waterpark with amusement rides, etc...
              </p>
            </div>
          }
          placeholder="Relaxing/Scenic/Modern/etc... Amenities/Location/etc..."
        />

        <br />
        <MultiSelectComboBox
          field="languages"
          description={
            <div>
              <p>Choose the languages spoken by the hosts of the place.</p>
              <p>Start typing for language & it will appear.</p>
            </div>
          }
          onSelectionChange={(values) => {
            handleFieldChanges("languages", values);
          }}
          options={languagesList}
          selected={state.languages.map((e, k) => ({
            name: e,
            id: k.toString(),
          }))}
          state={state}
        />

        <br />
        <MultiTextInput
          field="travelInstructions"
          onListChange={(values) => {
            handleFieldChanges("travelInstructions", values);
          }}
          state={state}
          useTextarea
          placeholder="Add any travel instructions or specific details for guests."
          description={
            <div>
              <p>
                Guide visitors about how to reach to the location from nearby
                Bus stops, Train stations, Airports
              </p>
              <p>Eg. X KM from Mumbai Central Railway Station etc...</p>
            </div>
          }
        />
        <MultiTextInput
          field="thingsToDo"
          onListChange={(values) => {
            handleFieldChanges("thingsToDo", values);
          }}
          state={state}
          useTextarea
          description={
            <div>
              <p>What are the things visitors can do in the neaby area</p>
              <p>
                Eg. Scuba diving, watersports, outdoor games, bonfire etc...
              </p>
            </div>
          }
          placeholder=""
        />

        <br />
        <ErrorBoundary fallback={<></>}>
          <OperationalTimePicker
            state={state.operationalTimings}
            onChange={(timings) => {
              handleFieldChanges("operationalTimings", timings);
            }}
          />
        </ErrorBoundary>

        <br />
        <ErrorBoundary fallback={<></>}>
          <BestVisitTime
            state={state.bestTimings}
            onChange={(duration) => {
              handleFieldChanges("bestTimings", [duration]);
            }}
          />
        </ErrorBoundary>

        <br />
        <ResourceFormLayout label="select listing images" nested>
          <ImageUpload
            listingId={id as string}
            folderName={`/marketplace/listings/${id}`}
            photos={state.photos}
          />
        </ResourceFormLayout>

        <br />
        <div className="static">
          <Button
            color="light"
            className={`inline-block ${
              mutation.isPending
                ? "disabled:opacity-50 disabled:cursor-not-allowed bg-slate-400"
                : ""
            }`}
            disabled={mutation.isPending}
            onClick={handleSubmit}
          >
            {mutation.isPending ? "Updating..." : "Update listing"}
          </Button>
        </div>
      </ResourceFormLayout>

      {/* <pre>{JSON.stringify(state, null, 2)}</pre> */}
    </div>
  );
}

const languagesList = [
  { name: "Malayalam", id: "1" },
  { name: "Punjabi", id: "2" },
  { name: "Gujarati", id: "3" },
  { name: "Hindi", id: "4" },
  { name: "Tamil", id: "5" },
  { name: "Bangla", id: "6" },
  { name: "Telugu", id: "7" },
  { name: "Oriya", id: "8" },
  { name: "Lushai", id: "9" },
  { name: "Marathi", id: "10" },
  { name: "Konkani", id: "11" },
  { name: "Khasi", id: "12" },
  { name: "Kannada", id: "13" },
  { name: "Nepali", id: "14" },
  { name: "Manipuri", id: "15" },
  { name: "Assamese", id: "16" },
  { name: "Nissi", id: "17" },
  { name: "Ao", id: "18" },
  { name: "English", id: "19" },
];
