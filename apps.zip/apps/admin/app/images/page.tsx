// import ImageUpload from "../../components/image-upload";

const ImagesUpload = () => {
  return <>{/* <ImageUpload/> */}</>;
};

export default ImagesUpload;
