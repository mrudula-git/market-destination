"use client";

import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { useState } from "react";
import type { CustomFlowbiteTheme } from "flowbite-react";
import { Flowbite } from "flowbite-react";
import { SessionProvider } from "next-auth/react";

const customTheme: CustomFlowbiteTheme = {
  button: {
    color: {
      blue: "text-white bg-blue-500 border border-transparent enabled:hover:bg-blue-600 focus:ring-4 focus:ring-blue-300 dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800",
      failure:
        "text-white bg-red-500 border border-transparent enabled:hover:bg-red-600 focus:ring-4 focus:ring-red-300 dark:bg-red-600 dark:enabled:hover:bg-red-700 dark:focus:ring-red-900",
    },
  },
};

export default function Providers({
  children,
}: {
  children: React.ReactNode;
}): JSX.Element {
  const [queryClient] = useState(() => new QueryClient());

  return (
    <QueryClientProvider client={queryClient}>
      <Flowbite theme={{ theme: customTheme }}>
        <SessionProvider>
          <>{children}</>
        </SessionProvider>
      </Flowbite>
    </QueryClientProvider>
  );
}
