export default function MediaPage() {
  return <div>Media</div>;
}
