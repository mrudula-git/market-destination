import { handlers } from "./auth";

export { handlers as GET, handlers as POST };
