import NextAuth from "next-auth";
import CredentialsProvider from "next-auth/providers/credentials";
import { compare } from "bcrypt";
import { prisma } from "database";
import { NextResponse } from "next/server";

export const handlers = NextAuth({
  secret: process.env.NEXTAUTH_SECRET,
  session: {
    strategy: "jwt",
    maxAge: 60 * 60 * 24, // 24 hour
  },
  jwt: {
    secret: process.env.NEXTAUTH_SECRET,
    maxAge: 60 * 60 * 24 * 30, // 30 days
  },
  providers: [
    CredentialsProvider({
      name: "Credentials",
      credentials: {
        email: {},
        password: {},
      },
      async authorize(credentials) {
        if (!credentials) return null;

        const { email, password } = credentials;
        if (!email || !password) return null;

        const user = await prisma.admin_users_authentication.findUnique({
          where: { email: email },
          include: { admin_user: true },
        });

        if (!user) {
          return null;
        }

        const isPasswordValid = await compare(password, user.password);

        if (!isPasswordValid) {
          NextResponse.json({ error: "invalid password" }, { status: 400 });
          return null;
        }

        return user;
      },
    }),
  ],
  callbacks: {
    signIn({ user, account, profile, email, credentials }) {
      // console.log("signIn Callback", {
      //   user,
      //   account,
      //   profile,
      //   email,
      //   credentials,
      // });
      return true;
    },
    async session({ session, user, token }) {
      // console.log("Session Callback", { session, user, token });
      return session;
    },
    async jwt({ token, user, account, profile, isNewUser }) {
      // console.log("JWT Callback", { token, user, account, profile, isNewUser });
      return token;
    },
  },
});
