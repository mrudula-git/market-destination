import { NextResponse } from "next/server";
import { prisma } from "database";
import { hash } from "bcrypt";

export async function POST(req: Request, res: any) {
  try {
    let body = await new Response(req.body).json();
    console.log(body);

    const { email, password, name } = body;

    if (!email || !password || !name) {
      return NextResponse.json(
        { error: "MissingCredentials" },
        { status: 400 }
      );
    }

    const existing = await prisma.admin_users_authentication.findUnique({
      where: {
        email: email,
      },
    });

    if (existing) {
      return NextResponse.json(
        { error: "DuplicateCredentials" },
        { status: 400 }
      );
    }

    const hashedPassword = await hash(password, 10);

    const adminUser = await prisma.admin_users.create({
      data: {
        name,
        contacts: {
          create: {
            primaryEmail: email,
          },
        },
      },
    });

    const adminUserAuth = await prisma.admin_users_authentication.create({
      data: {
        email: email,
        password: hashedPassword,
        admin_user: {
          connect: {
            id: adminUser.id,
          },
        },
      },
    });

    return NextResponse.json(
      { auth: adminUserAuth, message: "Successfuly signed up" },
      { status: 201 }
    );
  } catch (error) {
    return NextResponse.json({}, { status: 500 });
  }
}
