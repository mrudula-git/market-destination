"use client";

import { useQuery } from "@tanstack/react-query";
import { Button, TextInput } from "flowbite-react";
import { useEffect, useState } from "react";
import apiKit from "../../../utils/api.helper";
import { apis } from "../../../constants/apis";
import FormComposer from "../../../components/form-builder/form-composer";
import { useCategoryStore } from "../../../store/zustand/categories.store";
import ResourceLayout from "../../../layouts/resource-layout";
import UpdateCategoryForm from "./update-category-form";

interface PageProps {
  params: {
    id: string;
  };
  searchParams: {
    query: string;
  };
}

async function getCategory(id: string) {
  return apiKit({
    api: apis.categoryById(id),
    showToast:false
  });
}

export default function UpdateCategoriesPage({ params }: PageProps) {
  const { id } = params;

  const { category, setCategory } = useCategoryStore();

  useEffect(() => {
    if (category) return;

    (async () => {
      const { category: categoryData } = await getCategory(id);
      setCategory(categoryData);
    })();
  }, [category]);

  return (
    <div>
      <br />
      <ResourceLayout label="update categories">
        {category ? <UpdateCategoryForm category={structuredClone(category)} /> : null}
      </ResourceLayout>
    </div>
  );
}
