import { Button } from "flowbite-react";
import { useEffect, useMemo, useState } from "react";
import { apis } from "../../../constants/apis";
import { useCategoryStore } from "../../../store/zustand/categories.store";
import apiKit from "../../../utils/api.helper";
import FormComposer from "../../../components/form-builder/form-composer";
import MultiSelectComboBox from "../../../components/form-builder/multiselect-combobox";
import FormComposer2 from "../../../components/form-builder/form-composer-2";
import ResourceFormLayout from "../../../layouts/resource-form-layout";
import { useFormik } from "formik";
import validationSchema from "../validationRules";

// async function getAttributes() {
//   return apiKit({
//     api: apis.attributes,
//     query: {
//       take: "all",
//     },
//     showToast: false,
//   });
// }

export default function UpdateCategoryForm({ category }) {
  const { attributes, setAttributes } = useCategoryStore();
  const [loading, setLoading] = useState(false); 
  const [state, setState] = useState(category);

  // useEffect(() => {
  //   (async () => {
  //     const { attributes: attributesData } = await getAttributes();
  //     setAttributes(attributesData);
  //   })();
  // }, []);

  function handleFieldChanges(key: string, value: any) {
    const _state = structuredClone(state);
    _state[key] = value;
    setState(_state);
  }

  const attributeOptions = useMemo(() => {
    if (!attributes) return null;
    const results = attributes.map(({ id, name }) => ({ id, name }));
    // console.log(results);
    return results;
  }, [attributes]);

  async function saveCategory() {
    setLoading(true); 
    try {
      const data = await apiKit({
        api: apis.categoryById(state.id),
        method: "PATCH",
        body: state,
        successMessage: "Category updated successfully",
        errorMessage: "Something went wrong. Category is not updated.",
      });
      console.log(data);
    } catch (error) {
      console.error("Error updating category:", error);
    } finally {
      setLoading(false);
    }
  }

  const formik = useFormik({
    initialValues: state,
    validationSchema: validationSchema,
    onSubmit: async (values) => {
      await saveCategory();
    },
  });

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await formik.validateForm();
      await formik.submitForm();
      const errorField = document.querySelector(".error-message");
      if (errorField) {
        errorField.scrollIntoView({ behavior: "smooth", block: "center" });
      }
    } catch (error) {
      console.error("Validation error:", error);
    }
  };
  
  return (
    <div>
      <ResourceFormLayout label="update category">
        <FormComposer2
          fields={[
            {
              name: "name",
              type: "string",
              placeholder: "Enter category name",
              error: (formik.touched?.name && formik.errors?.name) || false,
              message: formik.errors?.name || "",
              requiredfield: true,
              onchange: (value: string) => {
                formik.setFieldTouched("name");
                formik.handleChange({ target: { name: "name", value } });
                formik.validateField("name");
              },
            },
            {
              name: "description",
              type: "string",
              placeholder: "Enter category description",
              useTextArea: true,
              requiredfield: true,
              error:
                (formik.touched?.description && formik.errors?.description) ||
                false,
              message: formik.errors?.description || "",
              onchange: (value: string) => {
                formik.setFieldTouched("description");
                formik.handleChange({
                  target: { name: "description", value },
                });
              },
            },
          ]}
          onStateChange={(values) => {
            setState(values);
            formik.setValues({
              ...formik.values,
              name: values.name,
              description: values.description,
            });
          }}
          state={state}
        />

        <br />
        <ResourceFormLayout label="select attributes" nested>
          {attributeOptions ? (
            <MultiSelectComboBox
              field="attributes"
              onSelectionChange={(values) => {
                // console.log("onSelectionChange", values);
                handleFieldChanges("attributes", values);
              }}
              options={attributeOptions}
              selected={state.attributes}
              state={state}
            />
          ) : null}
        </ResourceFormLayout>

        <br />
        <Button
          color="light"
          className={`${
            loading
              ? "disabled:opacity-50 disabled:cursor-not-allowed bg-slate-400"
              : ""
          }`}
          disabled={loading}
          onClick={handleSubmit}
        >
          {loading ? 'Saving...' : 'Save category'}
        </Button>
      </ResourceFormLayout>
    </div>
  );
}
