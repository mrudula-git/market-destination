"use client";

import { useQuery } from "@tanstack/react-query";
import { Accordion, Spinner } from "flowbite-react";
import { apis } from "../../../constants/apis";
import apiKit from "../../../utils/api.helper";
import ResourceLayout from "../../../layouts/resource-layout";
import UpdateAdminUserForm from "../../admins/[id]/update-admin-user-form";
import CategoriesTabLayout from "../../../layouts/categories-tab-layout";
import DataTable from "../../../components/table";
import CreateAttributeGroupForm from "./create-attribute-group-form";
import UpdateAttributeGroupForm from "./update-attribute-group-form";
import { useMemo } from "react";

async function getAttributeGroups() {
  return apiKit({
    api: apis.attributeGroups,
    showToast: false,
  });
}

export default function GroupsRootPage(): JSX.Element {
  const {
    data: { attributeGroups = [] } = {},
    isLoading,
    isError,
  } = useQuery({
    queryKey: ["attributeGroups"],
    queryFn: getAttributeGroups,
  });

  const searializeToTable = useMemo(() => {
    // const formatter = new Intl.ListFormat("en", {
    //   style: "long",
    //   type: "conjunction",
    // });
    if (!attributeGroups) return [];
    return attributeGroups.map((el) => ({
      id: el.id,
      name: el.name,
      // attributes: formatter.format(el.attributes.map((a) => a.name)),
    }));
  }, [attributeGroups]);

  return (
    <main>
      <CategoriesTabLayout activeKey="categories_attribute_groups" />
      {isError && (
        <div>Internal Server Error</div>
      )}
      {isLoading && (
        <div className="text-center justify-center mt-20">
          <Spinner aria-label="loader" size="xl" />
        </div>
      )}
      {/* {!isLoading && <DataTable data={searializeToTable} />} */}
      <br />
      <ResourceLayout label="create attribute group">
        <CreateAttributeGroupForm />
      </ResourceLayout>
      <br />
      <ResourceLayout label="update attribute groups">
        <Accordion collapseAll>
          {attributeGroups
            ? attributeGroups.map((attributeGroup) => (
                <Accordion.Panel key={attributeGroup.id}>
                  <Accordion.Title>
                    <div className="px-4">{attributeGroup.name}</div>
                  </Accordion.Title>
                  <Accordion.Content className="px-4 border-0">
                    <UpdateAttributeGroupForm attributeGroup={attributeGroup} />
                  </Accordion.Content>
                </Accordion.Panel>
              ))
            : null}
        </Accordion>
      </ResourceLayout>
      {/* <pre>{JSON.stringify(attributeGroups, null, 2)}</pre> */}
    </main>
  );
}
