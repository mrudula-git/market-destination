import { Suspense } from "react";

export default function GroupsRootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <main>
      <Suspense>{children}</Suspense>
    </main>
  );
}
