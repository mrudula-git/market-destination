import * as yup from "yup";

const validationSchema = yup.object().shape({
  name: yup
    .string()
    .trim()
    .min(2, "Name must be at least 2 characters")
    .max(1000, "Name must not exceed 1000 characters")
    .matches(/^[^\s].*[^\s]$/, "Name should not start or end with a space")
    .required("Name is required"),
  iconUrl: yup.string().trim(),
  description: yup.string(),
  canFilter: yup.boolean(),
});

export default validationSchema;
