"use client";

import { useEffect } from "react";

type Error = {
  error: Error & { digest?: string };
  reset: () => void;
};

export default function CategoriesRootError({ error, reset }: Error) {
  console.log("CategoriesRootError", error);

  return (
    <div>
      <p>Error</p>
    </div>
  );
}
