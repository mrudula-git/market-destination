import { ErrorBoundary } from "react-error-boundary";
import CategoriesFetcher from "../../components/categories-fetcher";
import { Suspense } from "react";
// import TabContentNavigation from "../../components/tab-content-navigation";
// import CategoriesTabLayout from "../../layouts/categories-tab-layout";

export default function CategoriesRootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <main>
      <ErrorBoundary fallback={<p>Fetcher</p>}>
        <CategoriesFetcher />
      </ErrorBoundary>

      <Suspense>
        <div>{children}</div>
      </Suspense>
    </main>
  );
}
