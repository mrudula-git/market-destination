"use client";

import { useQuery } from "@tanstack/react-query";
import { Button, Spinner } from "flowbite-react";
import { useEffect, useMemo } from "react";
import DataTable from "../../components/table";
import { apis } from "../../constants/apis";
import { routes } from "../../constants/routes";
import { useCountStore } from "../../store/zustand/count.store";
import type { PageProps } from "../../constants/props.types";
import type { QueryArgs, Resources } from "../../utils/api.helper";
import apiKit from "../../utils/api.helper";
import CategoriesTabLayout from "../../layouts/categories-tab-layout";
import { ErrorBoundary } from "react-error-boundary";

async function getCategories(query: QueryArgs): Promise<Resources> {
  return apiKit({
    api: apis.categories,
    query,
    showToast: false,
  });
}

export default function CategoriesRootPage({
  searchParams,
}: PageProps): JSX.Element {
  const {
    data: { categories, count: _count } = {},
    isLoading,
    isError,
  } = useQuery({
    queryKey: ["categories"],
    queryFn: () => getCategories(searchParams),
  });

  const { setCount } = useCountStore();
  useEffect(() => {
    if (!_count) return;
    setCount(_count);
  }, [_count, setCount]);

  const searializeToTable = useMemo(() => {
    // const formatter = new Intl.ListFormat("en", {
    //   style: "long",
    //   type: "conjunction",
    // });
    if (!categories) return [];
    return categories.map((el) => ({
      id: el.id,
      name: el.name,
      // attributes: formatter.format(el.attributes.map((a) => a.name)),
    }));
  }, [categories]);

  if (isError) {
    return (
      <div>
        <h1>Internal Server Error</h1>
      </div>
    );
  }

  return (
    <main>
      <ErrorBoundary fallback={<p>Tabs</p>}>
        <CategoriesTabLayout activeKey="categories" />
      </ErrorBoundary>

      <div className="flex justify-between items-center">
        <h2>Categories</h2>
        <Button color="light" href={routes.categoriesCreate}>
          Create
        </Button>
      </div>

      <ErrorBoundary fallback={<p>Spinner</p>}>
        {isLoading && (
          <div className="text-center justify-center mt-20">
            <Spinner aria-label="loader" size="xl" />
          </div>
        )}
      </ErrorBoundary>

      <ErrorBoundary fallback={<p>Table</p>}>
        {!isLoading && <DataTable data={searializeToTable} />}
      </ErrorBoundary>
      {/* <pre>{JSON.stringify(searializeToTable, null, 2)}</pre> */}
      {/* <pre>{.stringify(categories, null, 2)}</pre> */}
    </main>
  );
}
