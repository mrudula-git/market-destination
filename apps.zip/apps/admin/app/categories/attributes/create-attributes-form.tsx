import { useMutation } from "@tanstack/react-query";
import { Button } from "flowbite-react";
import { useState } from "react";
import { apis } from "../../../constants/apis";
import ResourceFormLayout from "../../../layouts/resource-form-layout";
import apiKit from "../../../utils/api.helper";
import FormComposer2 from "../../../components/form-builder/form-composer-2";
import { useFormik } from "formik";
import validationSchema from "../validationRules";

const initialState = {
  uid: Math.round(Math.random() * 1000000),
  name: "",
  description: "",
  iconUrl: "",
  type: "string",
  canFilter: false,
};

async function postListingAttributes(body: any) {
  const results = apiKit({
    api: apis.attributes,
    method: "POST",
    query: {
      take: "all",
    },
    body,
    successMessage: "Attribute created successfully",
    errorMessage: "Something went wrong. Attribute is not created.",
  });
  return results;
}

export default function CreateAttributesForm() {
  const [state, setState] = useState(initialState);

  const mutation = useMutation({
    mutationKey: ["postListingAttributes"],
    mutationFn: (body) => postListingAttributes(body),
  });

  const formik = useFormik({
    initialValues: initialState,
    validationSchema: validationSchema,
    onSubmit: async (values) => {
      console.log({ state });
      // await mutation.mutate(values);
      // Addeed later
      // mutation.mutate(state);
      // location.reload();
    },
  });

  return (
    <div>
      <ResourceFormLayout label="attribute details">
        <FormComposer2
          fields={[
            {
              name: "name",
              type: "string",
              placeholder: "Enter attribute name",
              error: (formik.touched?.name && formik.errors?.name) || false,
              message: formik.errors?.name || "",
              requiredfield: true,
              onchange: (value: string) => {
                formik.setFieldTouched("name");
                formik.handleChange({ target: { name: "name", value } });
                formik.validateField("name");
              },
            },
            {
              name: "description",
              type: "string",
              useTextArea: true,
              placeholder: "Enter attribute description",
              requiredfield: true,
              error:
                (formik.touched?.description && formik.errors?.description) ||
                false,
              message: formik.errors?.description || "",
              onchange: (value: string) => {
                formik.setFieldTouched("description");
                formik.handleChange({
                  target: { name: "description", value },
                });
                formik.validateField("description");
              },
            },
            {
              name: "iconUrl",
              type: "string",
              placeholder: "Enter attribute icon url",
              error:
                (formik.touched?.iconUrl && formik.errors?.iconUrl) || false,
              message: formik.errors?.iconUrl || "",
              onchange: (value: string) => {
                formik.setFieldTouched("iconUrl");
                formik.handleChange({
                  target: { name: "iconUrl", value },
                });
                formik.validateField("iconUrl");
              },
            },
            {
              name: "canFilter",
              type: "boolean",
              placeholder: "Select the filter of attribute",
              error:
                (formik.touched?.canFilter && formik.errors?.canFilter) ||
                false,
              message: formik.errors?.canFilter || "",
              onchange: (value: string) => {
                formik.setFieldTouched("canFilter");
                formik.handleChange({
                  target: { name: "canFilter", value },
                });
                formik.validateField("canFilter");
              },
            },
            {
              name: "type",
              type: "select",
              placeholder: "Select the type of attribute field",
              error: (formik.touched?.type && formik.errors?.type) || false,
              message: formik.errors?.type || "",
              onchange: (value: string) => {
                formik.setFieldTouched("type");
                formik.handleChange({
                  target: { name: "type", value },
                });
                formik.validateField("type");
              },
              options: [
                { value: "string", label: "Text" },
                { value: "number", label: "Number" },
                { value: "boolean", label: "Boolean(Checkbox)" },
                { value: "long-string", label: "Long Text" },
                { value: "select", label: "Select(Dropdown)" },
                { value: "date", label: "Date" },
                { value: "time", label: "Time" },
              ],
            },
          ]}
          onStateChange={(values) => {
            setState(values);
            formik.setValues({
              ...formik.values,
              name: values.name,
              description: values.description,
              iconUrl: values.iconUrl,
              canFilter: values.canFilter,
            });
          }}
          state={state}
        />

        <br />
        <Button
          color="light"
          className={`${
            mutation.isPending
              ? "disabled:opacity-50 disabled:cursor-not-allowed bg-slate-400"
              : ""
          }`}
          disabled={mutation.isPending}
          onClick={(e: React.MouseEvent<HTMLButtonElement, MouseEvent>) => {
            e.preventDefault();
            formik.submitForm();

            mutation.mutate(state);
            setTimeout(() => {
              location.reload();
            }, 250);
          }}
        >
         {mutation.isPending ? 'Creating...' : 'Create attribute'}
        </Button>
      </ResourceFormLayout>
    </div>
  );
}
