"use client";

import { useMutation, useQuery } from "@tanstack/react-query";
import { apis } from "../../../constants/apis";
import ResourceLayout from "../../../layouts/resource-layout";
import apiKit from "../../../utils/api.helper";
import CreateAttributesForm from "./create-attributes-form";
import { useEffect, useMemo, useState } from "react";
import { useCategoryStore } from "../../../store/zustand/categories.store";
import DataTable from "../../../components/table";
import CategoriesTabLayout from "../../../layouts/categories-tab-layout";
import { useCountStore } from "../../../store/zustand/count.store";
import { Button, Modal, ModalBody } from "flowbite-react";
import FormComposer2 from "../../../components/form-builder/form-composer-2";
import ResourceFormLayout from "../../../layouts/resource-form-layout";
import { Spinner } from "flowbite-react";
import { useFormik } from "formik";
import validationSchema from "../validationRules";

interface PageProps {
  searchParams: {
    search: string;
    page: string;
  };
  editfunction: any;
}

async function getAttributes(query: any) {
  return apiKit({
    api: apis.attributes,
    query,
    showToast: false,
  });
}

export default function AttributesRootPage({
  searchParams,
}: PageProps): JSX.Element {
  const {
    data: { attributes, count: _count } = {},
    isLoading,
    isError,
  } = useQuery({
    queryKey: ["attributes"],
    queryFn: () => getAttributes(searchParams),
  });

  const { setAttributes } = useCategoryStore();
  const { setCount } = useCountStore();

  useEffect(() => {
    if (!attributes) return;
    setAttributes(attributes);
  }, [attributes]);

  useEffect(() => {
    if (!_count) return;
    setCount(_count);
  }, [_count, setCount]);

  const searializeToTable = useMemo(() => {
    if (!attributes) return [];
    return attributes.map((el) => ({
      id: el.id,
      name: el.name,
      type: el.type,
    }));
  }, [attributes]);

  const initialState = {
    name: null,
    description: null,
    iconUrl: null,
    type: null,
    canFilter: false,
  };

  const [selectedAttributeId, setSelectedAttributeId] = useState<string>("");
  const [openModal, setOpenModal] = useState(false);
  const [state, setState] = useState(initialState);

  const handleEdit = (id: string) => {
    setSelectedAttributeId(id);
    const selectedAttribute = attributes?.find((attr) => attr.id === id);
    if (selectedAttribute) {
      setState({
        name: selectedAttribute.name || "",
        description: selectedAttribute.description || "",
        iconUrl: selectedAttribute.iconUrl || "",
        type: selectedAttribute.type || "",
        canFilter: selectedAttribute.canFilter || false,
      });
    }
    setOpenModal(true);
  };

  const mutation = useMutation({
    mutationKey: ["updateListingAttributes"],
    mutationFn: () => updateListingAttributes(selectedAttributeId, state),
    onSuccess: () => {
      setOpenModal(false);
      setState({ ...state });
    },
  });
  async function updateListingAttributes(id: string, body: any) {
    await apiKit({
      api: apis.attributeById(id),
      method: "PATCH",
      body,
      successMessage: "Attribute updated successfully",
      errorMessage: "Something went wrong. Attribute is not updated.",
    });
  }

  const formik = useFormik({
    initialValues: initialState,
    validationSchema: validationSchema,
    onSubmit: async (values) => {
      // await mutation.mutate(values);
      await mutation.mutate(state);
    },
  });

  if (isError) {
    return (
      <div>
        <h1>Internal Server Error</h1>
      </div>
    );
  }

  return (
    <main>
      <CategoriesTabLayout activeKey="categories_attributes" />

      <br />
      <ResourceLayout label="create attributes">
        <CreateAttributesForm />
      </ResourceLayout>

      <br />
      <hr />
      <br />
      <ResourceLayout label="attributes">
        {isLoading && (
          <div className="text-center justify-center mt-20">
            <Spinner aria-label="loader" size="xl" />
          </div>
        )}
        {!isLoading && (
          <DataTable data={searializeToTable} editFunction={handleEdit} />
        )}
      </ResourceLayout>

      {/* <pre>{JSON.stringify(attributes, null, 2)}</pre> */}

      <Modal show={openModal} onClose={() => setOpenModal(false)}>
        <ResourceFormLayout
          label="Update Attribute"
          onClose={() => setOpenModal(false)}
        >
          <FormComposer2
            fields={[
              {
                name: "name",
                type: "string",
                placeholder: "Enter attribute name",
                error: (formik.touched?.name && formik.errors?.name) || false,
                message: formik.errors?.name || "",
                requiredfield: true,
                onchange: (value: string) => {
                  formik.setFieldTouched("name");
                  formik.handleChange({ target: { name: "name", value } });
                  formik.validateField("name");
                },
              },
              {
                name: "description",
                type: "string",
                placeholder: "Enter attribute description",
                useTextArea: true,
                requiredfield: true,
                error:
                  (formik.touched?.description && formik.errors?.description) ||
                  false,
                message: formik.errors?.description || "",
                onchange: (value: string) => {
                  formik.setFieldTouched("description");
                  formik.handleChange({
                    target: { name: "description", value },
                  });
                  formik.validateField("description");
                },
              },
              {
                name: "iconUrl",
                type: "string",
                placeholder: "Enter attribute icon url",
                error:
                  (formik.touched?.iconUrl && formik.errors?.iconUrl) || false,
                message: formik.errors?.iconUrl || "",
                onchange: (value: string) => {
                  formik.setFieldTouched("iconUrl");
                  formik.handleChange({
                    target: { name: "iconUrl", value },
                  });
                  formik.validateField("iconUrl");
                },
              },
              {
                name: "canFilter",
                type: "boolean",
                placeholder: "Select the filter of attribute",
                error:
                  (formik.touched?.canFilter && formik.errors?.canFilter) ||
                  false,
                message: formik.errors?.canFilter || "",
                onchange: (value: string) => {
                  formik.setFieldTouched("canFilter");
                  formik.handleChange({
                    target: { name: "canFilter", value },
                  });
                  formik.validateField("canFilter");
                },
              },
              {
                name: "type",
                type: "select",
                placeholder: "Select the type of attribute field",
                error: (formik.touched?.type && formik.errors?.type) || false,
                message: formik.errors?.type || "",
                onchange: (value: string) => {
                  formik.setFieldTouched("type");
                  formik.handleChange({
                    target: { name: "type", value },
                  });
                  formik.validateField("type");
                },
                options: [
                  { value: "string", label: "Text" },
                  { value: "number", label: "Number" },
                  { value: "boolean", label: "Boolean(Checkbox)" },
                  { value: "long-string", label: "Long Text" },
                  { value: "select", label: "Select(Dropdown)" },
                  { value: "date", label: "Date" },
                  { value: "time", label: "Time" },
                ],
              },
            ]}
            onStateChange={(values) => {
              setState(values);
              formik.setValues({
                ...formik.values,
                name: values.name,
                description: values.description,
                iconUrl: values.iconUrl,
                canFilter: values.canFilter,
              });
            }}
            state={state}
          />
          <br />
          <Button
            color="light"
            disabled={mutation.isPending}
            className={`${
              mutation.isPending
                ? "disabled:opacity-50 disabled:cursor-not-allowed bg-slate-400"
                : ""
            }`}
            onClick={(e: React.MouseEvent<HTMLButtonElement, MouseEvent>) => {
              e.preventDefault();
              formik.submitForm();
              setTimeout(() => {
                window.location.reload();
              }, 200);
            }}
          >
            {mutation.isPending ? "Updating..." : "Update attribute"}
          </Button>
        </ResourceFormLayout>
      </Modal>
      {/* <pre>{JSON.stringify(attributes, null, 2)}</pre> */}
    </main>
  );
}
