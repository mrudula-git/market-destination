import { Suspense, type ReactNode } from "react";

// export default function AttributesRootLayout({
//   children,
//   edit,
// }: {
//   children: ReactNode;
//   type?: ReactNode;
// }) {
//   return (
//     <main>
//       <dialog open>
//         <p>Greetings, one and all!</p>
//         <button>OK</button>
//       </dialog>

//       {edit}
//       {children}
//     </main>
//   );
// }
export default function AttributesRootLayout({
  children,
}: {
  children: ReactNode;
}) {
  return (
    <main>
      <Suspense>{children}</Suspense>
    </main>
  );
}
