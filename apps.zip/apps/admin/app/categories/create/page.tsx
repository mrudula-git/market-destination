"use client";

import { Suspense } from "react";
import ResourceLayout from "../../../layouts/resource-layout";
import { useCategoryStore } from "../../../store/zustand/categories.store";
import CreateCategoryForm from "./create-category-form";

export default function CreateCategoriesPage() {
  return (
    <div>
      <br />
      <Suspense>
        <ResourceLayout label="create categories">
          <CreateCategoryForm />
        </ResourceLayout>
      </Suspense>
    </div>
  );
}
