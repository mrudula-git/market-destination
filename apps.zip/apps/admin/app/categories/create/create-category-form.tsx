import { useMutation } from "@tanstack/react-query";
import { Button } from "flowbite-react";
import { useEffect, useMemo, useState } from "react";
import FormComposer2 from "../../../components/form-builder/form-composer-2";
import MultiSelectComboBox from "../../../components/form-builder/multiselect-combobox";
import { apis } from "../../../constants/apis";
import ResourceFormLayout from "../../../layouts/resource-form-layout";
import { useCategoryStore } from "../../../store/zustand/categories.store";
import apiKit from "../../../utils/api.helper";
import { useRouter } from "next/navigation";
import { routes } from "../../../constants/routes";
import { useFormik } from "formik";
import validationSchema from "../validationRules";

const initialState = {
  name: null,
  description: null,
  attributes: [],
};

async function getAttributes() {
  return apiKit({
    api: apis.attributes,
    showToast: false,
  });
}

async function postCategory(body) {
  return apiKit({
    api: apis.categories,
    method: "POST",
    body,
    successMessage: "Category created successfully",
    errorMessage: "Something went wrong. Category is not created.",
  });
}

export default function CreateCategoryForm() {
  const router = useRouter();

  const { attributes, setAttributes } = useCategoryStore();

  const [state, setState] = useState(initialState);

  // useEffect(() => {
  //   (async () => {
  //     const { attributes: attributesData } = await getAttributes();
  //     setAttributes(attributesData);
  //   })();
  // }, []);

  const mutation = useMutation({
    mutationKey: ["postCategory"],
    mutationFn: async (body) => {
      const { category } = await postCategory(body);
      if (category) router.replace(routes.categories);
    },
  });

  function handleFieldChanges(key: string, value: any) {
    // console.log(caller);
    const _state = structuredClone(state);
    _state[key] = value;
    setState(_state);
  }

  const attributeOptions = useMemo(() => {
    if (!attributes) return null;
    const results = attributes.map(({ id, uid, name }) => ({ id, uid, name }));
    // console.log(results);
    return results;
  }, [attributes]);

  const formik = useFormik({
    initialValues: initialState,
    validationSchema: validationSchema,
    onSubmit: async (values) => {
      // await mutation.mutate(values);
      await mutation.mutate(state);
    },
  });

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await formik.validateForm();
      await formik.submitForm();
      const errorField = document.querySelector(".error-message");
      if (errorField) {
        errorField.scrollIntoView({ behavior: "smooth", block: "center" });
      }
    } catch (error) {
      console.error("Validation error:", error);
    }
  };

  return (
    <div>
      {/* <pre>{JSON.stringify({ state, form: formik.values }, null, 2)}</pre> */}
      <ResourceFormLayout label="category details">
        <FormComposer2
          fields={[
            {
              name: "name",
              type: "string",
              placeholder: "Enter category name",
              error: (formik.touched?.name && formik.errors?.name) || false,
              message: formik.errors?.name || "",
              requiredfield: true,
              onchange: (value: string) => {
                formik.setFieldTouched("name");
                formik.handleChange({ target: { name: "name", value } });
                formik.validateField("name");
              },
            },
            {
              name: "description",
              type: "string",
              useTextArea: true,
              placeholder: "Enter category description",
              error:
                (formik.touched?.description && formik.errors?.description) ||
                false,
              message: formik.errors?.description || "",
              requiredfield: true,
              onchange: (value: string) => {
                formik.setFieldTouched("description");
                formik.handleChange({
                  target: { name: "description", value },
                });
              },
            },
          ]}
          onStateChange={(values) => {
            setState(values);
            formik.setValues({
              ...formik.values,
              name: values.name,
              description: values.description,
            });
          }}
          state={state}
        />

        <br />
        <ResourceFormLayout label="select attributes" nested>
          {attributeOptions ? (
            <MultiSelectComboBox
              field="attributes"
              onSelectionChange={(values) => {
                // console.log("onSelectionChange", values);
                handleFieldChanges("attributes", values);
              }}
              options={attributeOptions}
              selected={state.attributes}
              state={state}
            />
          ) : null}
        </ResourceFormLayout>

        <br />
        <Button
          color="light"
          className={`${
            mutation.isPending
              ? "disabled:opacity-50 disabled:cursor-not-allowed bg-slate-400"
              : ""
          }`}
          onClick={handleSubmit}
          disabled={mutation.isPending}
        >
         {mutation.isPending ? 'Creating...' : 'Create Category'}
        </Button>
      </ResourceFormLayout>
    </div>
  );
}
