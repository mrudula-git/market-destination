export const baseUrl =
  process.env.NEXT_PUBLIC_API_URL || "http://54.81.164.225:8000/api";

export const apis = {
  dashboard: "/dashboard",

  listings: "/listings",
  listingById: (id: string) => `/listings/${id}`,
  attributesOflistingById: (id: string) => `/listings/${id}/attributes`,
  categoriesOflistingById: (id: string) => `/listings/${id}/categories`,

  locationOflistingById: (id: string) => `/listings/${id}/location`,
  placesOflistingById: (id: string) => `/listings/${id}/places`,
  placeByIdOflistingById: (id: string, listingId: string) =>
    `/listings/${listingId}/places/${id}`,

  packagesOflistingById: (id: string) => `/listings/${id}/packages`,
  packageByIdOflistingById: (id: string, listingId: string) =>
    `/listings/${listingId}/packages/${id}`,

  badgesOflistingById: (id: string) => `/listings/${id}/badges`,

  categories: "/categories",
  categoryById: (id: string) => `/categories/${id}`,

  attributes: "/categories/attributes",
  attributeById: (id: string) => `/categories/attributes/${id}`,

  attributeGroups: "/categories/attribute-groups",
  attributeGroupsById: (id: string) => `/categories/attribute-groups/${id}`,

  review: "/review",
  reviews: "/reviews",
  reviewById: (id: string) => `/reviews/${id}`,

  // reviewers: "/reviewers",
  // verify:"/reviewers/verify",

  adminusers: "/adminusers",
  adminUserById: (id: string) => `/adminusers/${id}`,

  contacts: "/contacts",
  contactsById: (id: string) => `/contacts/${id}`,

  feedback: "/feedback",
  feedbackById: (id: string) => `/feedback/${id}`,

  register: "/api/auth/register",
  login: "/api/auth/login",
  forgetpassword: "/user/forget-password",
  resetpassword: "/user/reset-password",
};
