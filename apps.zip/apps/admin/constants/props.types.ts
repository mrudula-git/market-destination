export type PageProps = {
  searchParams: {
    search: string;
    page: string | number;
  };
};
