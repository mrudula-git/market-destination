export const routes = {
  home: "/",

  login: "/login",
  register: "/register",

  dashboard: "/dashboard",

  listings: "/listings",
  listingsCreate: "/listings/create",
  listingsUpdateById: (id: string) => `/listings/${id}`,
  listingsAttributesUpdateById: (id: string) => `/listings/${id}/attributes`,
  listingsPackagesUpdateById: (id: string) => `/listings/${id}/packages`,
  listingsPlacesUpdateById: (id: string) => `/listings/${id}/places`,
  listingsBadgesUpdateById: (id: string) => `/listings/${id}/badges`,

  categories: "/categories",
  categoriesCreate: "/categories/create",
  categoriesUpdateById: (id: string) => `/categories/${id}`,

  attributes: "/categories/attributes",
  attributeGroups: "/categories/attribute-groups",
  subcategories: "/categories/subcategories",

  reviews: "/reviews",
  reviewById: (id: string) => `/reviews/${id}`,
  adminUsers: "/admins",
  adminUserCreate: "/admins/create",
  adminUserUpdateById: (id: string) => `/admins/${id}`,

  feedback: "/feedback",

  notFound: "/404",
};
