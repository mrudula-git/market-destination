/* eslint-disable @typescript-eslint/no-unnecessary-condition */
import type { ColumnDef } from "@tanstack/react-table";
import {
  createColumnHelper,
  flexRender,
  getCoreRowModel,
  useReactTable,
} from "@tanstack/react-table";
import { Button, Card, Pagination, Table, TextInput } from "flowbite-react";
import { usePathname, useSearchParams } from "next/navigation";
import { Fragment, useMemo, useState } from "react";
import { useCountStore } from "../store/zustand/count.store";
import { ErrorBoundary } from "react-error-boundary";

const MAX_RESULTS_PER_PAGE = 10;

const columnHelper = createColumnHelper<any>();

function tableColums(data: string | any[], page = 1) {
  if (!data || !data.length) {
    return [];
  }

  const noColumn = columnHelper.accessor("No.", {
    cell(info) {
      const no = (page - 1) * MAX_RESULTS_PER_PAGE + (info.row.index + 1);
      return no;
    },
  });

  const columns: ColumnDef<any, any>[] = [noColumn];

  const keys = Object.keys(data[0]);
  keys.forEach((h) => {
    if (
      h.toLowerCase() === "id" ||
      h.toLowerCase() === "_id" ||
      h.toLowerCase() === "createdat" ||
      h.toLowerCase() === "updatedat"
    )
      return;
    columns.push(
      columnHelper.accessor(h, {
        header: (info) => info.column.id,
        cell: (info) => info.getValue(),
      })
    );
  });
  return columns;
}
interface DataTableProps {
  data: {
    id: string;
    name: string | null;
    type: string | null;
  }[];
  editFunction: any;
}
export default function DataTable({
  data,
  editFunction,
}: DataTableProps): JSX.Element {
  const searchParams = useSearchParams();
  const pathname = usePathname();

  const { count } = useCountStore();

  const [currentPage] = useState(searchParams.get("page") ?? "1");
  const [searchValue, setsearchValue] = useState(
    searchParams.get("search") ?? ""
  );

  function handleQueryParamsChange({
    search,
    page,
  }: {
    search?: string;
    page?: number;
  }): void {
    console.log({ search, page });
    const qs = new URLSearchParams("");
    if (search) qs.append("search", search);
    if (page) qs.append("page", page.toString());
    location.replace(pathname + qs.size ? `?${qs.toString()}` : ``);
  }

  const generateTotalPages = useMemo(() => {
    if (!count) return 1;
    return Math.ceil(count / MAX_RESULTS_PER_PAGE);
  }, [count]);

  const table = useReactTable({
    data,
    columns: tableColums(data, Number(currentPage)),
    getCoreRowModel: getCoreRowModel(),
  });

  return (
    <div>
      <br />

      <Card /* className="max-w-screen-xl mx-auto" */>
        <div className="max-w-lg ">
          <div className="flex items-center gap-2">
            <TextInput
              className="grow"
              onChange={(e) => {
                setsearchValue(e.target.value);
              }}
              placeholder="Search..."
              value={searchValue}
            />
            {searchValue ? (
              <Button
                color="failure"
                onClick={() => {
                  handleQueryParamsChange({
                    page: 1,
                  });
                }}
                outline
              >
                Clear
              </Button>
            ) : null}
            <Button
              color="blue"
              onClick={() => {
                handleQueryParamsChange({
                  search: searchValue,
                  page: 1,
                });
              }}
            >
              Search
            </Button>
          </div>
          <br />
        </div>

        <br />
        {data && data.length > 0 ? (
          <ErrorBoundary fallback={<div>Something went wrong</div>}>
            {/* <p>{JSON.stringify(table, null, 2)}</p> */}

            <Table hoverable>
              {table.getRowModel() ? (
                <Table.Head>
                  {table.getHeaderGroups().map((headerGroup) => (
                    <Fragment key={headerGroup.id}>
                      {headerGroup.headers.map((header) => (
                        <Table.HeadCell key={header.id}>
                          {header.isPlaceholder
                            ? null
                            : flexRender(
                                header.column.columnDef.header,
                                header.getContext()
                              )}
                        </Table.HeadCell>
                      ))}
                    </Fragment>
                  ))}
                  <Table.HeadCell>Action</Table.HeadCell>
                </Table.Head>
              ) : null}

              {table.getRowModel() ? (
                <Table.Body className="divide-y">
                  {table.getRowModel().rows.map((row) => (
                    <Table.Row
                      className="bg-white dark:border-gray-700 dark:bg-gray-800"
                      key={row.id}
                    >
                      {row.getVisibleCells().map((cell) => (
                        <Table.Cell
                          className="whitespace-nowrap font-medium text-gray-900 dark:text-white"
                          key={cell.id}
                        >
                          {flexRender(
                            cell.column.columnDef.cell,
                            cell.getContext()
                          )}
                        </Table.Cell>
                      ))}
                      <Table.Cell className="flex gap-2">
                        <Button
                          color="blue"
                          onClick={() => {
                            if (!editFunction) {
                              location.replace(
                                `${pathname}/${row.original.id}`
                              );
                            } else {
                              editFunction(row.original.id);
                            }
                          }}
                        >
                          Edit
                        </Button>
                        <Button
                          color="failure"
                          disabled
                          onClick={() => {
                            // onClickDelete();
                          }}
                        >
                          Delete
                        </Button>
                      </Table.Cell>
                    </Table.Row>
                  ))}
                </Table.Body>
              ) : null}
            </Table>
          </ErrorBoundary>
        ) : null}

        <br />
        <div className="flex full-width overflow-x-auto sm:justify-center">
          <Pagination
            currentPage={Number(currentPage)}
            id="table-pagination"
            onPageChange={(page) => {
              handleQueryParamsChange({ search: searchValue, page });
            }}
            totalPages={generateTotalPages}
          />
        </div>
      </Card>
    </div>
  );
}
