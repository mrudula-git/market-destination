import { Breadcrumb } from "flowbite-react";
import { usePathname } from "next/navigation";

export default function ContentBreadcrumb() {
  const pathname = usePathname();

  return (
    <Breadcrumb className="my-4">
      {/* <Breadcrumb.Item>Home</Breadcrumb.Item> */}
      {pathname.split("/").map((path) => (
        <Breadcrumb.Item className="capitalize" key={path}>
          {path}
        </Breadcrumb.Item>
      ))}
    </Breadcrumb>
  );
}
