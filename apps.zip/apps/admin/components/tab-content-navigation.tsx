"use client";

import { Tabs } from "flowbite-react";
import { useRouter } from "next/navigation";

interface Props {
  contents: any;
  activeKey?: string;
}

export default function TabContentNavigation({ contents, activeKey }: Props) {
  const router = useRouter();

  // const tabsRef = useRef<TabsRef>(null);
  // const [activeTab, setActiveTab] = useState(0);

  function handleActiveTabChange(href: string) {
    // router.push(href);
    window.location.replace(href);
  }

  return (
    <div>
      <Tabs
        aria-label="Default tabs"
        style="default"
        // ref={tabsRef}
        onActiveTabChange={(tab) => {
          handleActiveTabChange(contents.items[tab]?.href);
        }}
      >
        {contents.items.map((item) => (
          <Tabs.Item
            active={activeKey === item.key}
            icon={item.icon}
            key={item.key}
            title={item.label}
          />
        ))}
      </Tabs>
    </div>
  );
}
