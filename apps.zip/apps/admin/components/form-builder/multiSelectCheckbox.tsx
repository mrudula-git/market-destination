import React, { useState, useEffect } from "react";
import { Label } from "flowbite-react";
import { HiXMark } from "react-icons/hi2";
import { FaExclamationCircle } from "react-icons/fa";
import { humanize } from "underscore.string";
import { Icon } from "@iconify/react";

interface Option {
  id: string;
  name: string;
}

interface Props {
  state?: any;
  field?: string;
  requiredfield?: boolean;
  description?: React.ReactNode;
  options: Option[];
  placeholder?: string;
  selected: Option[];
  error?: boolean;
  message?: string;
  onSelectionChange: (selected: Option[]) => void;
}

export default function MultiSelectCheckBox({
  state = null,
  field = "",
  description = null,
  options,
  placeholder = "",
  requiredfield=false,
  selected = [],
  onSelectionChange,
  error = false,
  message = "",
}: Props) {
  const [filterInput, setFilterInput] = useState("");
  const [filteredOptions, setFilteredOptions] = useState(options);

  useEffect(() => {
    setFilteredOptions(options);
  }, [options]);

  const handleToggleOption = (option: Option) => {
    const isSelected = selected.find((item) => item.id === option.id);
    let updatedSelected: Option[] = [];
    if (isSelected) {
      updatedSelected = selected.filter((item) => item.id !== option.id);
    } else {
      updatedSelected = [...selected, option];
    }
    onSelectionChange(updatedSelected);
  };

  const handleInputChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const value = event.target.value;
    setFilterInput(value);
    const filtered = options.filter((option) =>
      option.name.toLowerCase().includes(value.toLowerCase())
    );
    setFilteredOptions(filtered);
  };

  return (
    <div>
      <div>
      <div className="flex gap-1">
        <Label
          className={`capitalize ${error ? "text-red-500" : ""}`}
          value={humanize(field)}
        />
                {requiredfield && (
          <Icon
            className="text-xs text-red-500"
            icon="material-symbols:star-rate"
          />
        )}</div>
        <div className="mb-2 text-gray-500 text-sm">{description}</div>
        {selected.length > 0 && (
          <div className="mb-2 flex gap-2 flex-wrap">
            {selected.map((option) => (
              <div key={option.id} className="group">
                <label className="flex items-center p-2.5 border-2 bg-gray-10 border-gray-100 text-gray-900 text-sm
              rounded-lg">
                   {/* <input
                    type="checkbox"
                    className="form-checkbox text-blue-500 h-4 w-4 rounded-lg"
                    checked
                    onChange={() => handleToggleOption(option)}
                  />  */}
                  <span className="ml-2">{option.name}</span>
                  <HiXMark
                    className="ml-2 p-0.5 w-5 h-5 rounded-full group-hover:bg-red-500 group-hover:text-white cursor-pointer"
                    onClick={() => handleToggleOption(option)}
                  />
                </label>
              </div>
            ))}
          </div>
        )}
        <input
          type="text"
          className={`bg-gray-50 border border-gray-300 text-gray-900 text-sm
              rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full
              p-2.5 dark:bg-gray-700 dark:border-gray-600
              dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500
              dark:focus:border-blue-500 ${error ? "border-red-500" : ""}`}
          onChange={handleInputChange}
          placeholder={placeholder ? placeholder : "Search..."}
          value={filterInput}
        />
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-2 px-1  py-2 text-sm text-gray-700 dark:text-gray-200 max-h-[200px] overflow-y-auto">
          {filteredOptions.map((option) => (
            <div key={option.id} className="block">
              <label className="flex items-center">
                <input
                  type="checkbox"
                  className="form-checkbox text-blue-500 h-4 w-4 rounded-sm"
                  checked={!!selected.find((item) => item.id === option.id)}
                  onChange={() => handleToggleOption(option)}
                />
                <span className="ml-2">{option.name}</span>
              </label>
            </div>
          ))}
        </div>
        {error && <p className="text-red-500 text-xs mt-1 error-message">{message}</p>}
      </div>
    </div>
  );
}
