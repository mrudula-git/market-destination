import React, { useState, useEffect, ReactNode } from "react";
import { Button, Label } from "flowbite-react";
import type { Key } from "react-aria-components";
import {
  ComboBox,
  Input,
  ListBox,
  ListBoxItem,
  Popover,
} from "react-aria-components";
import { HiXMark } from "react-icons/hi2";
import { FaExclamationCircle } from "react-icons/fa";
import { humanize } from "underscore.string";

interface Props {
  state?: any;
  field?: string;
  description?: ReactNode;
  options: any;
  placeholder?:string, 
  selected: any;
  error?: boolean;
  message?: string;
  onSelectionChange: (value: any) => void;
}

export default function MultiSelectComboBox({
  state = null,
  field = "",
  description = null,
  options = null,
  placeholder = "", 
  selected = null,
  onSelectionChange,
  error = false,
  message = "",
}: Props) {
  const [optionsList, setOptionsList] = useState(options ?? []);
  const [showOptions, setShowOptions] = useState(false);
  const [filterInput, setFilterInput] = useState("");
  const [selectedList, setSelectedList] = useState(selected ?? []);

  function addToSelectedList(key: Key) {
    const _selected = structuredClone(selectedList);
    const _selectedIx = _selected.findIndex((el) => el?.id === key);
    if (_selectedIx === -1) {
      _selected.push(optionsList.find((el) => el?.id === key));
      setSelectedList(_selected);
      onSelectionChange(_selected);
    }
  }

  function removeFromSelectedList(key: Key) {
    const _selected = structuredClone(selectedList);
    const _selectedIx = _selected.findIndex((el) => el?.id === key);
    if (_selectedIx > -1) {
      _selected.splice(_selectedIx, 1);
      setSelectedList(_selected);
      onSelectionChange(_selected);
    }
  }

  function handleSelectionChange(key: Key) {
    if (!key) return;
    addToSelectedList(key);
    setFilterInput("");
  }

  useEffect(() => {
    setOptionsList(options ?? []);
  }, [options]);

  if (state === null) return null;

  return (
    <div>
      <div>
        <ComboBox
          onFocusChange={(focused) => {
            setShowOptions(focused);
          }}
          onSelectionChange={handleSelectionChange}
        >
          <Label
            className={`capitalize ${error ? "text-red-500" : ""}`}
            value={humanize(field)}
          />
          <div className="mb-2 text-gray-500 text-sm">{description}</div>
          {selectedList.length > 0 && (
            <div className="mb-2 flex gap-2 flex-wrap">
              {selectedList.map((el) => (
                <Button
                  className="group"
                  color="light"
                  key={el?.id}
                  onClick={() => {
                    removeFromSelectedList(el?.id);
                  }}
                >
                  {el?.name}
                  <HiXMark className="ml-2 p-0.5 w-5 h-5 rounded-full group-hover:bg-red-500 group-hover:text-white" />
                </Button>
              ))}
            </div>
          )}
          <Input
            className={`bg-gray-50 border border-gray-300 text-gray-900 text-sm
              rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full
              p-2.5 dark:bg-gray-700 dark:border-gray-600
              dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500
              dark:focus:border-blue-500 ${error ? "border-red-500" : ""}`}
            onChange={(event) => {
              setFilterInput(event.currentTarget.value);
            }}
            placeholder={placeholder? placeholder: "Search..."}
            value={filterInput}
          />

          <Popover
            className="bg-white divide-y divide-gray-100 rounded-lg shadow w-44 dark:bg-gray-700"
            isOpen={showOptions ? filterInput : null}
          >
            <ListBox className="py-2 text-sm text-gray-700 dark:text-gray-200 max-h-[200px] overflow-y-auto">
              {optionsList.map((el) => (
                <ListBoxItem
                  className="block px-4 py-2 hover:bg-gray-100 dark:hover:bg-gray-600 dark:hover:text-white"
                  id={el?.id}
                  key={el?.id}
                >
                  {el?.name}
                </ListBoxItem>
              ))}
            </ListBox>
          </Popover>
        </ComboBox>

        {error && <p className="text-red-500 text-xs mt-1 error-message">{message}</p>}
      </div>
    </div>
  );
}
