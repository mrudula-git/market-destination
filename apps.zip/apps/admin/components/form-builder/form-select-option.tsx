import React from "react";
import { Label } from "flowbite-react";
import { FaExclamationCircle } from "react-icons/fa";
import { Icon } from "@iconify/react";

interface SelectOption {
  value: string | number;
  label: string;
}

interface Props {
  field: string;
  placeholder?: string;
  options: SelectOption[];
  onChange: (value: string | number) => void;
  value?: string | number;
  error?: boolean;
  message?: string;
  requiredfield?: boolean;
}

export default function FormSelectInput({
  field,
  options,
  onChange,
  value,
  placeholder = "",
  error = false,
  message = "",
  requiredfield,
}: Props) {
  return (
    <div>
      <div className="grid grid-cols-3 gap-3">
        <div className="col-span-1 self-center flex gap-1">
          <Label
            className={`capitalize ${error ? "text-red-500" : ""}`}
            htmlFor={field}
            value={field}
          />
          {requiredfield && (
            <Icon
              className="text-xs text-red-500"
              icon="material-symbols:star-rate"
            />
          )}
        </div>
        <div className="col-span-2 relative">
          <div className="flex">
            <select
              className={`w-full text-sm rounded-lg block border ${
                error ? "border-red-500" : "border-gray-300"
              } disabled:cursor-not-allowed disabled:opacity-50 bg-gray-50 text-gray-900 focus:border-cyan-500 focus:ring-cyan-500 dark:border-gray-600 dark:bg-gray-700 dark:text-white dark:placeholder-gray-400 dark:focus:border-cyan-500 dark:focus:ring-cyan-500 p-2.5`}
              id={field}
              onChange={(event) => {
                const selectedValue = event.target.value;
                onChange(selectedValue);
              }}
              value={value}
            >
              <option value="" disabled selected hidden>
                {placeholder}
              </option>
              {options.map((option) => (
                <option
                  className="rounded-lg h-72"
                  key={option.value}
                  value={option.value}
                >
                  {option.label}
                </option>
              ))}
            </select>
            {error && (
              <div className="absolute top-2 right-2 text-red-500">
                <FaExclamationCircle />
              </div>
            )}
          </div>
          {error && <p className="text-red-500 text-xs mt-1 error-message">{message}</p>}
        </div>
      </div>
    </div>
  );
}
