import { Label, TextInput, Checkbox } from "flowbite-react";

interface Props {
  state: any;
  fields: string[];
  onStateChange: (state: any) => void;
}

export default function FormComposer({
  state = null,
  fields = [],
  onStateChange,
}: Props) {
  function handleFieldChanges(key: string, value: any, caller = null) {
    const _state = structuredClone(state);
    _state[key] = value;
    // console.log(_state, caller);
    onStateChange(_state);
  }

  function checkField(field: string) {
    if (
      typeof state[field] === "number" ||
      typeof state[field] === "string" ||
      typeof state[field] === "boolean"
    )
      return true;

    if (typeof state[field] === "object") {
      if (state[field] === null) return true;
    }

    return false;
  }

  function getLabel(field: string) {
    const camelCaseString = field;
    const regex = /([a-z])([A-Z])/g;
    const spacedString = camelCaseString.replace(regex, "$1 $2");
    const capitalizedString = spacedString
      .replace(/^ (.)/, (str) => str.toUpperCase())
      .replace(/ (.)/g, (str) => str.toUpperCase());
    field = camelCaseString;
    return field;
  }

  if (state === null) return null;
  return (
    <div
      className="align-item-center"
      style={{
        display: "grid",
        gridTemplateColumns: "repeat(3, 1fr)",
        gridGap: 20,
      }}
    >
      {Object.keys(state).map((field) => (
        <div key={field}>
          {fields.includes(field) && checkField(field) && (
            <div>
              {typeof state[field] !== "boolean" ? (
                <Label
                  className="capitalize"
                  htmlFor={field}
                  value={getLabel(field)}
                />
              ) : null}
              {typeof state[field] === "number" ? (
                <TextInput
                  id={field}
                  min={0}
                  onChange={(event) => {
                    const value = Number(event.target.value);
                    handleFieldChanges(field, value, "form-composer");
                  }}
                  step={1}
                  value={state[field] ?? 0}
                />
              ) : typeof state[field] === "boolean" ? (
                <Checkbox
                  checked={state[field] ?? false}
                  className="m-1"
                  id={field}
                  onChange={(event) => {
                    const value = event.target.checked;
                    handleFieldChanges(field, value, "form-composer");
                  }}
                />
              ) : (
                <TextInput
                  id={field}
                  onChange={(event) => {
                    const value = event.target.value;
                    handleFieldChanges(field, value, "form-composer");
                  }}
                  value={state[field] ?? ""}
                />
              )}
              {typeof state[field] === "boolean" ? (
                <Label
                  className="capitalize"
                  htmlFor={field}
                  value={getLabel(field)}
                />
              ) : null}
            </div>
          )}
        </div>
      ))}
    </div>
  );
}
