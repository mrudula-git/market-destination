// import React, { useState } from 'react';
// import TimePicker from 'react-time-picker'

// interface TimePickerComponentProps {
//   onChange: (weekdays: { startTime: string; endTime: string }, weekends: { startTime: string; endTime: string }) => void;
// }

// function TimePickerComponent({ onChange }: TimePickerComponentProps) {
//   const [weekdaysStartTime, setWeekdaysStartTime] = useState('09:00');
//   const [weekdaysEndTime, setWeekdaysEndTime] = useState('17:00');
//   const [weekendsStartTime, setWeekendsStartTime] = useState('10:00');
//   const [weekendsEndTime, setWeekendsEndTime] = useState('18:00');

//   const handleWeekdaysChange = (event: React.ChangeEvent<HTMLInputElement>, isStart: boolean) => {
//     const value = event.target.value;
//     if (isStart) {
//       setWeekdaysStartTime(value);
//       onChange({ startTime: value, endTime: weekdaysEndTime }, { startTime: weekendsStartTime, endTime: weekendsEndTime });
//     } else {
//       setWeekdaysEndTime(value);
//       onChange({ startTime: weekdaysStartTime, endTime: value }, { startTime: weekendsStartTime, endTime: weekendsEndTime });
//     }
//   };

//   const handleWeekendsChange = (event: React.ChangeEvent<HTMLInputElement>, isStart: boolean) => {
//     const value = event.target.value;
//     if (isStart) {
//       setWeekendsStartTime(value);
//       onChange({ startTime: weekdaysStartTime, endTime: weekdaysEndTime }, { startTime: value, endTime: weekendsEndTime });
//     } else {
//       setWeekendsEndTime(value);
//       onChange({ startTime: weekdaysStartTime, endTime: weekdaysEndTime }, { startTime: weekendsStartTime, endTime: value });
//     }
//   };
//   const [value, onChange3] = useState('10:00');

//   return (
//     <div className="my-4">
//       <div className="mb-2">
//         <label className="block text-sm font-bold text-gray-700 mb-3">Weekdays Timing:</label>
//         <div className="flex gap-2">
//           <input
//             type="time"
//             className="form-input border border-gray-300 rounded w-full bg-gray-50"
//             value={weekdaysStartTime}
//             onChange={(e) => handleWeekdaysChange(e, true)}
//           />
//           <span className="text-gray-700 pt-2"> to </span>
//           <input
//             type="time"
            
//             className="form-input border border-gray-300 rounded w-full bg-gray-50"
//             value={weekdaysEndTime}
//             onChange={(e) => handleWeekdaysChange(e, false)}
//           />
//         </div>
//       </div>

//       <div>
//         <label className="block text-sm font-bold text-gray-700 mb-3">Weekends Timing:</label>
//         <div className="flex gap-2">
//           <input
//             type="time"
//             className="form-input border border-gray-300 rounded w-full bg-gray-50"
//             value={weekendsStartTime}
//             onChange={(e) => handleWeekendsChange(e, true)}
//           />
//           <TimePicker onChange={onChange3} value={value} />
//           <span className="text-gray-700 pt-2"> to </span>
//           <input
//             type="time"
//             className="form-input border border-gray-300 rounded w-full bg-gray-50"
//             value={weekendsEndTime}
//             onChange={(e) => handleWeekendsChange(e, false)}
//           />
//         </div>
//       </div>
//     </div>
//   );
// }

// export default TimePickerComponent;

import React, { useState } from 'react';
import TimePicker from 'react-time-picker';

const CustomTimePicker = () => {
  const [time, setTime] = useState(new Date());

  const handleTimeChange = (newTime) => {
    setTime(newTime);
  };

  return (
    <div className="flex items-center justify-center h-screen">
      <div>
        <label>Selected Time:</label>
        <TimePicker
          onChange={handleTimeChange}
          value={time}
          disableClock={true} // Disable the clock view
          clearIcon={null} // Remove the clear button
          format="hh:mm a" // Display AM/PM
        />
      </div>
    </div>
  );
};

export default CustomTimePicker;
