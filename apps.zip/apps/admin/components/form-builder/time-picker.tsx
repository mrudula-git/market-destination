import { TextInput } from "flowbite-react";
import { useEffect, useState } from "react";
import ReactTimePicker from "react-time-picker";
import "react-clock/dist/Clock.css";
import "react-time-picker/dist/TimePicker.css";

type Props = {
  value: string;
  onChange: (value: string) => void;
};

export default function TimePicker({ value, onChange }: Props) {
  const [time, setTime] = useState(value);

  useEffect(() => {
    setTime(value);
  }, [value]);

  return (
    <div>
      <div>
        <TextInput
          className="max-w-min"
          type="time"
          placeholder="HH:MM"
          value={time}
          onChange={(event) => {
            onChange(event?.target?.value);
          }}
        />
      </div>
      {/* <div>
        <ReactTimePicker
          // className="flowite-compound-input"
          // disableClock={true}
          // clockIcon={null}
          clearIcon={null}
          locale="en-IN"
          format="h:m a"
          hourPlaceholder="hh"
          minutePlaceholder="mm"
          value={time}
          onChange={(value) => {
            console.log(value);
            setTime(value);
            onChange(value);
          }}
        />
      </div> */}
    </div>
  );
}
