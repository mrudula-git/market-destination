import { Label, TextInput } from "flowbite-react";
import { useState, ChangeEvent, useEffect } from "react";
import { humanize } from "underscore.string";
import { FaExclamationCircle } from "react-icons/fa";
import { Icon } from "@iconify/react";

interface TimePickerProps {
  field: string;
  value?: string;
  onChange: (
    value: string,
    event: ChangeEvent<HTMLInputElement> | undefined
  ) => void;
  error?: boolean;
  message?: string;
  requiredfield?: boolean;
  placeholder?: string;
}

export default function FormTimeInput({
  field,
  value = "",
  onChange,
  error = false,
  message = "",
  requiredfield,
  placeholder = "",
}: TimePickerProps): JSX.Element {
  const [state, setState] = useState(value);

  useEffect(() => {
    setState(value);
  }, [value]);

  return (
    <div className="grid grid-cols-3 gap-3">
      <div className="col-span-1 self-center flex gap-1">
        <Label
          className={`capitalize ${error ? "text-red-500" : ""}`}
          htmlFor={field}
          value={humanize(field)}
        />
        {requiredfield && (
          <Icon
            className="text-xs text-red-500"
            icon="material-symbols:star-rate"
          />
        )}
      </div>
      <div className="col-span-2 relative">
        <TextInput
          type="time"
          id={field}
          onChange={(event) => {
            setState(event.target.value);
            onChange(event.target.value, event);
          }}
          placeholder={placeholder}
          value={state}
        />
        {error && (
          <div className="absolute top-2 right-2 text-red-500">
            <FaExclamationCircle />
          </div>
        )}
        {error && <p className="text-red-500 text-xs mt-1 error-message">{message}</p>}
      </div>
    </div>
  );
}
