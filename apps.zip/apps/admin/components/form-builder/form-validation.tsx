export function validateField(value: any, field: Field): string | null {
    if (field.required && (value === null || (typeof value === 'string' && value.trim() === ''))) {
      return 'This field is required';
    }
  
    switch (field.type) {
      case 'string':
        if (field.maxLength && value && value.length > field.maxLength) {
          return `Maximum length is ${field.maxLength}`;
        }
        break;
  
      case 'number':
        if (typeof value !== 'number') {
          return 'Please enter a valid number';
        }
        break;
  
      case 'boolean':
        if (typeof value !== 'boolean') {
          return 'Please enter a valid boolean value';
        }
        break;
  
      // Add more cases for other field types as needed
  
      default:
        break;
    }
  
    return null;
  }
  
  // Update the import statements in other files accordingly
  