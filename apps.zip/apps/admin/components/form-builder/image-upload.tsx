"use client";

import { Button, FileInput, Label, Modal } from "flowbite-react";
import ImageKit from "imagekit";
import type { ChangeEvent } from "react";
import { useState } from "react";
import apiKit from "../../utils/api.helper";
import type { Media } from "database";
import { deleteImageKitImage } from "../../app/actions";

const publicKey = process.env.NEXT_PUBLIC_IMAGEKIT_PUBLIC_KEY!;
const privateKey = process.env.NEXT_PUBLIC_IMAGEKIT_PRIVATE_KEY!;
const urlEndpoint = process.env.NEXT_PUBLIC_IMAGEKIT_URL_ENDPOINT!;

// this gets moved inside the function that generates Imakekit instance.
// this instance will get reused inside the upload function
// then upload funtion will feed data to media creation
const imagekit = new ImageKit({
  urlEndpoint,
  privateKey,
  publicKey,
});

type ImageUploadProps = {
  listingId: string;
  folderName: string;
  photos?: Media[];
};

export default function ImageUpload({
  listingId,
  folderName,
  photos,
}: ImageUploadProps) {
  const [images, setImages] = useState(photos ?? []);
  const [showModal, setShowModal] = useState(false);
  const [selectedImageIndex, setSelectedImageIndex] = useState(null);

  const handleThumbnailClick = (index: any) => {
    setShowModal(true);
    setSelectedImageIndex(index);
  };

  const closeModal = () => {
    setShowModal(false);
    setSelectedImageIndex(null);
  };

  const handleImageChange = async (
    event: ChangeEvent<HTMLInputElement>,
    listingId: string
  ) => {
    const files = event.target.files;
    if (!files) return;

    for (const file of files) {
      try {
        const imageKitResult = await imagekit.upload({
          file,
          fileName: file.name,
          folder: folderName,
        });

        console.log("ImageKit Result:", imageKitResult);
        // Create Media with some Id recived from Imagekeit
        // const ikFileId = imageKitResult.fileId;
        const mediaApiResult = await apiKit({
          api: "/media",
          method: "POST",
          body: {
            url: imageKitResult.url,
            thumbUrl: imageKitResult.thumbnailUrl,
            ikFileId: imageKitResult.fileId,
            // ikId: imageKitResult.fileId,
            // imagekitId <- imageKitId
            // cdnType: "imagekit",
            // cdnAuthKey: "your_auth_key",
            listingsId: listingId,
          },
        });

        setImages((prevImages) => [...prevImages, mediaApiResult.mediaEntry]);

        console.log("Media API Resultt:", mediaApiResult, imageKitResult);
      } catch (error) {
        console.error("Error uploading image:", error);
      }
    }
  };

  async function deleteMedia(mediaId) {
    try {
      const deleteResult = await apiKit({
        api: `/media/${mediaId}`,
        method: "DELETE",
        body: {},
      });
      // console.log("Media deleted successfully",deleteResult);
      setImages((prevImages) =>
        prevImages.filter((image) => image.id !== mediaId)
      );
    } catch (error) {
      console.log("Error deleting media", error);
    }
  }

  async function deletePhoto(photo) {
    try {
      console.log("deletePhoto - received photo:", photo);

      const fileId = photo.url?.replace(urlEndpoint, "");
      const ikFileId = photo.ikFileId;
      const mediaId = photo.id;

      // Pass Imakekit ImageId
      await deleteImageKitImage(ikFileId);

      // console.log('Media ID to delete:', mediaId);

      await deleteMedia(mediaId);

      setShowModal(false);
    } catch (error) {
      console.log("deletePhoto");
      console.log(error);
    }
  }

  return (
    <div>
      <div>
        <div className="block">
          <Label htmlFor="image-upload" value="Upload Images" />
        </div>
        <FileInput
          accept="image/*"
          helperText="PNG, JPG"
          id="image-upload"
          onChange={(event) => handleImageChange(event, listingId)}
          multiple
        />
      </div>

      <br />
      <div className="flex flex-wrap gap-2">
        {images.map((image, index) => (
          <div className="relative" key={index}>
            <img
              alt={`thumbnail-${index}`}
              className="w-32 h-32 object-cover cursor-pointer"
              onClick={() => {
                handleThumbnailClick(index);
              }}
              src={image.thumbUrl}
            />
            <button
              className="absolute top-2 right-2 bg-red-500 text-white px-2 py-1 rounded-full text-xs"
              onClick={() => {
                deletePhoto(image);
              }}
            >
              {/* Cross Icon SVG */}
              <svg
                xmlns="http://www.w3.org/2000/svg"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
                className="h-2 w-2"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth="2"
                  d="M6 18L18 6M6 6l12 12"
                />
              </svg>
            </button>
          </div>
        ))}
        {/* <pre>{JSON.stringify(photos, null, 2)}</pre> */}
      </div>

      {showModal ? (
        <Modal
          onClose={closeModal}
          size={"4xl"}
          className="h-screen"
          show={showModal}
        >
          <Modal.Header>Image Preview</Modal.Header>
          <Modal.Body>
            {selectedImageIndex !== null && (
              <img
                src={images[selectedImageIndex].url}
                alt={`preview-${selectedImageIndex}`}
              />
            )}
          </Modal.Body>
          <Modal.Footer className="flex justify-between">
            <Button color="gray" onClick={closeModal}>
              Close
            </Button>
            <Button
              color="failure"
              onClick={() => {
                deletePhoto(images[selectedImageIndex]);
              }}
            >
              Delete
            </Button>
          </Modal.Footer>
        </Modal>
      ) : null}
    </div>
  );
}
