import FormBooleanInput from "./form-boolean-input";
import FormNumberInput from "./form-number-input";
import FormSelectInput from "./form-select-option";
import FormTextInput from "./form-text-input";
import FormTimeInput from "./form-time-input";

interface Props {
  label: string;
  type: string;
  value: string | number | boolean;
  error:boolean;
  message:string;
  options: { 
    value: string | number; 
    label: string;
   }[];
  onChange: (value: string | number | boolean) => void;
}

export default function AutoTypeForm({
  label,
  type,
  value,
  error,
  message,
  options,
  onChange,
}: Props) {
  // console.log({ label, type, options, value });
  // function handleFieldChanges(key: string, value: any) {
  //   const _state = structuredClone(state);
  //   _state[key] = value;
  //   onStateChange(_state);
  //   onChange(value);
  // }

  return (
    <div className="mb-2">
      {/* <p>{label}:{type} = {JSON.stringify(value)}</p> */}
      {
        {
          string: (
            <FormTextInput
              field={label}
              onChange={(value) => {
                // handleFieldChanges(name, value);
                onChange(value);
              }}
              value={value as string}
            />
          ),
          "long-string": (
            <FormTextInput
              field={label}
              onChange={(value) => {
                // handleFieldChanges(name, value);
                onChange(value);
              }}
              useTextarea={true}
              error={error}
              message={message}
              value={value as string}
            />
          ),
          number: (
            <FormNumberInput
              field={label}
              onChange={(value) => {
                // handleFieldChanges(label, value);
                onChange(value);
              }}
              error={error}
              message={message}
              value={value as number}
            />
          ),
          boolean: (
            <FormBooleanInput
              field={label}
              onChange={(value) => {
                // handleFieldChanges(label, value);
                onChange(value);
              }}
              error={error}
              message={message}
              value={value as boolean}
            />
          ),
          select: (
            <FormSelectInput
              field={label}
              onChange={(value) => {
                onChange(value);
              }}
              options={options}
              error={error}
              message={message}
              value={value as string}
            />
          ),
          time: (
            <FormTimeInput
              field={label}
              value={value as string}
              onChange={(value) => {
                onChange(value);
              }}
              error={error}
              message={message}
            />
          ),
        }[type]
      }
    </div>
  );
}
