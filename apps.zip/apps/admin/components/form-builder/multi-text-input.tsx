import React, { ReactNode, useState } from "react";
import { Button, Label, ListGroup, TextInput, Textarea } from "flowbite-react";
import { HiXMark } from "react-icons/hi2";
import { humanize } from "underscore.string";
import { Icon } from "@iconify/react";


interface Props {
  state?: any;
  field?: string;
  onListChange: (value: any) => void;
  useTextarea?: boolean;
  error?: boolean;
  message?: string;
  description?: ReactNode;
  placeholder?: string;
  requiredfield?: boolean;
}

export default function MultiTextInput({
  state = null,
  field = "",
  onListChange,
  useTextarea = false,
  error = false,
  message = "",
  description = null,
  placeholder = "",
  requiredfield,
}: Props) {
  const [input, setInput] = useState("");
  const [list, setList] = useState(state?.[field] ?? []);

  function addToList(item: string) {
    if (!item) {
      return;
    }
  
    const _list = structuredClone(list);
    _list.push(item);
    setList(_list);
    onListChange(_list);
    setInput("");
  }

  function removeFromList(key: number) {
    const _list = structuredClone(list);
    _list.splice(key, 1);
    setList(_list);
    onListChange(_list);
  }

  const InputComponent = useTextarea ? Textarea : TextInput;

  return (
    <div>
      <br />
      <div className="flex gap-1">
        <Label
          className={`capitalize ${error ? "text-red-500" : ""}`}
          value={humanize(field)}
        />
        {requiredfield && (
          <Icon
            className="text-xs text-red-500"
            icon="material-symbols:star-rate"
          />
        )}
      </div>
      <p className="text-sm text-gray-500 pl-1 pb-1">{description}</p>
      <form className="flex gap-2">
        <InputComponent
          className={`flex-grow placeholder:text-slate-400 placeholder:text-sm border p-2 rounded-md focus:outline-none focus:ring focus:border-blue-300 ${
            error ? "border-red-500" : "border-gray-300"
          }`}
          onKeyDown={(e) => {
            if (e.key === "Enter") {
              e.preventDefault();
              if (input) {
                addToList(input);
                setInput("");
              }
            }
          }}
          onChange={(event) => {
            setInput(event.target.value);
          }}
          onKeyPress={(event) => {
            if (event.key === "Enter") {
              if (input.trim() === "") {
              } else {
                addToList(input.trim());
                setInput("");
              }
            }
          }}
          placeholder={placeholder}
          value={input}
        />
        <Button
          color="light"
          onClick={() => {
            addToList(input.trim());
            setInput("");
          }}
        >
          Add
        </Button>
      </form>

      {error && <p className="text-red-500 text-xs mt-1 error-message">{message}</p>}

      <div className="mt-2">
        <ListGroup className="overflow-hidden">
          {list.map((item, key) => (
            <ListGroup.Item
              className="group"
              color="light"
              key={key}
              onClick={() => {
                removeFromList(key);
              }}
            >
              <div className="w-full flex justify-between">
                <div className="text-left">{item}</div>
                <HiXMark className="ml-2 p-0.5 w-5 h-5 rounded-full group-hover:bg-red-500 group-hover:text-white" />
              </div>
            </ListGroup.Item>
          ))}
        </ListGroup>
      </div>
    </div>
  );
}
