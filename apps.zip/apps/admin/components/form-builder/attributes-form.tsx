import { useEffect, useState } from "react";
import { Button } from "flowbite-react";
import { useListingStore } from "../../store/zustand/listings.store";
import ResourceFormLayout from "../../layouts/resource-form-layout";
import AutoTypeForm from "./auto-type-form";

export default function AttributesForm({
  onChange,
  onSectionSave,
  onCompleteSave,
  disabled,
}) {
  const { listing } = useListingStore();

  const [attributes, setAttributes] = useState(listing?.attributes);
  const [errors, setErrors] = useState({});

  useEffect(() => {
    setAttributes(listing?.attributes ?? []);
  }, [listing?.attributes]);

  function handleAttributesChange(attribute, value) {
    const { id, uid, name, type, iconUrl } = attribute;
    const _attributes = structuredClone(attributes);
    const _attributeIx = _attributes.findIndex((el) => el.id === id);
    const _attribute = { id, uid, name, type, value, iconUrl };
    if (_attributeIx > -1) _attributes[_attributeIx] = { ..._attribute };
    else _attributes.push(_attribute);
    setAttributes(_attributes);
    onChange(_attributes);
  }

  function handleCompleteAttributesSave() {
    onCompleteSave(attributes);
  }

  return (
    <div>
      <h3>Attributes By Categories</h3>
      {listing?.categories?.map((category) => (
        <div key={category.id}>
          <br />
          <ResourceFormLayout label={`${category.name} details`} nested>
            <p>{category.description}</p>
            <br />
            {category?.attributes?.map((attribute) => (
              <div key={attribute.id}>
                <div>
                  <AutoTypeForm
                    label={attribute.name}
                    onChange={(value) => {
                      handleAttributesChange(attribute, value);
                    }}
                    type={attribute.type}
                    value={
                      attributes?.find((el) => el.id === attribute.id)?.value
                    }
                    options={attribute.options || []}
                    error={errors[attribute.id]}
                    message={errors[attribute.id]}
                  />
                </div>
              </div>
            ))}
            <br />

          </ResourceFormLayout>
          <br />
        </div>
      ))}

      <br />
      <hr />
      <br />

      <h3>Attributes By Groups</h3>
      {listing?.attributeGroups?.map((attributeGroups) => (
        <div key={attributeGroups.id}>
          <br />
          <ResourceFormLayout label={`${attributeGroups.name} details`} nested>
            <p>{attributeGroups.description}</p>
            <br />
            {attributeGroups?.attributes?.map((attribute) => (
              <div key={attribute.id}>
                <div>
                  <AutoTypeForm
                    label={attribute.name}
                    onChange={(value) => {
                      // console.log(value);
                      handleAttributesChange(attribute, value);
                    }}
                    type={attribute.type}
                    value={
                      attributes?.find((el) => el.id === attribute.id)?.value
                    }
                    options={attribute.options || []}
                    error={errors[attribute.id]}
                    message={errors[attribute.id]}
                  />
                </div>
              </div>
            ))}

            <br />
          </ResourceFormLayout>
          <br />
        </div>
      ))}

      <br />
      <Button
        color="light"
        className={`${
          disabled
            ? "disabled:opacity-50 disabled:cursor-not-allowed bg-slate-400"
            : ""
        }`}
        disabled={disabled}
        onClick={() => {
          handleCompleteAttributesSave();
        }}
      >
      {disabled ? 'Saving...' : 'Save all'}

      </Button>

     
    </div>
  );
}
