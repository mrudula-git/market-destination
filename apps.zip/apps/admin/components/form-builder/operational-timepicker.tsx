import { Button, Label } from "flowbite-react";
import TimePicker from "./time-picker";
import { use, useEffect, useState } from "react";
import { humanize } from "underscore.string";
import AutoTypeForm from "./auto-type-form";

type Timings = {
  name: string;
  start: string;
  end: string;
};

type OperationalTimePickerProps = {
  state?: Timings[];
  onChange: (timings: Timings[]) => void;
};

const weekdaysInitialState = {
  name: "weekdays",
  start: "",
  end: "",
};

const weekendsInitialState = {
  name: "weekends",
  start: "",
  end: "",
};

export default function OperationalTimePicker({
  state,
  onChange,
}: OperationalTimePickerProps) {
  const [wd, setWd] = useState(state?.[0] || weekdaysInitialState);
  const [we, setWe] = useState(state?.[1] || weekendsInitialState);

  useEffect(() => {
    if (!state?.length) return;

    setWd(state[0]!);
    setWe(state[1]!);
  }, [state]);

  useEffect(() => {
    onChange([wd, we]);
  }, [wd.start, wd.end, we.start, we.end]);

  return (
    <div>
      <div className="mb-2">
        <Label>Operational times</Label>
        <p className="text-gray-500 text-sm">
          The time in which place accepts customers
        </p>
      </div>

      <div className="text-sm">
        <div className="flex items-baseline gap-2 mb-1">
          <p>
            On <span className="font-medium">{humanize(wd.name)}</span> opens at{" "}
          </p>
          <TimePicker
            value={wd.start}
            onChange={(value) => {
              setWd({ ...wd, start: value });
            }}
          />
          {/* <AutoTypeForm
            label="timimg"
            value={wd.start}
            onChange={(value) => {
              setWd({ ...wd, start: value });
            }}
            type="time"
            error={false}
            message="message"
            // options={value="er"}
          /> */}
          <p> & closes at </p>
          <TimePicker
            value={wd.end}
            onChange={(value) => {
              setWd({ ...wd, end: value });
            }}
          />
          {/* <AutoTypeForm
            label="timimg"
            value={wd.end}
            onChange={(value) => {
              setWd({ ...wd, end: value });
            }}
            type="time"
            error={false}
            message="message"
            // options={value="er"}
          /> */}
        </div>
        {/* <pre>{JSON.stringify(wd, null, 2)}</pre> */}

        <div className="flex items-baseline gap-2 mb-1">
          <p>
            On <span className="font-medium">{humanize(we.name)}</span> opens at{" "}
          </p>
          <TimePicker
            value={we.start}
            onChange={(value) => {
              setWe({ ...we, start: value });
            }}
          />
          {/* <AutoTypeForm
            label="timimg"
            value={we.start}
            onChange={(value) => {
              setWe({ ...we, start: value });
            }}
            type="time"
            error={false}
            message="message"
          /> */}
          <p> & closes at </p>
          <TimePicker
            value={we.end}
            onChange={(value) => {
              setWe({ ...we, end: value });
            }}
          />
          {/* <AutoTypeForm
            label="timimg"
            value={we.end}
            onChange={(value) => {
              setWe({ ...we, end: value });
            }}
            type="time"
            error={false}
            message="message"
          /> */}
        </div>
        {/* <pre>{JSON.stringify(we, null, 2)}</pre> */}
      </div>

      <div className="flex items-center gap-2">
        {/* <Button
          color="gray"
          onClick={() => {
            // onConfirm();
          }}
        >
          Confirm
        </Button> */}
        <div className="text-sm">
          {wd?.start && wd?.end && (
            <div>
              On {humanize(wd.name)} place opens at {formatTo12Hour(wd.start)}{" "}
              and closes at {formatTo12Hour(wd.end)}
            </div>
          )}
          {we.start && we.end && (
            <div>
              On {humanize(we.name)} place opens at {formatTo12Hour(we.start)}{" "}
              and closes at {formatTo12Hour(we.end)}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function formatTo12Hour(time: string) {
  const [hours, minutes] = time.split(":");
  const _hours = parseInt(hours!);
  const _minutes = parseInt(minutes!);
  const _ampm = _hours >= 12 ? "PM" : "AM";
  const _hours12 = _hours % 12 || 12;
  return `${_hours12}:${_minutes} ${_ampm}`;
}
