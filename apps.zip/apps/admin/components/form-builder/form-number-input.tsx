import React from "react";
import { Label } from "flowbite-react";
import { FaExclamationCircle } from "react-icons/fa";
import { TextInput } from "flowbite-react";
import type { ChangeEvent } from "react";
import { humanize } from "underscore.string";
import { Icon } from "@iconify/react";

interface FormNumberInputProps {
  field: string;
  value?: number;
  placeholder?: string;
  onChange: (
    value: number,
    event: ChangeEvent<HTMLInputElement> | undefined
  ) => void;
  error?: boolean;
  message?: string;
  requiredfield?: boolean;
}

export default function FormNumberInput({
  field,
  value,
  onChange,
  error = false,
  message = "",
  placeholder = "",
  requiredfield,
  ...extraProps
}: FormNumberInputProps): JSX.Element {
  return (
    <div className="grid grid-cols-3 gap-3">
      <div className="col-span-1 self-center">
        <Label
          className={`capitalize ${error ? "text-red-500" : ""}`}
          htmlFor={field}
          value={humanize(field)}
        />
        {requiredfield && (
          <Icon
            className="text-xs text-red-500"
            icon="material-symbols:star-rate"
          />
        )}
      </div>
      <div className="col-span-2 relative">
        <TextInput
          id={field}
          type="number"
          {...extraProps}
          placeholder={placeholder}
          color={error ? "failure" : "gray"}
          onChange={(event) => {
            const inputValue = Number(event.target.value);
            onChange(inputValue, event);
          }}
          value={value}
          className={`w-full text-sm rounded-lg block ${
            error ? "border-red-500" : "border-gray-300"
          } disabled:cursor-not-allowed disabled:opacity-50 bg-gray-50 text-gray-900 focus:border-cyan-500 focus:ring-cyan-500 dark:border-gray-600 dark:bg-gray-700 dark:text-white dark:placeholder-gray-400 dark:focus:border-cyan-500 dark:focus:ring-cyan-500`}
        />
        {error && (
          <div className="absolute top-2 right-2 text-red-500">
            <FaExclamationCircle />
          </div>
        )}
        {error && <p className="text-red-500 text-xs mt-1 error-message">{message}</p>}
      </div>
    </div>
  );
}
