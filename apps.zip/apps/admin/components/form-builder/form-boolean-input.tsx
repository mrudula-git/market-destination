import React from "react";
import { Checkbox, Label } from "flowbite-react";
import { FaExclamationCircle } from "react-icons/fa";
import { useState, type ChangeEvent, useEffect } from "react";
import { humanize } from "underscore.string";

interface FormBooleanInputProps {
  field: string;
  value?: boolean;
  placeholder?: string;
  onChange: (
    value: boolean,
    event: ChangeEvent<HTMLInputElement> | undefined
  ) => void;
  error?: boolean;
  message?: string;
}

export default function FormBooleanInput({
  field,
  value,
  onChange,
  placeholder = "",
  error = false,
  message = "",
  ...extraProps
}: FormBooleanInputProps): JSX.Element {
  const [state, setState] = useState(value);

  useEffect(() => {
    setState(value);
  }, [value]);

  return (
    <div className="grid grid-cols-3 gap-3 h-10 relative">
      <div className="col-span-1 self-center">
        <Label
          className={`capitalize ${error ? "text-red-500" : ""}`}
          htmlFor={field}
          value={humanize(field)}
        />
      </div>
      <div className="col-span-2 self-center relative">
        <Checkbox
          id={field}
          {...extraProps}
          checked={state}
          placeholder={placeholder}
          onChange={(event) => {
            setState(event.target.checked);
            onChange(event.target.checked, event);
          }}
        />
        {error && (
          <div className="absolute top-2 right-2 text-red-500">
            <FaExclamationCircle />
          </div>
        )}
        {error && <p className="text-red-500 text-xs mt-1 error-message">{message}</p>}
      </div>
    </div>
  );
}
