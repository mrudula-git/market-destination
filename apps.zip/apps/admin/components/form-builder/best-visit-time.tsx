import { Button, Label, Select } from "flowbite-react";
import { useEffect, useState } from "react";

type MonthDuration = {
  start: string;
  end: string;
};

interface BestVisitTimeProps {
  state?: MonthDuration[];
  onChange: (duration: MonthDuration) => void;
}

const monthsList = [
  "January",
  "February",
  "March",
  "April",
  "May",
  "June",
  "July",
  "August",
  "September",
  "October",
  "November",
  "December",
];

const listFormatter = new Intl.ListFormat("en", {
  style: "narrow",
  type: "unit",
});

const initialState = {
  start: "January",
  end: "December",
};

export default function BestVisitTime({ state, onChange }: BestVisitTimeProps) {
  const [months, setMonths] = useState(state?.[0] || initialState);
  const [preview, setPreview] = useState("");

  // useEffect(() => {
  //   if (!state?.length) return;

  //   // console.log("len >1");
  //   // setMonths(state[0]);
  // }, [state]);

  useEffect(() => {
    // console.log("on Confirm");
    const _preview = listFormatter.format([months.start, months.end]);
    setPreview(_preview);
    onChange && onChange(months);
  }, [months.start, months.end]);

  // function onConfirm() {
  //   const _preview = listFormatter.format([months.start, months.end]);
  //   setPreview(_preview);
  //   onChange && onChange(months);
  // }

  return (
    <div>
      <div className="mb-2">
        <Label>Best time to visit</Label>
        <p className="text-sm text-gray-500">
          Best time of the year to visit the place, based on festivals or
          seasons.
        </p>
      </div>

      <div>
        <div className="flex items-baseline gap-2 text-sm mb-2">
          <p>Best visit during</p>
          <div>
            <Label></Label>
            <Select
              value={months.start}
              onChange={(event) => {
                setMonths({ ...months, start: event.target.value });
              }}
            >
              {monthsList.map((m) => (
                <option key={m} value={m}>
                  {m}
                </option>
              ))}
            </Select>
          </div>
          <p>to</p>
          <div>
            <Label></Label>
            <Select
              value={months.end}
              onChange={(event) => {
                setMonths({ ...months, end: event.target.value });
              }}
            >
              {monthsList.map((m) => (
                <option key={m} value={m}>
                  {m}
                </option>
              ))}
            </Select>
          </div>
        </div>
        <div className="flex items-center gap-2">
          {/* <Button
            color="gray"
            onClick={() => {
              // onConfirm();
            }}
          >
            Confirm
          </Button> */}
          {/* <div className="text-sm">{preview}</div> */}
        </div>
      </div>
      {/* <pre>{JSON.stringify(months, null, 2)}</pre>
      <pre>{JSON.stringify(state, null, 2)}</pre> */}
    </div>
  );
}
