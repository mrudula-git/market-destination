import React, { ChangeEvent, useEffect, useState } from "react";
import { Label, TextInput, Textarea } from "flowbite-react";
import { FaExclamationCircle } from "react-icons/fa";
import { humanize } from "underscore.string";
import { Icon } from "@iconify/react";

interface FormTextInputProps {
  field: string;
  value?: string;
  placeholder?: string;
  onChange: (
    value: string,
    event: ChangeEvent<HTMLInputElement | HTMLTextAreaElement> | undefined
  ) => void;
  useTextarea?: boolean;
  error?: boolean;
  message?: string;
  disable?: boolean;
  requiredfield?: boolean;
}

export default function FormTextInput({
  field,
  value = "",
  onChange,
  useTextarea = false,
  error = false,
  message = "",
  disable = false,
  requiredfield,
  placeholder = "",
  ...extraProps
}: FormTextInputProps): JSX.Element {
  const [state, setState] = useState(value);

  useEffect(() => {
    setState(value);
  }, [value]);

  const InputComponent = useTextarea ? Textarea : TextInput;

  return (
    <div className="grid grid-cols-3 gap-3">
      <div className="col-span-1 self-center flex gap-1">
        <Label
          className={`capitalize ${error ? "text-red-500" : ""}`}
          htmlFor={field}
          value={humanize(field)}
        />
        {requiredfield && (
          <Icon
            className="text-xs text-red-500"
            icon="material-symbols:star-rate"
          />
        )}
      </div>
      <div className="col-span-2 relative">
        <InputComponent
          autoCapitalize="on"
          id={field}
          placeholder={placeholder}
          {...extraProps}
          color={error ? "failure" : "gray"}
          // className={`border ${error ? "border-red-500" : "border-gray-300"}  rounded-lg focus:outline-none focus:ring focus:border-blue-300`}
          onChange={(event) => {
            setState(event.target.value);
            onChange(event.target.value, event);
          }}
          value={state}
          disabled={disable}
        />
        {error && (
          <div className="absolute top-2 right-2 text-red-500">
            <FaExclamationCircle />
          </div>
        )}
        {error && <p className="text-red-500 text-xs mt-1 error-message">{message}</p>}
      </div>
    </div>
  );
}
