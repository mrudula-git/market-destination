import { useState } from "react";
import FormTextInput from "./form-text-input";
import FormNumberInput from "./form-number-input";
import FormBooleanInput from "./form-boolean-input";
import FormSelectInput from "./form-select-option";
import MultiTextInput from "./multi-text-input";
import FormTimeInput from "./form-time-input";

interface Field<T = any> {
  options?: { value: string | number; label: string }[];
  name: string;
  type: string;
  placeholder?: string;
  requiredfield?: boolean;
  useTextArea?: boolean;
  onchange?: (value: T) => void;
  default?: string | number | boolean;
  label?: string;
  error?: boolean;
  message?: string;
  disable?: boolean;
}

interface FormComposerProps {
  state: Record<string, any> | null;
  initialState?: Record<string, any> | null;
  fields: Field[];
  onStateChange?: (values: any) => void;
}

export default function FormComposer2({
  state = null,
  initialState = null,
  fields = [],
  onStateChange,
}: FormComposerProps) {
  const [selectedTime, setSelectedTime] = useState("");

  function handleChange(key: string, value: any) {
    // Update the state
    const _state = { ...state, [key]: value };
    onStateChange?.(_state);
    // Execute the onchange function if provided
    const field = fields.find((f) => f.name === key);
    if (field && field.onchange) {
      field.onchange(value);
    }
  }

  if (state === null) {
    if (initialState !== null) {
      state = { ...initialState };
    } else return null;
  }

  return (
    <div>
      {/* <p className="text-xs text-gray-600 mb-2">Id: {state.id}</p> */}
      {Object.keys(state).map((field) => (
        <div key={field}>
          {/* <div>{fields.map((f) => f.name).join(", ")}</div> */}
          {/* <div>{JSON.stringify(state, null, 2)}</div> */}
          {fields.map((f) => (
            <div key={f.name}>
              {f.name === field && (
                <div className="mb-2">
                  {
                    {
                      string: (
                        <FormTextInput
                          field={f.label || f.name}
                          onChange={(value) => handleChange(f.name, value)}
                          value={
                            (state?.[f.name] as string) ?? (f.default as string)
                          }
                          useTextarea={f.useTextArea ? true : false}
                          error={f.error || false}
                          message={f.message}
                          disable={f.disable}
                          requiredfield={f.requiredfield}
                          placeholder={f.placeholder ?? ""}
                        />
                      ),
                      number: (
                        <FormNumberInput
                          field={f.name}
                          onChange={(value) => handleChange(f.name, value)}
                          value={
                            (state?.[f.name] as number) ?? (f.default as number)
                          }
                          error={f.error || false}
                          message={f.message}
                          requiredfield={f.requiredfield}
                          placeholder={f.placeholder ?? ""}
                        />
                      ),
                      boolean: (
                        <FormBooleanInput
                          field={f.label || f.name}
                          onChange={(value) => handleChange(f.name, value)}
                          value={
                            (f.default as number) || (state?.[f.name] as number)
                          }
                          error={f.error || false}
                          message={f.message}
                          requiredfield={f.requiredfield}
                          placeholder={f.placeholder ?? ""}
                        />
                      ),
                      select: (
                        <>
                          <FormSelectInput
                            field={f.label || f.name}
                            onChange={(value) => {
                              handleChange(f.name, value);
                            }}
                            options={f.options || []}
                            value={state?.[f.name] ?? f.default}
                            error={f.error || false}
                            message={f.message}
                            requiredfield={f.requiredfield}
                            placeholder={f.placeholder ?? ""}
                          />
                          <div className="grid grid-cols-3 gap-3">
                            <div className="col-span-1"></div>
                            <div className="col-span-2">
                              {state?.[f.name] === "select" && (
                                <MultiTextInput
                                  field={`options`}
                                  onListChange={(options) => {
                                    const _options = options?.map(
                                      (option: string, index: number) => ({
                                        label: option,
                                        value: index,
                                      })
                                    );
                                    handleChange(`options`, _options);
                                  }}
                                  state={state[f.name] || []}
                                  error={f.error || false}
                                  message={f.message}
                                  requiredfield={f.requiredfield}
                                  placeholder={f.placeholder ?? ""}
                                />
                              )}
                            </div>
                          </div>
                        </>
                      ),
                      time: (
                        <FormTimeInput
                          field={f.label || f.name}
                          value={selectedTime}
                          onChange={(time) => {
                            setSelectedTime(time);
                            handleChange(f.name, time);
                          }}
                          error={f.error || false}
                          message={f.message}
                          requiredfield={f.requiredfield}
                        />
                      ),
                    }[f.type]
                  }
                </div>
              )}
            </div>
          ))}
        </div>
      ))}
    </div>
  );
}
