"use client";

import { Sidebar } from "flowbite-react";
import { useRouter } from "next/navigation";
import { AiFillProfile } from "react-icons/ai";
import { FaUserCog } from "react-icons/fa";
import {
  HiBell,
  HiBellAlert,
  HiChatBubbleBottomCenter,
  HiTag,
} from "react-icons/hi2";
import { MdSpaceDashboard } from "react-icons/md";
import { routes } from "../constants/routes";
import { routeModule } from "next/dist/build/templates/app-page";

export default function SideNavigation() {
  const contents = {
    groups: [
      {
        items: [
          { label: "Dashboard", icon: MdSpaceDashboard, href: routes.home },
          // {
          //   label: "Admins",
          //   icon: FaUserCog,
          //   href: routes.adminUsers,
          //   children: [
          //     { label: "Admins", href: routes.adminUsers },
          //     // { label: "Add User", href: routes.adminUserCreate },
          //   ],
          // },
          {
            label: "Listings",
            icon: AiFillProfile,
            href: routes.listings,
            children: [
              { label: "Listings", href: routes.listings },
              // { label: "Featured" },
              // { label: "Others" },
            ],
          },
          // {
          //   label: "Categories",
          //   icon: HiTag,
          //   href: routes.categories,
          //   children: [
          //     { label: "Categories", href: routes.categories },
          //     // { label: "", href: routes.subcategories },
          //   ],
          // },
          // {
          //   label: "Reviews",
          //   icon: HiChatBubbleBottomCenter,
          //   href: routes.reviews,
          //   children: [{ label: "Reviews", href: routes.reviews }],
          // },
          {
            label: "Feedbacks",
            icon: HiBellAlert,
            href: routes.feedback,
            children: [{ label: "Feedbacks", href: routes.feedback }],
          },
        ],
      },
      {
        // items
      },
    ],
  };

  return (
    <Sidebar className="pt-4">
      <Sidebar.Items>
        {contents.groups.map((group, groupKey) => (
          <Sidebar.ItemGroup className="border-t-0" key={groupKey}>
            {group.items?.map((item, itemKey) =>
              item.children ? (
                <Sidebar.Collapse
                  icon={item.icon}
                  key={itemKey}
                  label={item.label}
                >
                  <div>
                    {item.children.map((child, childKey) => (
                      <Sidebar.Item href={child.href} key={childKey}>
                        {child.label}
                      </Sidebar.Item>
                    ))}
                  </div>
                </Sidebar.Collapse>
              ) : (
                <Sidebar.Item href={item.href} icon={item.icon} key={itemKey}>
                  {item.label}
                </Sidebar.Item>
              )
            )}
          </Sidebar.ItemGroup>
        ))}
      </Sidebar.Items>
    </Sidebar>
  );
}
