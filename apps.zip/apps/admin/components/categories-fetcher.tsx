"use client";

import { useQuery } from "@tanstack/react-query";
import { useEffect } from "react";
import { apis } from "../constants/apis";
import { useCategoryStore } from "../store/zustand/categories.store";
import apiKit from "../utils/api.helper";
import { useSearchParams } from "next/navigation";

async function getAttributes(query: any) {
  return apiKit({
    api: apis.attributes,
    query: {
      ...query,
      take: "all",
    },
    showToast:false
  });
}

export default function CategoriesFetcher(): null {
  const searchParams = Object.fromEntries(useSearchParams());

  const { setAttributes } = useCategoryStore();

  const { data: { attributes } = {} } = useQuery({
    queryKey: ["attributes"],
    queryFn: () => getAttributes(searchParams),
  });

  useEffect(() => {
    if (!attributes) return;
    setAttributes(attributes);
  }, [attributes, setAttributes]);

  return null;
}
