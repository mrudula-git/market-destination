import { Button } from "flowbite-react";
import { useState } from "react";
import { apis } from "../../constants/apis";
// import { useCategoryStore } from "../../store/zustand/categories.store";
import apiKit from "../../utils/api.helper";
import FormComposer from "../form-builder/form-composer";
// import MultiSelectComboBox from "../form-builder/multiselect-combobox";

const initialState = {
  primaryEmail: null,
  primaryPhoneNumber: null,
  secondaryEmail: null,
  secondaryPhoneNumber: null,
  country: null,
  city: null,
  district: null,
  state: null,
  pinCode: null,
  companyName: null,
};

// async function getcontacts() {
//   return apiKit({
//     api: apis.contacts,
//   });
// }

export default function CreateContactForm() {
  //   const { attributes, setAttributes } = useCategoryStore();

  const [state, setState] = useState(initialState);

  //   useEffect(() => {
  //     (async () => {
  //       const { contacts: adminUserData } = await getcontacts();
  //       setAttributes(adminUserData);
  //     })();
  //   }, []);

  function handleFieldChanges(key: string, value: any, caller = null) {
    // console.log(caller);
    const _state = structuredClone(state);
    _state[key] = value;
    setState(_state);
  }

  //   const attributeOptions = useMemo(() => {
  //     if (!attributes) return null;
  //     const results = attributes.map(({ id, name }) => ({ id, name }));
  //     console.log(results);
  //     return results;
  //   }, [attributes]);

  async function createContact() {
    const data = await apiKit({
      api: apis.contacts,
      method: "POST",
      body: state,
    });
  }

  return (
    <div>
      <FormComposer
        fields={[
          "primaryEmail",
          "primaryPhoneNumber",
          "secondaryEmail",
          "active",
          "country",
          "city",
          "district",
          "state",
          "pinCode",
          "companyName",
        ]}
        onStateChange={(values) => {
          console.log("onStateChange", values);
          setState(values);
        }}
        state={state}
      />

      <div className="my-4">
        <Button
          color="light"
          onClick={() => {
            console.log("save ", state);
            createContact();
          }}
        >
          Submit
        </Button>
        c
      </div>
    </div>
  );
}
