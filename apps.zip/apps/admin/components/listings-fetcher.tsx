"use client";

import { useQuery } from "@tanstack/react-query";
import { useParams } from "next/navigation";
import { useEffect } from "react";
import { apis } from "../constants/apis";
import { useListingStore } from "../store/zustand/listings.store";
import apiKit from "../utils/api.helper";

async function getListing(id: string) {
  return apiKit({
    api: apis.listingById(id),
    showToast:false
  });
}

export default function ListingsFetcher(): null {
  const { id } = useParams();

  const { setListing } = useListingStore();

  const { data: { listing } = {} } = useQuery({
    queryKey: ["listing"],
    queryFn: () => getListing(id as string),
  });

  useEffect(() => {
    if (!listing) return;
    setListing(listing);
  }, [listing, setListing]);

  return null;
}
