import type {
  ListingsAttributes,
  ListingsAttributesGroup,
  ListingsCategories,
} from "database";
import { create } from "zustand";

interface ZState {
  category: ListingsCategories | null;
  categories: ListingsCategories[] | null;
  attributes: ListingsAttributes[] | null;
  attributeGroups: ListingsAttributesGroup[] | null;
}
interface ZAction {
  setCategory: (category: ZState["category"]) => void;
  setCategories: (categories: ZState["categories"]) => void;
  setAttributes: (attributes: ZState["attributes"]) => void;
  setAttributeGroups: (attributeGroups: ZState["attributeGroups"]) => void;
}

export const useCategoryStore = create<ZState & ZAction>((set) => ({
  category: null,
  attributes: null,
  categories: null,
  attributeGroups: null,

  setCategory: (_category) => {
    // console.log(_category);
    set(() => ({ category: _category }));
  },
  setCategories: (_attributes) => {
    // console.log(_category);
    set(() => ({ categories: _attributes }));
  },
  setAttributes: (_attributes) => {
    // console.log(_category);
    set(() => ({ attributes: _attributes }));
  },
  setAttributeGroups: (_attributesGroup) => {
    // console.log(_category);
    set(() => ({ attributeGroups: _attributesGroup }));
  },
}));
