import type { Listings } from "database";
import { create } from "zustand";

interface ZState {
  listing: Listings | null;
}
interface ZAction {
  setListing: (listing: ZState["listing"]) => void;
}

export const useListingStore = create<ZState & ZAction>((set) => ({
  listing: null,
  setListing: (_listing) => {
    // console.log(_category);
    set(() => ({ listing: _listing }));
  },
}));
