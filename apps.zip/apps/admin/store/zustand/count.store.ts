import { create } from "zustand";

type ZState = {
  count: number | null;
};
type ZAction = {
  setCount: (review: ZState["count"]) => void;
};

export const useCountStore = create<ZState & ZAction>((set) => ({
  count: null,
  setCount: (_count: any) => {
    set(() => ({ count: _count }));
  },
}));
