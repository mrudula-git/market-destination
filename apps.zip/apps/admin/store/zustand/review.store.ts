import type { Reviews } from "database";
import { create } from "zustand";

interface ZState {
    review: Reviews | null; 
};

interface ZAction {
    setReview: (review: ZState["review"]) => void;
  }

  export const useReviewStore = create<ZState & ZAction>((set) => ({
    review: null,
    setReview : (_reviews) => {
        set(()=>({review: _reviews}));
    }
  }));
