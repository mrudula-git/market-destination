"use client";

import { useSession } from "next-auth/react";
import { redirect, usePathname } from "next/navigation";
import Shell from "../components/shell";

import { routes } from "../constants/routes";

export default function DefaultLayout({ children }: any) {
  const path = usePathname();
  const { status, data } = useSession();

  if (
    path === "/login" ||
    path === "/register" ||
    path === "/forget-password" ||
    path === "/reset-password" ||
    path === "/404"
  ) {
    return <>{children}</>;
  }

  if (status === "unauthenticated") {
    redirect(routes.login);
  }

  return (
    <>
      <Shell>{children}</Shell>
    </>
  );
}
