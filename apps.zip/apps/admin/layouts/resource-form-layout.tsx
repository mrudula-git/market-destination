import { Card, Button } from "flowbite-react";
import type { ReactNode } from "react";
import { Icon } from "@iconify/react";

type Props = {
  label: string;
  children: ReactNode;
  nested?: boolean;
  onClose?: () => void;
};

export default function ResourceFormLayout({
  label,
  children,
  nested = false,
  onClose,
}: Props): JSX.Element {
  return (
    <Card className={nested ? " " : " "}>
      <div className="flex justify-between items-center mb-4">
        <h4 className="capitalize">{label}</h4>
        {onClose && (
          <Icon className="w-6 h-6 cursor-pointer" icon="mdi:close" onClick={onClose} />
        )}
      </div>
      <div>{children}</div>
    </Card>
  );
}
