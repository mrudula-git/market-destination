"use client";

import { useParams } from "next/navigation";
import { routes } from "../constants/routes";
import TabContentNavigation from "../components/tab-content-navigation";

type Props = {
  activeKey?: string;
};

export default function ListingTabLayout({ activeKey }: Props) {
  const { id } = useParams();

  const contents = {
    items: [
      { key: "listing", label: "Listing", href: routes.listingsUpdateById(id) },
      {
        key: "listing_attributes",
        label: "Attributes",
        href: routes.listingsAttributesUpdateById(id),
      },
      {
        key: "listing_packages",
        label: "Prices & Packages",
        href: routes.listingsPackagesUpdateById(id),
      },
      {
        key: "listing_places",
        label: "Location & Nearby",
        href: routes.listingsPlacesUpdateById(id),
      },
      {
        key: "listing_badges",
        label: "Badges",
        href: routes.listingsBadgesUpdateById(id),
      },
    ],
  };

  return <TabContentNavigation activeKey={activeKey} contents={contents} />;
}
