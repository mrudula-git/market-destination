import { Card } from "flowbite-react";
import type { ReactNode } from "react";

type Props = {
  label: string;
  children: ReactNode;
};

export default function ResourceLayout({
  label,
  children,
}: Props): JSX.Element {
  return (
    <div>
      <h3 className="capitalize">{label}</h3>
      <br />
      <div>{children}</div>
    </div>
  );
}
