import TabContentNavigation from "../components/tab-content-navigation";
import { routes } from "../constants/routes";

type Props = {
  activeKey?: string;
};

export default function CategoriesTabLayout({ activeKey }: Props) {
  const contents = {
    items: [
      {
        key: "categories",
        label: "Categories",
        href: routes.categories,
      },
      {
        key: "categories_attributes",
        label: "Attributes",
        href: routes.attributes,
      },
      {
        key: "categories_attribute_groups",
        label: "Attribute Groups",
        href: routes.attributeGroups,
      },
    ],
  };

  return <TabContentNavigation activeKey={activeKey} contents={contents} />;
}
