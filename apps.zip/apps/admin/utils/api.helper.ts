import { toast } from "react-toastify";
import type {
  AdminUsers,
  Contacts,
  Listings,
  ListingsAttributes,
  ListingsAttributesGroup,
  ListingsCategories,
  Reviews,
  Reviewers,
} from "database";
import { baseUrl } from "../constants/apis";
import { getToken } from "next-auth/jwt";
export type QueryArgs = {
  search?: string;
  page?: number | string;
  take?: number | "all";
};

type Args = {
  url?: string;
  api?: string;
  query?: QueryArgs;
  body?: object | null;
  method?: string;
  showToast?: boolean;
  successMessage?: string;
  errorMessage?: string;
};

export type Resources = {
  adminUsers?: AdminUsers[];
  adminUser?: AdminUsers;
  contacts?: Contacts[];
  listings?: Listings[];
  listing?: Listings;
  categories?: ListingsCategories[];
  attributes?: ListingsAttributes[];
  attributeGroups?: ListingsAttributesGroup[];
  reviews?: Reviews[];
  review?: Reviews;
  reviewers?: Reviewers;
  count?: number;
};

export default async function apiKit({
  url,
  api,
  query,
  body = null,
  method = "GET",
  showToast = true,
  successMessage: customSuccessMessage,
  errorMessage: customErrorMessage,
}: Args): Promise<Resources> {
  const defaultSuccessMessage = "Request succeeded";
  const defaultErrorMessage = "Request failed";

  try {
    let qs = new URLSearchParams("");
    if (query) {
      const { search, page, take } = query;
      if (search) qs.append("search", search);
      if (page) qs.append("page", page);
      if (take) qs.append("take", take);
    }

    const _url = (url ?? baseUrl + api) + (qs.size ? `?${qs.toString()}` : "");
    // console.log(_url);

    const response = await fetch(_url, {
      body: method === "GET" ? null : JSON.stringify(body),
      method,
      credentials: "include",
      headers: {
        "Content-Type": "application/json",
        // "Access-Control-Allow-Origin": process.env?.NEXT_PUBLIC_ORIGIN || "*",
      },
    });

    if (response.status >= 200 && response.status < 300) {
      const data = await response.json();
      const successMessage = customSuccessMessage || defaultSuccessMessage;
      if (showToast) {
        showToastMessage(successMessage, "success");
      }
      return data;
    } else {
      const errorMessage = customErrorMessage || defaultErrorMessage;
      if (showToast) {
        showToastMessage(errorMessage, "error");
      }

      const error = await response.json();
      throw error;
    }
  } catch (error) {
    console.log("apiKit ERROR", error);
    throw error;
  }
}

const showToastMessage = (message: string, type: "success" | "error") => {
  toast[type](message, {
    position: "top-right",
    autoClose: 5000,
    hideProgressBar: false,
    closeOnClick: true,
    pauseOnHover: true,
    draggable: true,
    progress: undefined,
    theme: "light",
  });
};
